# TiffinBox: meal subscription API (Spring Boot)

> **Repository questions: there are 3 in this test, one per tech stack (Node, Django, Spring Boot). Solve ANY ONE of them. 60 minutes.**

TiffinBox sells daily meal subscriptions. A customer picks a plan, how many meals a day and for how many days, pays
up front (with GST), can pause the subscription, and gets deliveries that are logged.

Some rules below are broken in the code. The visible tests in `src/test/java` describe them and **all fail right now**.
Fix the code in `src/main/java` until every test passes. Do not edit the tests. Two hidden tests re-check the same rules.

```bash
mvn test                                                   # run all tests
mvn test -Dtest=TiffinApiTest#gstIsRoundedHalfUpToThePaisa  # run one test
```

## Rules

**Plans** (fixed menu, price per meal): `PLN-1` Classic Veg Thali Rs 80.00 · `PLN-2` Chicken Meal Rs 120.00 ·
`PLN-3` Diet Bowl Rs 99.50.

**Subscribing**
- `mealsPerDay` is **1 to 3**; `days` is 1 to 30. Anything else is a validation error.
- subtotal = price per meal × mealsPerDay × days. **GST = 5% of the subtotal, rounded half up to the paisa**
  (Rs 99.50 → GST 4.975 → Rs 4.98). total = subtotal + GST.
- A phone number has at most one open (ACTIVE or PAUSED) subscription: a second one is **409 `ACTIVE_SUBSCRIPTION_EXISTS`**.

**Pausing**
- Only an ACTIVE subscription can be paused (`NOT_ACTIVE`).
- The pause must start **at least 24 hours** after the request. Exactly 24 hours ahead is allowed; less is
  `PAUSE_TOO_LATE`.
- After a pause, the subscription **stays PAUSED** (GET shows status `PAUSED` and `pausedFrom`).

**Deliveries**
- Only ACTIVE subscriptions get deliveries; at most `mealsPerDay` meals per delivery (`TOO_MANY_MEALS`).
- The delivery history is **newest first** (latest `deliveredAt` first), at most 20 entries.

## API

| Method | Path | Body | Success |
|---|---|---|---|
| GET | `/plans` | | 200 menu |
| POST | `/subscriptions` | `{"phone":"9800000001","planId":"PLN-1","mealsPerDay":2,"days":10}` | 201 subscription |
| GET | `/subscriptions/{id}` | | 200 |
| POST | `/subscriptions/{id}/pause` | `{"startsAt":"2026-06-11T06:00:00Z"}` | 200 subscription |
| POST | `/subscriptions/{id}/cancel` | | 200 subscription |
| POST | `/subscriptions/{id}/deliveries` | `{"meals":2}` | 201 delivery |
| GET | `/subscriptions/{id}/deliveries` | | 200 list, newest first |

## Errors

Every error body is `{"code": "...", "message": "...", "fields": [...]}`.

| Code | Status | When |
|---|---|---|
| VALIDATION_FAILED | 400 | a body field breaks a rule; `fields` lists them |
| MALFORMED_REQUEST | 400 | the body is not valid JSON |
| PLAN_NOT_FOUND, SUBSCRIPTION_NOT_FOUND | 404 | unknown id |
| ACTIVE_SUBSCRIPTION_EXISTS | 409 | the phone already has an open subscription |
| NOT_ACTIVE | 409 | pausing, cancelling or delivering when the status does not allow it |
| PAUSE_TOO_LATE | 422 | the pause starts less than 24 hours from now |
| TOO_MANY_MEALS | 422 | a delivery has more meals than mealsPerDay |
