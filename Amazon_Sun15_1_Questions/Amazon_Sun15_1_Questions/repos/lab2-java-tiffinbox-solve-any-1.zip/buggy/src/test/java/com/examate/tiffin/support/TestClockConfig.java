package com.examate.tiffin.support;

import java.time.Instant;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

@TestConfiguration
public class TestClockConfig {

    /** Monday 1 June 2026, 09:00 UTC. */
    @Bean
    @Primary
    public MutableClock testClock() {
        return new MutableClock(Instant.parse("2026-06-01T09:00:00Z"));
    }
}
