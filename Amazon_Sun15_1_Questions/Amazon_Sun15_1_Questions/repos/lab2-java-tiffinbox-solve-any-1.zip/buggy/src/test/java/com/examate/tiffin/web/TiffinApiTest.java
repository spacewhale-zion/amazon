package com.examate.tiffin.web;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.tiffin.support.WebTestBase;
import org.junit.jupiter.api.Test;

/**
 * These tests describe behaviour from README.md that is broken right now: every one of them FAILS on the starting
 * code. Fix the bugs in src/main/java until they all pass. Two hidden tests check the same rules again.
 */
class TiffinApiTest extends WebTestBase {

    @Test
    void gstIsRoundedHalfUpToThePaisa() throws Exception {
        subscribe(newPhone(), "PLN-3", 1, 1)
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.subtotalPaise").value(9_950))
                .andExpect(jsonPath("$.gstPaise").value(498))
                .andExpect(jsonPath("$.totalPaise").value(10_448));
    }

    @Test
    void moreThanThreeMealsADayIsAValidationError() throws Exception {
        subscribe(newPhone(), "PLN-1", 4, 10)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_FAILED"))
                .andExpect(jsonPath("$.fields[0]").value("mealsPerDay"));
    }

    @Test
    void aSecondSubscriptionForTheSamePhoneIs409() throws Exception {
        String phone = newPhone();
        subscribe(phone, "PLN-1", 2, 10).andExpect(status().isCreated());
        subscribe(phone, "PLN-2", 1, 5)
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("ACTIVE_SUBSCRIPTION_EXISTS"));
    }

    @Test
    void aPauseExactly24HoursAheadIsAllowed() throws Exception {
        clock.set("2026-06-10T06:00:00Z");
        String sub = idOf(subscribe(newPhone(), "PLN-1", 2, 20).andExpect(status().isCreated()));
        pause(sub, "2026-06-11T06:00:00Z")
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("PAUSED"));
    }

    @Test
    void aPauseIsSaved() throws Exception {
        clock.set("2026-06-12T06:00:00Z");
        String sub = idOf(subscribe(newPhone(), "PLN-2", 1, 15).andExpect(status().isCreated()));
        pause(sub, "2026-06-14T06:00:00Z").andExpect(status().isOk());
        subscription(sub)
                .andExpect(jsonPath("$.status").value("PAUSED"))
                .andExpect(jsonPath("$.pausedFrom").value("2026-06-14T06:00:00Z"));
    }

    @Test
    void deliveriesAreListedNewestFirst() throws Exception {
        clock.set("2026-06-15T05:00:00Z");
        String sub = idOf(subscribe(newPhone(), "PLN-1", 2, 7).andExpect(status().isCreated()));
        deliver(sub, 1).andExpect(status().isCreated());
        clock.set("2026-06-15T13:00:00Z");
        deliver(sub, 2).andExpect(status().isCreated());
        deliveries(sub)
                .andExpect(jsonPath("$[0].meals").value(2))
                .andExpect(jsonPath("$[1].meals").value(1));
    }
}
