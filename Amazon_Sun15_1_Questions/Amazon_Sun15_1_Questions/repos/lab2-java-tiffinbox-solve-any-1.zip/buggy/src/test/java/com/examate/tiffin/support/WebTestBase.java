package com.examate.tiffin.support;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import com.examate.tiffin.TiffinApplication;
import com.jayway.jsonpath.JsonPath;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/**
 * Every web test extends this class, so all of them share ONE Spring context and ONE clock. Nothing is reset between
 * tests: each test uses its own phone numbers, and a test that depends on the time sets the clock first.
 */
@SpringBootTest(classes = {TiffinApplication.class, TestClockConfig.class})
@AutoConfigureMockMvc
public abstract class WebTestBase {

    private static final AtomicLong PHONES = new AtomicLong(9_800_000_000L);

    @Autowired
    protected MockMvc mvc;

    @Autowired
    protected MutableClock clock;

    protected ResultActions postJson(String url, String json) throws Exception {
        return mvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(json));
    }

    protected ResultActions getUrl(String url) throws Exception {
        return mvc.perform(get(url));
    }

    protected static String idOf(ResultActions result) throws Exception {
        return JsonPath.read(result.andReturn().getResponse().getContentAsString(), "$.id");
    }

    /** A phone number no test has used yet. */
    protected static String newPhone() {
        return String.valueOf(PHONES.incrementAndGet());
    }

    protected ResultActions subscribe(String phone, String planId, int mealsPerDay, int days) throws Exception {
        return postJson("/subscriptions", "{\"phone\":\"" + phone + "\",\"planId\":\"" + planId
                + "\",\"mealsPerDay\":" + mealsPerDay + ",\"days\":" + days + "}");
    }

    protected ResultActions pause(String subscriptionId, String startsAt) throws Exception {
        return postJson("/subscriptions/" + subscriptionId + "/pause", "{\"startsAt\":\"" + startsAt + "\"}");
    }

    protected ResultActions deliver(String subscriptionId, int meals) throws Exception {
        return postJson("/subscriptions/" + subscriptionId + "/deliveries", "{\"meals\":" + meals + "}");
    }

    protected ResultActions subscription(String subscriptionId) throws Exception {
        return getUrl("/subscriptions/" + subscriptionId);
    }

    protected ResultActions deliveries(String subscriptionId) throws Exception {
        return getUrl("/subscriptions/" + subscriptionId + "/deliveries");
    }
}
