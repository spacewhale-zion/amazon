package com.examate.tiffin.repository;

import com.examate.tiffin.domain.Delivery;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

/** In-memory table, in insertion order. */
@Repository
public class DeliveryRepository {

    private final List<Delivery> rows = new ArrayList<>();

    public synchronized Delivery save(Delivery row) {
        rows.add(row);
        return row;
    }

    public synchronized List<Delivery> findBySubscription(String subscriptionId) {
        return rows.stream().filter(d -> d.subscriptionId().equals(subscriptionId)).toList();
    }
}
