package com.examate.tiffin.support;

import java.time.Duration;

/** Business rules from README.md, in one place. */
public final class TiffinRules {

    public static final int MAX_MEALS_PER_DAY = 3;

    public static final int MAX_DAYS = 30;

    /** GST on meal subscriptions, rounded half up to the paisa. */
    public static final int GST_PERCENT = 5;

    /** A pause must start at least this long after the request. */
    public static final Duration PAUSE_NOTICE = Duration.ofHours(24);

    /** How many deliveries the history endpoint returns. */
    public static final int HISTORY_SIZE = 20;

    private TiffinRules() {
    }
}
