package com.examate.tiffin.web;

import com.examate.tiffin.service.DeliveryService;
import com.examate.tiffin.web.dto.DeliveryRequest;
import com.examate.tiffin.web.dto.DeliveryResponse;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DeliveryController {

    private final DeliveryService deliveries;

    public DeliveryController(DeliveryService deliveries) {
        this.deliveries = deliveries;
    }

    @PostMapping("/subscriptions/{subscriptionId}/deliveries")
    @ResponseStatus(HttpStatus.CREATED)
    public DeliveryResponse deliver(@PathVariable("subscriptionId") String subscriptionId,
                                    @Valid @RequestBody DeliveryRequest body) {
        return DeliveryResponse.from(deliveries.deliver(subscriptionId, body.meals()));
    }

    @GetMapping("/subscriptions/{subscriptionId}/deliveries")
    public List<DeliveryResponse> history(@PathVariable("subscriptionId") String subscriptionId) {
        return deliveries.history(subscriptionId).stream().map(DeliveryResponse::from).toList();
    }
}
