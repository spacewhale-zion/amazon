package com.examate.tiffin.domain;

import java.time.Instant;

/** A customer's meal subscription. Immutable: a change is a new Subscription that must be saved. */
public record Subscription(String id, String phone, String planId, int mealsPerDay, int days, long subtotalPaise,
                           long gstPaise, long totalPaise, SubscriptionStatus status, Instant createdAt,
                           Instant pausedFrom) {

    public int totalMeals() {
        return mealsPerDay * days;
    }

    public Subscription paused(Instant from) {
        return new Subscription(id, phone, planId, mealsPerDay, days, subtotalPaise, gstPaise, totalPaise,
                SubscriptionStatus.PAUSED, createdAt, from);
    }

    public Subscription cancelled() {
        return new Subscription(id, phone, planId, mealsPerDay, days, subtotalPaise, gstPaise, totalPaise,
                SubscriptionStatus.CANCELLED, createdAt, pausedFrom);
    }
}
