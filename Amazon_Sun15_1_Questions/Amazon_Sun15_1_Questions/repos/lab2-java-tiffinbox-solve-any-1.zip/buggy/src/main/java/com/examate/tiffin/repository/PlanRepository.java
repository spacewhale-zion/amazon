package com.examate.tiffin.repository;

import com.examate.tiffin.domain.MealPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** The menu. It is fixed for this exercise. */
@Repository
public class PlanRepository {

    private final Map<String, MealPlan> rows = new LinkedHashMap<>();

    public PlanRepository() {
        add(new MealPlan("PLN-1", "Classic Veg Thali", 8_000));
        add(new MealPlan("PLN-2", "Chicken Meal", 12_000));
        add(new MealPlan("PLN-3", "Diet Bowl", 9_950));
    }

    private void add(MealPlan plan) {
        rows.put(plan.id(), plan);
    }

    public Optional<MealPlan> findById(String id) {
        return Optional.ofNullable(rows.get(id));
    }

    public List<MealPlan> findAll() {
        return List.copyOf(rows.values());
    }
}
