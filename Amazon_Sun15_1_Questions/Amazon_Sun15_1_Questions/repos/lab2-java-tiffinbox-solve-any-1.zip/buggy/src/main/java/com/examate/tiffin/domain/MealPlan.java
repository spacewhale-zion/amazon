package com.examate.tiffin.domain;

/** A meal plan on the menu. Price is per meal, in paise. */
public record MealPlan(String id, String name, long pricePerMealPaise) {
}
