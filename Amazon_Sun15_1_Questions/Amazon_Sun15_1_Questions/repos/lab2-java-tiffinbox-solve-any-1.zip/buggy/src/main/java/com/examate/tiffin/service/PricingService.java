package com.examate.tiffin.service;

import com.examate.tiffin.domain.MealPlan;
import com.examate.tiffin.support.Money;
import com.examate.tiffin.support.TiffinRules;
import org.springframework.stereotype.Service;

/** Prices a subscription: subtotal, GST and total, all in paise. */
@Service
public class PricingService {

    public record Quote(long subtotalPaise, long gstPaise, long totalPaise) {
    }

    public Quote quote(MealPlan plan, int mealsPerDay, int days) {
        long subtotal = plan.pricePerMealPaise() * mealsPerDay * days;
        long gst = subtotal * TiffinRules.GST_PERCENT / 100;
        return new Quote(subtotal, gst, subtotal + gst);
    }
}
