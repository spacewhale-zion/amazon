package com.examate.tiffin.error;

import org.springframework.http.HttpStatus;

/** Every error the API can return, with its HTTP status. Must match the error table in README.md. */
public enum ErrorCode {
    VALIDATION_FAILED(HttpStatus.BAD_REQUEST),
    MALFORMED_REQUEST(HttpStatus.BAD_REQUEST),
    PLAN_NOT_FOUND(HttpStatus.NOT_FOUND),
    SUBSCRIPTION_NOT_FOUND(HttpStatus.NOT_FOUND),
    ACTIVE_SUBSCRIPTION_EXISTS(HttpStatus.BAD_REQUEST),
    NOT_ACTIVE(HttpStatus.CONFLICT),
    PAUSE_TOO_LATE(HttpStatus.UNPROCESSABLE_ENTITY),
    TOO_MANY_MEALS(HttpStatus.UNPROCESSABLE_ENTITY);

    private final HttpStatus status;

    ErrorCode(HttpStatus status) {
        this.status = status;
    }

    public HttpStatus status() {
        return status;
    }
}
