package com.examate.tiffin.service;

import com.examate.tiffin.domain.MealPlan;
import com.examate.tiffin.error.ErrorCode;
import com.examate.tiffin.error.TiffinException;
import com.examate.tiffin.repository.PlanRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class PlanService {

    private final PlanRepository plans;

    public PlanService(PlanRepository plans) {
        this.plans = plans;
    }

    public MealPlan get(String planId) {
        return plans.findById(planId)
                .orElseThrow(() -> new TiffinException(ErrorCode.PLAN_NOT_FOUND, "Plan " + planId + " was not found"));
    }

    public List<MealPlan> menu() {
        return plans.findAll();
    }
}
