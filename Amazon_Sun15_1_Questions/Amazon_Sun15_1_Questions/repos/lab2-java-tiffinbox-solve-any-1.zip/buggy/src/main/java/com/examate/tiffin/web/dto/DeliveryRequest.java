package com.examate.tiffin.web.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record DeliveryRequest(@NotNull @Min(1) @Max(3) Integer meals) {
}
