package com.examate.tiffin.web;

import com.examate.tiffin.service.SubscriptionService;
import com.examate.tiffin.web.dto.PauseRequest;
import com.examate.tiffin.web.dto.SubscribeRequest;
import com.examate.tiffin.web.dto.SubscriptionResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SubscriptionController {

    private final SubscriptionService subscriptions;

    public SubscriptionController(SubscriptionService subscriptions) {
        this.subscriptions = subscriptions;
    }

    @PostMapping("/subscriptions")
    @ResponseStatus(HttpStatus.CREATED)
    public SubscriptionResponse subscribe(@Valid @RequestBody SubscribeRequest body) {
        return SubscriptionResponse.from(
                subscriptions.subscribe(body.phone(), body.planId(), body.mealsPerDay(), body.days()));
    }

    @GetMapping("/subscriptions/{subscriptionId}")
    public SubscriptionResponse get(@PathVariable("subscriptionId") String subscriptionId) {
        return SubscriptionResponse.from(subscriptions.get(subscriptionId));
    }

    @PostMapping("/subscriptions/{subscriptionId}/pause")
    public SubscriptionResponse pause(@PathVariable("subscriptionId") String subscriptionId,
                                      @Valid @RequestBody PauseRequest body) {
        return SubscriptionResponse.from(subscriptions.pause(subscriptionId, body.startsAt()));
    }

    @PostMapping("/subscriptions/{subscriptionId}/cancel")
    public SubscriptionResponse cancel(@PathVariable("subscriptionId") String subscriptionId) {
        return SubscriptionResponse.from(subscriptions.cancel(subscriptionId));
    }
}
