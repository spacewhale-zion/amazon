package com.examate.tiffin.repository;

import com.examate.tiffin.domain.Subscription;
import com.examate.tiffin.domain.SubscriptionStatus;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** In-memory table. Records are immutable: a changed record is only kept after save(). */
@Repository
public class SubscriptionRepository {

    private final Map<String, Subscription> rows = new LinkedHashMap<>();

    public synchronized Subscription save(Subscription row) {
        rows.put(row.id(), row);
        return row;
    }

    public synchronized Optional<Subscription> findById(String id) {
        return Optional.ofNullable(rows.get(id));
    }

    /** The phone's subscription that is not cancelled, if any. */
    public synchronized Optional<Subscription> findOpenByPhone(String phone) {
        return rows.values().stream()
                .filter(s -> s.phone().equals(phone) && s.status() != SubscriptionStatus.CANCELLED)
                .findFirst();
    }
}
