package com.examate.tiffin.web.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record SubscribeRequest(@NotBlank @Size(min = 10, max = 13) String phone,
                               @NotBlank String planId,
                               @NotNull @Min(1) Integer mealsPerDay,
                               @NotNull @Min(1) @Max(30) Integer days) {
}
