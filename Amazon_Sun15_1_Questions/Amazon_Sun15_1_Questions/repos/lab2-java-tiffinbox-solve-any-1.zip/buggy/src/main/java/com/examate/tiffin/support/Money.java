package com.examate.tiffin.support;

/** Money helpers. Amounts are whole paise. */
public final class Money {

    private Money() {
    }

    /** percent % of amount, rounded half up to a whole paisa: 5% of 9950 = 497.5 -> 498. */
    public static long percentOf(long amount, int percent) {
        return (amount * percent + 50) / 100;
    }

    public static String rupees(long paise) {
        return String.format("Rs %d.%02d", paise / 100, paise % 100);
    }
}
