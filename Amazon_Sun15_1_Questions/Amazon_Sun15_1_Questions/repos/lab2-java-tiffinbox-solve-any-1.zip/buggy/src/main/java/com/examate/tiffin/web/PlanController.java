package com.examate.tiffin.web;

import com.examate.tiffin.domain.MealPlan;
import com.examate.tiffin.service.PlanService;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PlanController {

    private final PlanService plans;

    public PlanController(PlanService plans) {
        this.plans = plans;
    }

    @GetMapping("/plans")
    public List<MealPlan> menu() {
        return plans.menu();
    }
}
