package com.examate.tiffin.domain;

import java.time.Instant;

/** Meals handed over to the customer at one time. */
public record Delivery(String id, String subscriptionId, int meals, Instant deliveredAt) {
}
