package com.examate.tiffin.web.dto;

import com.examate.tiffin.domain.Subscription;
import java.time.Instant;

public record SubscriptionResponse(String id, String phone, String planId, int mealsPerDay, int days, int totalMeals,
                                   long subtotalPaise, long gstPaise, long totalPaise, String status,
                                   Instant createdAt, Instant pausedFrom) {

    public static SubscriptionResponse from(Subscription s) {
        return new SubscriptionResponse(s.id(), s.phone(), s.planId(), s.mealsPerDay(), s.days(), s.totalMeals(),
                s.subtotalPaise(), s.gstPaise(), s.totalPaise(), s.status().name(), s.createdAt(), s.pausedFrom());
    }
}
