package com.examate.tiffin.domain;

public enum SubscriptionStatus {
    ACTIVE,
    PAUSED,
    CANCELLED
}
