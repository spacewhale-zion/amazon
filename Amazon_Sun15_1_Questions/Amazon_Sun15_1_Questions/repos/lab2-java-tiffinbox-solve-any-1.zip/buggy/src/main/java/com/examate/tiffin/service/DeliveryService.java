package com.examate.tiffin.service;

import com.examate.tiffin.domain.Delivery;
import com.examate.tiffin.domain.Subscription;
import com.examate.tiffin.domain.SubscriptionStatus;
import com.examate.tiffin.error.ErrorCode;
import com.examate.tiffin.error.TiffinException;
import com.examate.tiffin.repository.DeliveryRepository;
import com.examate.tiffin.repository.IdGenerator;
import com.examate.tiffin.support.Ids;
import com.examate.tiffin.support.TiffinRules;
import java.time.Clock;
import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class DeliveryService {

    private static final Comparator<Delivery> NEWEST_FIRST =
            Comparator.comparing(Delivery::deliveredAt).thenComparing(Delivery::id, Ids.NATURAL);

    private final DeliveryRepository deliveries;
    private final SubscriptionService subscriptions;
    private final IdGenerator ids;
    private final Clock clock;

    public DeliveryService(DeliveryRepository deliveries, SubscriptionService subscriptions, IdGenerator ids, Clock clock) {
        this.deliveries = deliveries;
        this.subscriptions = subscriptions;
        this.ids = ids;
        this.clock = clock;
    }

    /** Records meals handed over now. Only ACTIVE subscriptions get deliveries, at most mealsPerDay at a time. */
    public Delivery deliver(String subscriptionId, int meals) {
        Subscription sub = subscriptions.get(subscriptionId);
        if (sub.status() != SubscriptionStatus.ACTIVE) {
            throw new TiffinException(ErrorCode.NOT_ACTIVE, "Subscription " + subscriptionId + " is " + sub.status());
        }
        if (meals > sub.mealsPerDay()) {
            throw new TiffinException(ErrorCode.TOO_MANY_MEALS, "At most " + sub.mealsPerDay() + " meals per delivery");
        }
        return deliveries.save(new Delivery(ids.next("DEL"), subscriptionId, meals, clock.instant()));
    }

    /** Newest delivery first; deliveries at the same instant: the later id first. */
    public List<Delivery> history(String subscriptionId) {
        subscriptions.get(subscriptionId);
        return deliveries.findBySubscription(subscriptionId).stream()
                .sorted(NEWEST_FIRST)
                .limit(TiffinRules.HISTORY_SIZE)
                .toList();
    }
}
