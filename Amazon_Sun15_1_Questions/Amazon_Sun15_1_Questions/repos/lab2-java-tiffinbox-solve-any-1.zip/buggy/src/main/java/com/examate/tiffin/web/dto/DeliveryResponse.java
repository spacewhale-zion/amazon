package com.examate.tiffin.web.dto;

import com.examate.tiffin.domain.Delivery;
import java.time.Instant;

public record DeliveryResponse(String id, String subscriptionId, int meals, Instant deliveredAt) {

    public static DeliveryResponse from(Delivery d) {
        return new DeliveryResponse(d.id(), d.subscriptionId(), d.meals(), d.deliveredAt());
    }
}
