package com.examate.tiffin.error;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(TiffinException.class)
    public ResponseEntity<ApiError> onBusinessError(TiffinException e) {
        return respond(e.code(), e.getMessage(), List.of());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiError> onInvalidBody(MethodArgumentNotValidException e) {
        List<String> fields = e.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getField)
                .distinct()
                .sorted()
                .toList();
        return respond(ErrorCode.VALIDATION_FAILED, "The request has invalid fields", fields);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiError> onUnreadableBody(HttpMessageNotReadableException e) {
        return respond(ErrorCode.MALFORMED_REQUEST, "The request body is not valid JSON for this endpoint", List.of());
    }

    private ResponseEntity<ApiError> respond(ErrorCode code, String message, List<String> fields) {
        return ResponseEntity.status(code.status()).body(new ApiError(code.name(), message, fields));
    }
}
