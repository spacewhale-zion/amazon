package com.examate.tiffin.error;

/** A business rule was broken. The handler turns it into the error body for its code. */
public class TiffinException extends RuntimeException {

    private final ErrorCode code;

    public TiffinException(ErrorCode code, String message) {
        super(message);
        this.code = code;
    }

    public ErrorCode code() {
        return code;
    }
}
