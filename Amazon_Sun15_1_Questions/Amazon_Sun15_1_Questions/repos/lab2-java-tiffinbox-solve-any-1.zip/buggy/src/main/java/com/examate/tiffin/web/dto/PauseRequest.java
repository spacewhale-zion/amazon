package com.examate.tiffin.web.dto;

import jakarta.validation.constraints.NotNull;
import java.time.Instant;

public record PauseRequest(@NotNull Instant startsAt) {
}
