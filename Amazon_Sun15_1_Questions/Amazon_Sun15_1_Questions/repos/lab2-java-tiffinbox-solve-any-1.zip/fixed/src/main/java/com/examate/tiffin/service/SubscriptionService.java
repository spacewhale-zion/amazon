package com.examate.tiffin.service;

import com.examate.tiffin.domain.MealPlan;
import com.examate.tiffin.domain.Subscription;
import com.examate.tiffin.domain.SubscriptionStatus;
import com.examate.tiffin.error.ErrorCode;
import com.examate.tiffin.error.TiffinException;
import com.examate.tiffin.repository.IdGenerator;
import com.examate.tiffin.repository.SubscriptionRepository;
import com.examate.tiffin.support.TiffinRules;
import java.time.Clock;
import java.time.Instant;
import org.springframework.stereotype.Service;

@Service
public class SubscriptionService {

    private final SubscriptionRepository subscriptions;
    private final PlanService plans;
    private final PricingService pricing;
    private final IdGenerator ids;
    private final Clock clock;

    public SubscriptionService(SubscriptionRepository subscriptions, PlanService plans, PricingService pricing,
                               IdGenerator ids, Clock clock) {
        this.subscriptions = subscriptions;
        this.plans = plans;
        this.pricing = pricing;
        this.ids = ids;
        this.clock = clock;
    }

    public Subscription get(String subscriptionId) {
        return subscriptions.findById(subscriptionId).orElseThrow(() -> new TiffinException(
                ErrorCode.SUBSCRIPTION_NOT_FOUND, "Subscription " + subscriptionId + " was not found"));
    }

    /** One open (ACTIVE or PAUSED) subscription per phone number. */
    public Subscription subscribe(String phone, String planId, int mealsPerDay, int days) {
        String p = phone.trim();
        MealPlan plan = plans.get(planId);
        if (subscriptions.findOpenByPhone(p).isPresent()) {
            throw new TiffinException(ErrorCode.ACTIVE_SUBSCRIPTION_EXISTS, "Phone " + p + " already has a subscription");
        }
        PricingService.Quote q = pricing.quote(plan, mealsPerDay, days);
        return subscriptions.save(new Subscription(ids.next("SUB"), p, plan.id(), mealsPerDay, days, q.subtotalPaise(),
                q.gstPaise(), q.totalPaise(), SubscriptionStatus.ACTIVE, clock.instant(), null));
    }

    /** An ACTIVE subscription can be paused from a time at least 24 hours away. */
    public Subscription pause(String subscriptionId, Instant startsAt) {
        Subscription sub = get(subscriptionId);
        if (sub.status() != SubscriptionStatus.ACTIVE) {
            throw new TiffinException(ErrorCode.NOT_ACTIVE, "Subscription " + subscriptionId + " is " + sub.status());
        }
        Instant earliest = clock.instant().plus(TiffinRules.PAUSE_NOTICE);
        if (startsAt.isBefore(earliest)) {
            throw new TiffinException(ErrorCode.PAUSE_TOO_LATE, "A pause must start at or after " + earliest);
        }
        return subscriptions.save(sub.paused(startsAt));
    }

    public Subscription cancel(String subscriptionId) {
        Subscription sub = get(subscriptionId);
        if (sub.status() == SubscriptionStatus.CANCELLED) {
            throw new TiffinException(ErrorCode.NOT_ACTIVE, "Subscription " + subscriptionId + " is already cancelled");
        }
        return subscriptions.save(sub.cancelled());
    }
}
