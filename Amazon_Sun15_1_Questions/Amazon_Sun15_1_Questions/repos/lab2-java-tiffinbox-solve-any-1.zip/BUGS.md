# Planted bugs (author only, never shown to students)

TiffinBox meal subscription API (Spring Boot).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Kind | Symptom | File | Fixed code | Buggy code | Visible tests | Hidden tests |
|---|---|---|---|---|---|---|---|
| 1 | RP-07 Rounding | GST is truncated instead of rounded half up | `src/main/java/com/examate/tiffin/service/PricingService.java` | `long gst = Money.percentOf(subtotal, TiffinRules.GST_PERCENT);` | `long gst = subtotal * TiffinRules.GST_PERCENT / 100;` | gstIsRoundedHalfUpToThePaisa | gstOnABiggerOrderIsAlsoRoundedHalfUp |
| 2 | RP-05 Validation missing | 4 or more meals a day are accepted | `src/main/java/com/examate/tiffin/web/dto/SubscribeRequest.java` | `@NotNull @Min(1) @Max(3) Integer mealsPerDay` | `@NotNull @Min(1) Integer mealsPerDay` | moreThanThreeMealsADayIsAValidationError | none |
| 3 | RP-03 Wrong status code | A second subscription answers 400 instead of 409 | `src/main/java/com/examate/tiffin/error/ErrorCode.java` | `ACTIVE_SUBSCRIPTION_EXISTS(HttpStatus.CONFLICT)` | `ACTIVE_SUBSCRIPTION_EXISTS(HttpStatus.BAD_REQUEST)` | aSecondSubscriptionForTheSamePhoneIs409 | none |
| 4 | RP-06 Boundary | A pause exactly 24 hours ahead is refused | `src/main/java/com/examate/tiffin/service/SubscriptionService.java` | `if (startsAt.isBefore(earliest)) {` | `if (!startsAt.isAfter(earliest)) {` | aPauseExactly24HoursAheadIsAllowed | none |
| 5 | RP-04 Change never saved (immutable record) | A pause is lost: GET still shows ACTIVE | `src/main/java/com/examate/tiffin/service/SubscriptionService.java` | `return subscriptions.save(sub.paused(startsAt));` | `return sub.paused(startsAt);` | aPauseIsSaved | none |
| 6 | RP-08 Wrong sort order | Delivery history is oldest first | `src/main/java/com/examate/tiffin/service/DeliveryService.java` | `Comparator.comparing(Delivery::deliveredAt).thenComparing(Delivery::id, Ids.NATURAL).reversed();` | `Comparator.comparing(Delivery::deliveredAt).thenComparing(Delivery::id, Ids.NATURAL);` | deliveriesAreListedNewestFirst | theLatestOfThreeDeliveriesComesFirst |

Fix notes:

1. Use Money.percentOf, which rounds half up to the paisa.
2. Add @Max(3) to mealsPerDay (TiffinRules.MAX_MEALS_PER_DAY).
3. A duplicate is a conflict with existing state: HttpStatus.CONFLICT (409).
4. Refuse only when the start is before now + 24h; exactly 24h is allowed.
5. paused(...) returns a new Subscription; store it with subscriptions.save(...).
6. Reverse the comparator: newest first, and among deliveries at the same instant the higher id first.
