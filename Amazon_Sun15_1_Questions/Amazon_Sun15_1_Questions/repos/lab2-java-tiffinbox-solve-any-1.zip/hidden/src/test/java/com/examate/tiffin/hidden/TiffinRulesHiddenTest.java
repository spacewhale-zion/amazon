package com.examate.tiffin.hidden;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.tiffin.support.WebTestBase;
import org.junit.jupiter.api.Test;

class TiffinRulesHiddenTest extends WebTestBase {

    @Test
    void gstOnABiggerOrderIsAlsoRoundedHalfUp() throws Exception {
        subscribe(newPhone(), "PLN-3", 3, 3)
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.subtotalPaise").value(89_550))
                .andExpect(jsonPath("$.gstPaise").value(4_478));
    }

    @Test
    void theLatestOfThreeDeliveriesComesFirst() throws Exception {
        clock.set("2026-06-20T04:00:00Z");
        String sub = idOf(subscribe(newPhone(), "PLN-2", 3, 5).andExpect(status().isCreated()));
        deliver(sub, 3).andExpect(status().isCreated());
        clock.set("2026-06-20T08:00:00Z");
        deliver(sub, 1).andExpect(status().isCreated());
        clock.set("2026-06-21T04:00:00Z");
        deliver(sub, 2).andExpect(status().isCreated());
        deliveries(sub)
                .andExpect(jsonPath("$[0].meals").value(2))
                .andExpect(jsonPath("$[2].meals").value(3));
    }
}
