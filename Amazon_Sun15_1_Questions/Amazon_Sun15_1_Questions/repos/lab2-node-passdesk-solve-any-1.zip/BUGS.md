# Planted bugs (author only, never shown to students)

PassDesk college bus pass API (Express).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Tracker | Kind | Symptom | File | Fixed code | Buggy code | Visible test | Hidden test |
|---|---|---|---|---|---|---|---|---|
| 1 | RP-07 | Rounding | Percentages are truncated instead of rounded half up | `src/utils/money.js` | `return Math.floor((amount * basisPoints + 5000) / 10000);` | `return Math.floor((amount * basisPoints) / 10000);` | a 3-month pass gets 5% off, rounded half up to the paisa | a 6-month pass with a sibling discount is rounded half up |
| 2 | RP-05 | Missing validation | Any pass length from 1 to 6 months is accepted | `src/validators/passValidator.js` | `check.require(Number.isInteger(months) && ALLOWED_MONTHS.includes(months), 'months', 'must be 1, 3 or 6');` | `check.require(Number.isInteger(months) && months >= 1 && months <= 6, 'months', 'must be 1, 3 or 6');` | a 2-month pass is a validation error | none |
| 3 | RP-03 | Wrong status code | ACTIVE_PASS_EXISTS is returned as 400 instead of 409 | `src/errors/errorCodes.js` | `ACTIVE_PASS_EXISTS: 409,` | `ACTIVE_PASS_EXISTS: 400,` | asking for a second pass while one is active is 409 ACTIVE_PASS_EXISTS | none |
| 4 | RP-06 | Boundary (> vs >=) | Renewing exactly 7 days before expiry is refused | `src/services/renewalService.js` | `if (left > config.RENEW_WINDOW_DAYS) {` | `if (left >= config.RENEW_WINDOW_DAYS) {` | a pass can be renewed exactly 7 days before it expires | renewal opens exactly 7 days before expiry, not 8 |
| 5 | RP-04 | Change never saved | A renewal is lost: the pass is never saved | `src/services/renewalService.js` | `const saved = passRepository.save(pass);` | `const saved = pass;` | a renewal is kept on the pass | none |
| 6 | RP-08 | Wrong sort order | Pass history is listed oldest first | `src/services/historyService.js` | `.sort(byKeys([(p) => p.validFrom, 'desc'], [byIdNumber, 'desc']))` | `.sort(byKeys([(p) => p.validFrom, 'asc'], [byIdNumber, 'asc']))` | a student's passes are listed newest first | none |
