'use strict';

const config = require('../config');
const { createChecker, isNonEmptyString } = require('./common');

const ALLOWED_MONTHS = Object.keys(config.TERM_DISCOUNT_BP).map(Number);   // [1, 3, 6]

function checkMonths(check, months) {
  check.require(Number.isInteger(months) && ALLOWED_MONTHS.includes(months), 'months', 'must be 1, 3 or 6');
}

/** Body of POST /passes: { rollNo, routeId, months } */
function validateNewPass(body) {
  const check = createChecker();
  check.require(isNonEmptyString(body.rollNo), 'rollNo', 'is required');
  check.require(isNonEmptyString(body.routeId), 'routeId', 'is required');
  checkMonths(check, body.months);
  check.throwIfAny();
  return { rollNo: body.rollNo, routeId: body.routeId, months: body.months };
}

/** Body of POST /passes/:id/renew: { months } */
function validateRenewal(body) {
  const check = createChecker();
  checkMonths(check, body.months);
  check.throwIfAny();
  return { months: body.months };
}

module.exports = { validateNewPass, validateRenewal, ALLOWED_MONTHS };
