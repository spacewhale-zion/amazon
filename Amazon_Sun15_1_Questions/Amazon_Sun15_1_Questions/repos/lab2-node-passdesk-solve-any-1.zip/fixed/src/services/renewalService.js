'use strict';

const config = require('../config');
const { AppError } = require('../errors/AppError');
const { validateRenewal } = require('../validators/passValidator');
const { statusOf, daysLeft, toView } = require('./passStatus');
const { PassStatus } = require('../domain/statuses');
const { addMonths, toDateString } = require('../utils/time');

/**
 * Renewing extends the SAME pass: validTill moves forward by `months`, a RENEWAL receipt is issued and the
 * renewal is added to pass.renewals. Only an ACTIVE pass in its last 7 days (inclusive) can be renewed.
 */
function createRenewalService({ passRepository, receiptRepository, studentService, passService, pricingService, ids, clock }) {
  function renew(id, body) {
    const input = validateRenewal(body || {});
    const pass = passService.requirePass(id);
    const now = toDateString(clock());

    const status = statusOf(pass, now);
    if (status !== PassStatus.ACTIVE) {
      throw new AppError('INVALID_STATE', `Only an ACTIVE pass can be renewed (${pass.id} is ${status})`);
    }
    const left = daysLeft(pass, now);
    if (left > config.RENEW_WINDOW_DAYS) {
      throw new AppError('TOO_EARLY', `Renewal opens ${config.RENEW_WINDOW_DAYS} days before expiry (${left} days left)`);
    }

    const student = studentService.requireStudent(pass.rollNo);
    const route = passService.requireOpenRoute(pass.routeId);
    const price = pricingService.quote(student, route, input.months, now);

    pass.validTill = addMonths(pass.validTill, input.months);
    pass.renewals.push({ months: input.months, on: now, total: price.total });
    const saved = passRepository.save(pass);

    receiptRepository.save({ id: ids.next('rcp'), passId: pass.id, kind: 'RENEWAL', amount: price.total, on: now });
    return toView(saved, now);
  }

  return { renew };
}

module.exports = { createRenewalService };
