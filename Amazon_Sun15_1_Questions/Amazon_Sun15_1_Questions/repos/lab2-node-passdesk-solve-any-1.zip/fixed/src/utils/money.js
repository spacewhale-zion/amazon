'use strict';

/**
 * A percentage of an amount in paise, given in basis points (100 bp = 1%), rounded half up to whole paise.
 * percentOf(299970, 500) === 14999 (5% of 299970 is 14998.5).
 */
function percentOf(amount, basisPoints) {
  return Math.floor((amount * basisPoints + 5000) / 10000);
}

/** Paise to a display string: 125000 -> "Rs 1250.00". */
function formatRupees(paise) {
  return `Rs ${(paise / 100).toFixed(2)}`;
}

module.exports = { percentOf, formatRupees };
