const { makeApp, newStudent, issued, renew } = require('../helpers');

describe('hidden: PassDesk rules', () => {
  test('a 6-month pass with a sibling discount is rounded half up', async () => {
    const ctx = makeApp();
    const elder = await newStudent(ctx);
    await issued(ctx, elder, 'R1', 1);
    const younger = await newStudent(ctx, { siblingRollNo: elder });
    const pass = await issued(ctx, younger, 'R2', 6);
    expect(pass.price).toEqual({
      monthlyFare: 135050, months: 6, base: 810300, termDiscount: 81030, siblingDiscount: 91159, total: 638111,
    });
  });

  test('renewal opens exactly 7 days before expiry, not 8', async () => {
    const ctx = makeApp();
    const pass = await issued(ctx, await newStudent(ctx), 'R3', 3);     // valid up to 2026-09-01
    ctx.clock.set('2026-08-24T06:00:00Z');                              // 8 days left
    const early = await renew(ctx, pass.id, 3);
    expect(early.status).toBe(422);
    expect(early.body.error).toBe('TOO_EARLY');
    ctx.clock.set('2026-08-25T06:00:00Z');                              // 7 days left
    const ok = await renew(ctx, pass.id, 3);
    expect(ok.status).toBe(200);
    expect(ok.body.validTill).toBe('2026-12-01');
  });
});
