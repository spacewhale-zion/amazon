# PassDesk college bus pass API (Express)

> **Repository questions: there are 3 in this test, one per tech stack (Node, Django, Spring Boot). Solve ANY ONE of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | PassDesk college bus passes | Node.js / Express |
> | 2 | CourtBook sports club bookings | Python / Django |
>
> Pick the one you are most comfortable with. Only one is counted, so finish one completely rather than
> starting both.
>
> **Every test in `tests/` fails on the starting code.** Each failing test points at a bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. When all of them pass you are almost done:
> two hidden tests run on submit, and they check **the same rules** as the visible tests (with other data), so fix
> the rule properly instead of special-casing the test values.

PassDesk runs the transport office of an engineering college: bus routes, students, monthly bus passes, renewals,
sibling discounts and receipts.

**Your task: find and fix the bugs in `src/` so that the API behaves as this README says.** Do not change the tests,
`package.json` or this file. When the code and the README disagree, the README is right.

```
npm install
npx jest          # run the tests
node src/server.js
```

## Code map

| Folder | What is in it |
|---|---|
| `src/app.js`, `src/container.js` | builds one app; wires repositories and services |
| `src/routes/` | HTTP layer only (no rules) |
| `src/services/` | the business rules: `passService` (issue, suspend, receipts), `renewalService`, `pricingService`, `historyService`, `studentService`, `routeService`, `passStatus` (status and views) |
| `src/repositories/` | in-memory tables. **Reads return copies**: a change is stored only when you `save` it |
| `src/validators/`, `src/utils/`, `src/config/`, `src/errors/` | input checks, money / time / sort helpers, constants, error codes |

## Conventions

* Money is in **paise** (100 paise = Rs 1). Dates are `YYYY-MM-DD` (UTC); the app reads today's date from the injected clock.
* Ids look like `pas_1`, `rcp_2`. Roll numbers look like `22CSE101`.
* Staff endpoints need the header `X-Role: staff` (or `admin`); otherwise 403 FORBIDDEN.
* Errors: `{ "error": CODE, "message": text, "details"?: [{ "field", "issue" }] }`.

| Code | HTTP | Code | HTTP |
|---|---|---|---|
| VALIDATION_FAILED | 400 | DUPLICATE, ACTIVE_PASS_EXISTS, INVALID_STATE | 409 |
| FORBIDDEN | 403 | TOO_EARLY, ROUTE_CLOSED | 422 |
| NOT_FOUND | 404 | | |

## Seed routes

| Id | Route | Monthly fare (paise) |
|---|---|---|
| R1 | Ameerpet - Campus | 125000 |
| R2 | Secunderabad - Campus | 135050 |
| R3 | LB Nagar - Campus | 99990 |
| R4 | Kukatpally - Campus | 150000 |

## Endpoints

| Method and path | Who | Notes |
|---|---|---|
| `GET /routes`, `GET /routes/:id` | anyone | |
| `GET /routes/:id/riders` | staff | roll numbers with an ACTIVE pass on the route |
| `POST /students`, `GET /students/:rollNo` | anyone | `{ rollNo, name, siblingRollNo? }`; a roll number registered twice is 409 DUPLICATE |
| `GET /students/:rollNo/passes` | anyone | the student's pass history (rule 7) |
| `POST /passes` | anyone | `{ rollNo, routeId, months }` -> 201 |
| `GET /passes/:id`, `GET /passes/:id/receipts` | anyone | |
| `POST /passes/:id/renew` | anyone | `{ months }` -> 200 |
| `POST /passes/:id/suspend` | staff | ACTIVE passes only |

Pass view: `{ id, rollNo, routeId, months, validFrom, validTill, status, daysLeft, price, renewals }`.

## Business rules

### Passes
1. `months` must be **1, 3 or 6**. Anything else is 400 VALIDATION_FAILED with the detail
   `{ "field": "months", "issue": "must be 1, 3 or 6" }`.
2. A pass is valid from `validFrom` (the day it is issued) up to, **not including**, `validTill = validFrom + months`.
   Its status is SUSPENDED if staff suspended it, EXPIRED from `validTill` on, and ACTIVE before that.
3. A student can hold only **one ACTIVE pass**. Asking for another is **409 ACTIVE_PASS_EXISTS**.

### Price (fixed when the pass or renewal is bought)
4. `base = monthlyFare x months`. A 3-month pass gets **5%** off the base and a 6-month pass **10%** (`termDiscount`).
   If the student's sibling holds an ACTIVE pass today, a further **12.5%** of `(base - termDiscount)` comes off
   (`siblingDiscount`). `total = base - termDiscount - siblingDiscount`.
5. Every percentage is **rounded half up** to whole paise (5% of 299970 = 14998.5 -> 14999).

### Renewal
6. Renewing extends the **same** pass: `validTill` moves forward by `months`, the renewal is added to `renewals`,
   and a RENEWAL receipt is issued. The change is permanent: later reads show the new `validTill`.
   Only an ACTIVE pass can be renewed (409 INVALID_STATE), and only in its **last 7 days, inclusive**: with 7 or
   fewer days left it is allowed; with 8 or more it is 422 TOO_EARLY.

### History
7. `GET /students/:rollNo/passes` lists the student's passes **newest first**: latest `validFrom` first, and for the
   same day the higher pass number first.
