'use strict';

const { validationError } = require('../errors/AppError');

/** Collects field problems and throws one VALIDATION_FAILED error with all of them. */
function createChecker() {
  const details = [];
  return {
    require(cond, field, issue) {
      if (!cond) details.push({ field, issue });
    },
    throwIfAny() {
      if (details.length) throw validationError(details);
    },
  };
}

const isNonEmptyString = (v) => typeof v === 'string' && v.trim().length > 0;

module.exports = { createChecker, isNonEmptyString };
