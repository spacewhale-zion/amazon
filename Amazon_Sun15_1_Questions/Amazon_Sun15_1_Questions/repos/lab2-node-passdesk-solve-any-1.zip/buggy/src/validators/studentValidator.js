'use strict';

const config = require('../config');
const { createChecker, isNonEmptyString } = require('./common');

/** Body of POST /students: { rollNo, name, siblingRollNo? } */
function validateNewStudent(body) {
  const check = createChecker();
  check.require(typeof body.rollNo === 'string' && config.ROLL_PATTERN.test(body.rollNo), 'rollNo', 'must look like 22CSE101');
  check.require(isNonEmptyString(body.name), 'name', 'is required');
  if (body.siblingRollNo !== undefined && body.siblingRollNo !== null) {
    check.require(typeof body.siblingRollNo === 'string' && config.ROLL_PATTERN.test(body.siblingRollNo),
      'siblingRollNo', 'must look like 22CSE101');
    check.require(body.siblingRollNo !== body.rollNo, 'siblingRollNo', 'cannot be the student themself');
  }
  check.throwIfAny();
  return {
    rollNo: body.rollNo,
    name: body.name.trim(),
    siblingRollNo: body.siblingRollNo || null,
  };
}

module.exports = { validateNewStudent };
