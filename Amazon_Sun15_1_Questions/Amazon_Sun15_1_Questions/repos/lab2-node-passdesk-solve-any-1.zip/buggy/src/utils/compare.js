'use strict';

const { idNumber } = require('./ids');

/** Sort helper: compare by several keys in order; each key is [getter, 'asc' | 'desc']. */
function byKeys(...keys) {
  return (a, b) => {
    for (const [get, dir] of keys) {
      const x = get(a);
      const y = get(b);
      if (x < y) return dir === 'desc' ? 1 : -1;
      if (x > y) return dir === 'desc' ? -1 : 1;
    }
    return 0;
  };
}

const byIdNumber = (item) => idNumber(item.id);

module.exports = { byKeys, byIdNumber };
