'use strict';

/** Deep copy for plain data (no functions, no dates). Repositories hand out copies, never the stored object. */
function clone(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

module.exports = { clone };
