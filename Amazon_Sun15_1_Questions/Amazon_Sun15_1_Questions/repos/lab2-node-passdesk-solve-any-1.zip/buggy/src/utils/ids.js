'use strict';

/** Ids look like pas_1, rcp_4. Numbers grow per prefix. */
function createIdGenerator() {
  const counters = new Map();
  return {
    next(prefix) {
      const n = (counters.get(prefix) || 0) + 1;
      counters.set(prefix, n);
      return `${prefix}_${n}`;
    },
  };
}

/** The number part of an id: idNumber('pas_12') === 12. */
function idNumber(id) {
  return Number(String(id).split('_')[1]);
}

module.exports = { createIdGenerator, idNumber };
