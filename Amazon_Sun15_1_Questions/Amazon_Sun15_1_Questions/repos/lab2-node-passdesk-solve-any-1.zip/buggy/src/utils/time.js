'use strict';

const DAY_MS = 24 * 60 * 60 * 1000;

/** 'YYYY-MM-DD' for a Date (UTC). */
function toDateString(d) {
  return d.toISOString().slice(0, 10);
}

/** Parses 'YYYY-MM-DD' as midnight UTC. */
function parseDate(s) {
  return new Date(`${s}T00:00:00Z`);
}

/** Adds whole months; the day is clamped to the month's last day (31 Jan + 1 month = 28/29 Feb). */
function addMonths(dateString, months) {
  const d = parseDate(dateString);
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth() + months;
  const target = new Date(Date.UTC(y, m, 1));
  const lastDay = new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0)).getUTCDate();
  target.setUTCDate(Math.min(d.getUTCDate(), lastDay));
  return toDateString(target);
}

/** Whole days from `from` to `to` (both 'YYYY-MM-DD'). daysBetween('2026-06-01', '2026-06-08') === 7. */
function daysBetween(from, to) {
  return Math.round((parseDate(to) - parseDate(from)) / DAY_MS);
}

module.exports = { toDateString, parseDate, addMonths, daysBetween, DAY_MS };
