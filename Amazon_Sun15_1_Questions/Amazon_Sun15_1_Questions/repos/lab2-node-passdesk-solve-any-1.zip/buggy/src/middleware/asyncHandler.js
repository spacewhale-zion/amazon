'use strict';

/** Wraps a route handler so that thrown errors (sync or async) reach the error handler. */
function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    try {
      Promise.resolve(fn(req, res, next)).catch(next);
    } catch (err) {
      next(err);
    }
  };
}

module.exports = { asyncHandler };
