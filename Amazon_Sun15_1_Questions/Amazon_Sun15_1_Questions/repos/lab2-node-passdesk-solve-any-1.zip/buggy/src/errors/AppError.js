'use strict';

const { statusFor } = require('./errorCodes');

class AppError extends Error {
  /**
   * @param {string} code one of ERROR_CODES
   * @param {string} message human readable message
   * @param {Array<{field: string, issue: string}>} [details] field-level problems for validation errors
   */
  constructor(code, message, details) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.status = statusFor(code);
    this.details = details && details.length ? details : undefined;
  }
}

const validationError = (details) => new AppError('VALIDATION_FAILED', 'The request is not valid', details);
const notFound = (what, id) => new AppError('NOT_FOUND', `${what} ${id} was not found`);

module.exports = { AppError, validationError, notFound };
