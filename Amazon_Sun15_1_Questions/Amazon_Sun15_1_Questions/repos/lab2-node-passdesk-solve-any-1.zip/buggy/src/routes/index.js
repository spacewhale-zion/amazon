'use strict';

const { asyncHandler } = require('../middleware/asyncHandler');
const { requireStaff } = require('../middleware/requireRole');

/** HTTP layer only: every rule lives in src/services. */
function mountRoutes(app, c) {
  app.get('/routes', asyncHandler((req, res) => res.json(c.routeService.list())));
  app.get('/routes/:id', asyncHandler((req, res) => res.json(c.routeService.get(req.params.id))));
  app.get('/routes/:id/riders', requireStaff, asyncHandler((req, res) => res.json(c.routeService.riders(req.params.id))));

  app.post('/students', asyncHandler((req, res) => res.status(201).json(c.studentService.register(req.body))));
  app.get('/students/:rollNo', asyncHandler((req, res) => res.json(c.studentService.get(req.params.rollNo))));
  app.get('/students/:rollNo/passes', asyncHandler((req, res) => res.json(c.historyService.forStudent(req.params.rollNo))));

  app.post('/passes', asyncHandler((req, res) => res.status(201).json(c.passService.issue(req.body))));
  app.get('/passes/:id', asyncHandler((req, res) => res.json(c.passService.get(req.params.id))));
  app.post('/passes/:id/renew', asyncHandler((req, res) => res.json(c.renewalService.renew(req.params.id, req.body))));
  app.post('/passes/:id/suspend', requireStaff, asyncHandler((req, res) => res.json(c.passService.suspend(req.params.id))));
  app.get('/passes/:id/receipts', asyncHandler((req, res) => res.json(c.passService.receipts(req.params.id))));
}

module.exports = { mountRoutes };
