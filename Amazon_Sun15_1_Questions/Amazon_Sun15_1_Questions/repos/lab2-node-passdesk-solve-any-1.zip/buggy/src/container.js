'use strict';

const { createRouteRepository } = require('./repositories/routeRepository');
const { createStudentRepository } = require('./repositories/studentRepository');
const { createPassRepository } = require('./repositories/passRepository');
const { createReceiptRepository } = require('./repositories/receiptRepository');
const { createStudentService } = require('./services/studentService');
const { createPricingService } = require('./services/pricingService');
const { createPassService } = require('./services/passService');
const { createRenewalService } = require('./services/renewalService');
const { createHistoryService } = require('./services/historyService');
const { createRouteService } = require('./services/routeService');

/** Wires repositories and services for one app instance. A service is built after its dependencies. */
function createContainer(store, clock) {
  const c = {
    ids: store.ids,
    clock,
    routeRepository: createRouteRepository(store),
    studentRepository: createStudentRepository(store),
    passRepository: createPassRepository(store),
    receiptRepository: createReceiptRepository(store),
  };
  c.studentService = createStudentService(c);
  c.pricingService = createPricingService(c);
  c.passService = createPassService(c);
  c.renewalService = createRenewalService(c);
  c.historyService = createHistoryService(c);
  c.routeService = createRouteService(c);
  return c;
}

module.exports = { createContainer };
