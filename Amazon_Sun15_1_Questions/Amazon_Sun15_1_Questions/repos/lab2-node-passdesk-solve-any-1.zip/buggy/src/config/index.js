'use strict';

module.exports = Object.freeze({
  /** A pass can be renewed only in the last RENEW_WINDOW_DAYS days before it expires (inclusive). */
  RENEW_WINDOW_DAYS: 7,
  /** Allowed pass lengths in months and the term discount for each, in basis points (100 bp = 1%). */
  TERM_DISCOUNT_BP: Object.freeze({ 1: 0, 3: 500, 6: 1000 }),
  /** Extra discount when a sibling already holds an ACTIVE pass, in basis points (12.5%). */
  SIBLING_DISCOUNT_BP: 1250,
  ROLL_PATTERN: /^[0-9]{2}[A-Z]{2,4}[0-9]{3}$/,
});
