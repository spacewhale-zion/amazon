'use strict';

/** Monthly fares are in paise (100 paise = Rs 1). */
const SEED_ROUTES = [
  { id: 'R1', name: 'Ameerpet - Campus', stops: 9, monthlyFare: 125000, active: true },
  { id: 'R2', name: 'Secunderabad - Campus', stops: 12, monthlyFare: 135050, active: true },
  { id: 'R3', name: 'LB Nagar - Campus', stops: 14, monthlyFare: 99990, active: true },
  { id: 'R4', name: 'Kukatpally - Campus', stops: 7, monthlyFare: 150000, active: true },
];

module.exports = { SEED_ROUTES };
