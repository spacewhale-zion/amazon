'use strict';

const { createBaseRepository } = require('./baseRepository');

function createReceiptRepository(store) {
  const base = createBaseRepository(store.receipts);
  return {
    ...base,
    findByPass(passId) {
      return base.findAll((r) => r.passId === passId);
    },
  };
}

module.exports = { createReceiptRepository };
