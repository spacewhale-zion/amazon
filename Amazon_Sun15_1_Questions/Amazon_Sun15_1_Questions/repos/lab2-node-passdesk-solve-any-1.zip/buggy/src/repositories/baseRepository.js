'use strict';

const { clone } = require('../utils/clone');

/**
 * A table in the in-memory store. Reads return COPIES: changing an object you got from findById or findAll does
 * nothing until you call save() with it.
 */
function createBaseRepository(table) {
  return {
    findById(id) {
      return clone(table.get(id));
    },
    findAll(predicate = () => true) {
      return [...table.values()].filter(predicate).map(clone);
    },
    save(entity) {
      table.set(entity.id, clone(entity));
      return clone(entity);
    },
    exists(id) {
      return table.has(id);
    },
  };
}

module.exports = { createBaseRepository };
