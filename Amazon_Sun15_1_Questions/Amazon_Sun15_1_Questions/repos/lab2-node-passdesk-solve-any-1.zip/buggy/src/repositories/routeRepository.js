'use strict';

const { createBaseRepository } = require('./baseRepository');

function createRouteRepository(store) {
  const base = createBaseRepository(store.routes);
  return {
    ...base,
    findActive() {
      return base.findAll((r) => r.active);
    },
  };
}

module.exports = { createRouteRepository };
