'use strict';

const { createBaseRepository } = require('./baseRepository');

/** Students are stored by roll number (their id). */
function createStudentRepository(store) {
  const base = createBaseRepository(store.students);
  return {
    ...base,
    findByRoll(rollNo) {
      return base.findById(rollNo);
    },
  };
}

module.exports = { createStudentRepository };
