'use strict';

const { createBaseRepository } = require('./baseRepository');

function createPassRepository(store) {
  const base = createBaseRepository(store.passes);
  return {
    ...base,
    findByStudent(rollNo) {
      return base.findAll((p) => p.rollNo === rollNo);
    },
    findByRoute(routeId) {
      return base.findAll((p) => p.routeId === routeId);
    },
  };
}

module.exports = { createPassRepository };
