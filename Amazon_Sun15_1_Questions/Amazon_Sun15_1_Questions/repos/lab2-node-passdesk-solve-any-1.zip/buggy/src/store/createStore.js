'use strict';

const { SEED_ROUTES } = require('../config/seedRoutes');
const { createIdGenerator } = require('../utils/ids');

/** One in-memory database: a Map per table plus an id generator. */
function createStore() {
  const store = {
    routes: new Map(),
    students: new Map(),
    passes: new Map(),
    receipts: new Map(),
    ids: createIdGenerator(),
  };
  for (const route of SEED_ROUTES) store.routes.set(route.id, { ...route });
  return store;
}

module.exports = { createStore };
