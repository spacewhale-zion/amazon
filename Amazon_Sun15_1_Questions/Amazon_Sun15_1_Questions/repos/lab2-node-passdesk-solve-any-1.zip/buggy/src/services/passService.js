'use strict';

const { AppError, notFound } = require('../errors/AppError');
const { validateNewPass } = require('../validators/passValidator');
const { statusOf, toView } = require('./passStatus');
const { PassStatus } = require('../domain/statuses');
const { addMonths, toDateString } = require('../utils/time');

function createPassService({ passRepository, routeRepository, receiptRepository, studentService, pricingService, ids, clock }) {
  const today = () => toDateString(clock());

  function requirePass(id) {
    const pass = passRepository.findById(id);
    if (!pass) throw notFound('Pass', id);
    return pass;
  }

  function requireOpenRoute(routeId) {
    const route = routeRepository.findById(routeId);
    if (!route) throw notFound('Route', routeId);
    if (!route.active) throw new AppError('ROUTE_CLOSED', `Route ${routeId} is not running this term`);
    return route;
  }

  function issue(body) {
    const input = validateNewPass(body || {});
    const student = studentService.requireStudent(input.rollNo);
    const route = requireOpenRoute(input.routeId);
    const now = today();

    const current = passRepository.findByStudent(student.rollNo).find((p) => statusOf(p, now) === PassStatus.ACTIVE);
    if (current) {
      throw new AppError('ACTIVE_PASS_EXISTS', `${student.rollNo} already holds active pass ${current.id}`);
    }

    const price = pricingService.quote(student, route, input.months, now);
    const pass = {
      id: ids.next('pas'),
      rollNo: student.rollNo,
      routeId: route.id,
      months: input.months,
      validFrom: now,
      validTill: addMonths(now, input.months),
      suspended: false,
      price,
      renewals: [],
    };
    const saved = passRepository.save(pass);
    receiptRepository.save({ id: ids.next('rcp'), passId: pass.id, kind: 'NEW', amount: price.total, on: now });
    return toView(saved, now);
  }

  function get(id) {
    return toView(requirePass(id), today());
  }

  function suspend(id) {
    const pass = requirePass(id);
    const now = today();
    if (statusOf(pass, now) !== PassStatus.ACTIVE) {
      throw new AppError('INVALID_STATE', `Only an ACTIVE pass can be suspended (${pass.id} is ${statusOf(pass, now)})`);
    }
    pass.suspended = true;
    return toView(passRepository.save(pass), now);
  }

  function receipts(id) {
    requirePass(id);
    return receiptRepository.findByPass(id).sort((a, b) => (a.id < b.id ? -1 : 1));
  }

  return { issue, get, suspend, receipts, requirePass, requireOpenRoute };
}

module.exports = { createPassService };
