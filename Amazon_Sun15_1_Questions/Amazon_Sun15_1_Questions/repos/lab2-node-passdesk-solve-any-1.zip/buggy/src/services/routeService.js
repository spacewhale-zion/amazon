'use strict';

const { notFound } = require('../errors/AppError');
const { statusOf } = require('./passStatus');
const { PassStatus } = require('../domain/statuses');
const { toDateString } = require('../utils/time');

function createRouteService({ routeRepository, passRepository, clock }) {
  function list() {
    return routeRepository.findActive().sort((a, b) => (a.id < b.id ? -1 : 1));
  }

  function get(id) {
    const route = routeRepository.findById(id);
    if (!route) throw notFound('Route', id);
    return route;
  }

  /** Roll numbers holding an ACTIVE pass on the route, in roll-number order. */
  function riders(id) {
    get(id);
    const now = toDateString(clock());
    return passRepository
      .findByRoute(id)
      .filter((p) => statusOf(p, now) === PassStatus.ACTIVE)
      .map((p) => p.rollNo)
      .sort();
  }

  return { list, get, riders };
}

module.exports = { createRouteService };
