'use strict';

const config = require('../config');
const { percentOf } = require('../utils/money');
const { statusOf } = require('./passStatus');
const { PassStatus } = require('../domain/statuses');

/**
 * Price of a pass (or a renewal) for `months` months on `route`:
 *   base            = monthlyFare x months
 *   termDiscount    = 5% of base for 3 months, 10% for 6 months
 *   siblingDiscount = 12.5% of (base - termDiscount) when the sibling holds an ACTIVE pass today
 *   total           = base - termDiscount - siblingDiscount
 * Every percentage is rounded half up to whole paise.
 */
function createPricingService({ passRepository }) {
  function siblingHasActivePass(student, today) {
    if (!student.siblingRollNo) return false;
    return passRepository
      .findByStudent(student.siblingRollNo)
      .some((p) => statusOf(p, today) === PassStatus.ACTIVE);
  }

  function quote(student, route, months, today) {
    const base = route.monthlyFare * months;
    const termDiscount = percentOf(base, config.TERM_DISCOUNT_BP[months]);
    const afterTerm = base - termDiscount;
    const siblingDiscount = siblingHasActivePass(student, today) ? percentOf(afterTerm, config.SIBLING_DISCOUNT_BP) : 0;
    return {
      monthlyFare: route.monthlyFare,
      months,
      base,
      termDiscount,
      siblingDiscount,
      total: afterTerm - siblingDiscount,
    };
  }

  return { quote, siblingHasActivePass };
}

module.exports = { createPricingService };
