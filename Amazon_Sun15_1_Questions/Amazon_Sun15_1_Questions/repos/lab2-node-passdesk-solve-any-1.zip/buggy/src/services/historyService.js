'use strict';

const { toView } = require('./passStatus');
const { byKeys, byIdNumber } = require('../utils/compare');
const { toDateString } = require('../utils/time');

/** A student's passes, newest first: latest validFrom first, and for the same day the higher pass number first. */
function createHistoryService({ passRepository, studentService, clock }) {
  function forStudent(rollNo) {
    studentService.requireStudent(rollNo);
    const now = toDateString(clock());
    return passRepository
      .findByStudent(rollNo)
      .sort(byKeys([(p) => p.validFrom, 'asc'], [byIdNumber, 'asc']))
      .map((p) => toView(p, now));
  }

  return { forStudent };
}

module.exports = { createHistoryService };
