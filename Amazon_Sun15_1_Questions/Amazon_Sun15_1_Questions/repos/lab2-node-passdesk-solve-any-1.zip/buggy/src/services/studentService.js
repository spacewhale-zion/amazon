'use strict';

const { AppError, notFound } = require('../errors/AppError');
const { validateNewStudent } = require('../validators/studentValidator');
const { statusOf } = require('./passStatus');
const { PassStatus } = require('../domain/statuses');
const { toDateString } = require('../utils/time');

function createStudentService({ studentRepository, passRepository, clock }) {
  function register(body) {
    const input = validateNewStudent(body || {});
    if (studentRepository.exists(input.rollNo)) {
      throw new AppError('DUPLICATE', `Student ${input.rollNo} is already registered`);
    }
    const student = { id: input.rollNo, rollNo: input.rollNo, name: input.name, siblingRollNo: input.siblingRollNo };
    return studentRepository.save(student);
  }

  function get(rollNo) {
    const student = studentRepository.findByRoll(rollNo);
    if (!student) throw notFound('Student', rollNo);
    const today = toDateString(clock());
    const active = passRepository.findByStudent(rollNo).find((p) => statusOf(p, today) === PassStatus.ACTIVE);
    return { ...student, activePassId: active ? active.id : null };
  }

  function requireStudent(rollNo) {
    const student = studentRepository.findByRoll(rollNo);
    if (!student) throw notFound('Student', rollNo);
    return student;
  }

  return { register, get, requireStudent };
}

module.exports = { createStudentService };
