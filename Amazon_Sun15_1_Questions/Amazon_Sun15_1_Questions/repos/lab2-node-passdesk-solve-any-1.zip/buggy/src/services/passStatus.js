'use strict';

const { PassStatus } = require('../domain/statuses');
const { daysBetween } = require('../utils/time');

/**
 * A pass is valid from validFrom up to (not including) validTill.
 * SUSPENDED wins over everything; otherwise it is EXPIRED from validTill on, and ACTIVE before that.
 */
function statusOf(pass, today) {
  if (pass.suspended) return PassStatus.SUSPENDED;
  if (today >= pass.validTill) return PassStatus.EXPIRED;
  return PassStatus.ACTIVE;
}

function daysLeft(pass, today) {
  return Math.max(0, daysBetween(today, pass.validTill));
}

function toView(pass, today) {
  return {
    id: pass.id,
    rollNo: pass.rollNo,
    routeId: pass.routeId,
    months: pass.months,
    validFrom: pass.validFrom,
    validTill: pass.validTill,
    status: statusOf(pass, today),
    daysLeft: daysLeft(pass, today),
    price: pass.price,
    renewals: pass.renewals,
  };
}

module.exports = { statusOf, daysLeft, toView };
