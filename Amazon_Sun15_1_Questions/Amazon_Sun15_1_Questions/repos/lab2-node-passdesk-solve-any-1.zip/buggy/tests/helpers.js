const request = require('supertest');
const { createApp } = require('../src/app');

// Monday 1 June 2026, 06:00 UTC
const NOW = '2026-06-01T06:00:00Z';

let counter = 100;

/** A fresh app with a clock the test can move: `ctx.clock.set('2026-06-24T06:00:00Z')`. */
function makeApp(start = NOW) {
  let now = new Date(start);
  const clock = { set(iso) { now = new Date(iso); } };
  const app = createApp({ clock: () => new Date(now) });
  const as = (role) => ({
    get: (url) => request(app).get(url).set('X-Role', role),
    post: (url, body) => request(app).post(url).set('X-Role', role).send(body || {}),
  });
  return { app, clock, api: as('student'), staff: as('staff') };
}

/** Registers a student and returns the roll number. Pass { siblingRollNo } to link a sibling. */
async function newStudent(ctx, extra = {}) {
  counter += 1;
  const rollNo = `22CSE${counter}`;
  const res = await ctx.api.post('/students', { rollNo, name: `Student ${counter}`, ...extra });
  if (res.status !== 201) throw new Error(`student not created: ${res.status} ${JSON.stringify(res.body)}`);
  return rollNo;
}

/** Asks for a new pass and returns the raw response (check the status yourself). */
const issue = (ctx, rollNo, routeId, months) => ctx.api.post('/passes', { rollNo, routeId, months });

/** Issues a pass and returns it; throws when the request is refused. */
async function issued(ctx, rollNo, routeId, months) {
  const res = await issue(ctx, rollNo, routeId, months);
  if (res.status !== 201) throw new Error(`pass not issued: ${res.status} ${JSON.stringify(res.body)}`);
  return res.body;
}

const renew = (ctx, passId, months) => ctx.api.post(`/passes/${passId}/renew`, { months });

/*
 * Seed routes (monthly fare in paise):
 *   R1 Ameerpet - Campus      125000
 *   R2 Secunderabad - Campus  135050
 *   R3 LB Nagar - Campus       99990
 *   R4 Kukatpally - Campus    150000
 */
module.exports = { request, makeApp, newStudent, issue, issued, renew, NOW };
