const { makeApp, newStudent, issue, issued, renew } = require('./helpers');

/**
 * These tests describe behaviour from README.md that is broken right now: every one of them FAILS on the starting
 * code. Fix the bugs in src/ until they all pass. Two hidden tests check the same rules again with other data.
 */
describe('PassDesk', () => {
  test('a 3-month pass gets 5% off, rounded half up to the paisa', async () => {
    const ctx = makeApp();
    const pass = await issued(ctx, await newStudent(ctx), 'R3', 3);
    expect(pass.price).toEqual({
      monthlyFare: 99990, months: 3, base: 299970, termDiscount: 14999, siblingDiscount: 0, total: 284971,
    });
  });

  test('a 2-month pass is a validation error', async () => {
    const ctx = makeApp();
    const res = await issue(ctx, await newStudent(ctx), 'R1', 2);
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_FAILED');
    expect(res.body.details).toEqual([{ field: 'months', issue: 'must be 1, 3 or 6' }]);
  });

  test('asking for a second pass while one is active is 409 ACTIVE_PASS_EXISTS', async () => {
    const ctx = makeApp();
    const roll = await newStudent(ctx);
    await issued(ctx, roll, 'R1', 1);
    const res = await issue(ctx, roll, 'R4', 1);
    expect(res.status).toBe(409);
    expect(res.body.error).toBe('ACTIVE_PASS_EXISTS');
  });

  test('a pass can be renewed exactly 7 days before it expires', async () => {
    const ctx = makeApp();
    const pass = await issued(ctx, await newStudent(ctx), 'R1', 1);     // valid 2026-06-01 up to 2026-07-01
    ctx.clock.set('2026-06-24T06:00:00Z');                              // 7 days left
    const res = await renew(ctx, pass.id, 1);
    expect(res.status).toBe(200);
    expect(res.body.validTill).toBe('2026-08-01');
  });

  test('a renewal is kept on the pass', async () => {
    const ctx = makeApp();
    const pass = await issued(ctx, await newStudent(ctx), 'R2', 1);     // valid up to 2026-07-01
    ctx.clock.set('2026-06-28T06:00:00Z');                              // 3 days left
    expect((await renew(ctx, pass.id, 1)).status).toBe(200);
    const read = await ctx.api.get(`/passes/${pass.id}`);
    expect(read.body.validTill).toBe('2026-08-01');
    expect(read.body.renewals).toHaveLength(1);
  });

  test("a student's passes are listed newest first", async () => {
    const ctx = makeApp();
    const roll = await newStudent(ctx);
    const first = await issued(ctx, roll, 'R1', 1);
    expect((await ctx.staff.post(`/passes/${first.id}/suspend`)).status).toBe(200);
    ctx.clock.set('2026-06-03T06:00:00Z');
    const second = await issued(ctx, roll, 'R4', 1);
    const res = await ctx.api.get(`/students/${roll}/passes`);
    expect(res.status).toBe(200);
    expect(res.body.map((p) => p.id)).toEqual([second.id, first.id]);
  });
});
