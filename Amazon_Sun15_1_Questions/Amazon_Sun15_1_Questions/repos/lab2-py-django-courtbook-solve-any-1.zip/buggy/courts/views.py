import json

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from . import services, validation
from .errors import ApiError, BadRequest
from .timefmt import parse_date
from .views_format import booking_view, court_view, member_view


def api(methods):
    """Parses the JSON body, allows only `methods`, and turns ApiError into {"error": ...}."""
    def wrap(fn):
        @csrf_exempt
        def inner(request, *args, **kwargs):
            if request.method not in methods:
                return JsonResponse({"error": "method not allowed"}, status=405)
            try:
                body = {}
                if request.method == "POST" and request.body:
                    try:
                        body = json.loads(request.body)
                    except ValueError:
                        raise BadRequest("body is not valid JSON")
                    if not isinstance(body, dict):
                        raise BadRequest("body must be a JSON object")
                return fn(request, body, *args, **kwargs)
            except ApiError as e:
                return JsonResponse({"error": e.message}, status=e.status)
        return inner
    return wrap


@api(["GET"])
def courts(request, body):
    return JsonResponse([court_view(c) for c in services.courts()], safe=False)


@api(["GET"])
def court_schedule(request, body, code):
    day = parse_date(request.GET.get("date"))
    if day is None:
        raise BadRequest("date must be YYYY-MM-DD")
    return JsonResponse([booking_view(b) for b in services.court_schedule(code, day)], safe=False)


@api(["POST"])
def members(request, body):
    member = services.add_member(validation.member_in(body))
    return JsonResponse(member_view(member), status=201)


@api(["GET"])
def member_bookings(request, body, member_id):
    return JsonResponse([booking_view(b) for b in services.member_bookings(member_id)], safe=False)


@api(["POST"])
def bookings(request, body):
    booking = services.book(validation.booking_in(body))
    return JsonResponse(booking_view(booking), status=201)


@api(["GET"])
def booking_detail(request, body, booking_id):
    return JsonResponse(booking_view(services.get_booking(booking_id)))


@api(["POST"])
def cancel(request, body, booking_id):
    return JsonResponse(booking_view(services.cancel(booking_id)))
