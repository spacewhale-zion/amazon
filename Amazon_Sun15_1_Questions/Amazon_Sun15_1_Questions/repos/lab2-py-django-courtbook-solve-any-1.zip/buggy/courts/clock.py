"""The current time for the service. Provided and read-only: the tests set it to control what is in the future."""
from datetime import datetime, timezone

_now = None


def now() -> datetime:
    return _now or datetime.now(timezone.utc)


def set_now(dt: datetime) -> None:
    global _now
    _now = dt


def reset() -> None:
    global _now
    _now = None
