import re
from datetime import date

_HHMM = re.compile(r"^([01][0-9]|2[0-3]):([0-5][0-9])$")
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def parse_hhmm(value):
    """'18:30' -> 1110 minutes, or None when the text is not HH:MM."""
    if not isinstance(value, str):
        return None
    m = _HHMM.match(value)
    return int(m.group(1)) * 60 + int(m.group(2)) if m else None


def format_hhmm(minutes: int) -> str:
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def parse_date(value):
    """'2026-06-02' -> date, or None."""
    if not isinstance(value, str) or not _DATE.match(value):
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None
