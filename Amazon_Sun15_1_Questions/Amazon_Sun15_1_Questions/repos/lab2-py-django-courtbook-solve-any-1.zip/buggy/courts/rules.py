"""Club rules in one place. Times are minutes after midnight (18:00 -> 1080)."""

OPEN_AT = 6 * 60          # 06:00
CLOSE_AT = 22 * 60        # 22:00, a booking must end by then
PEAK_FROM = 18 * 60       # bookings that START at 18:00 or later are peak
PEAK_SURCHARGE_PCT = 50   # peak bookings pay 50% more
GST_PCT = 18
SLOT_MINUTES = 30         # bookings start on :00 or :30 and last a whole number of slots
MIN_MINUTES = 30
MAX_MINUTES = 120
MAX_BOOKINGS_PER_DAY = 2  # per member, BOOKED only

SEED_COURTS = [
    # code, name, sport, rate per hour in paise
    ("C1", "Badminton Court A", "BADMINTON", 40000),
    ("C2", "Badminton Court B", "BADMINTON", 35050),
    ("S1", "Squash Court", "SQUASH", 45000),
    ("T1", "Tennis Court", "TENNIS", 60000),
]
