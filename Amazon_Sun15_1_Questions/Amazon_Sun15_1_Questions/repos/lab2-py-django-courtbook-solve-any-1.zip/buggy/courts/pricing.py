"""Price of a booking, fixed when it is made.

base  = hourly rate x minutes / 60
peak  = 50% of base when the booking STARTS at 18:00 or later, else 0
gst   = 18% of (base + peak)
total = base + peak + gst
Every percentage is rounded half up to whole paise.
"""
from . import rules
from .money import percent_of


def is_peak(start_min: int) -> bool:
    return start_min > rules.PEAK_FROM


def quote(court, start_min: int, minutes: int) -> dict:
    base = court.rate_paise * minutes // 60
    peak = percent_of(base, rules.PEAK_SURCHARGE_PCT) if is_peak(start_min) else 0
    gst = percent_of(base + peak, rules.GST_PCT)
    return {"base": base, "peak": peak, "gst": gst, "total": base + peak + gst}
