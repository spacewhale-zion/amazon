from .timefmt import format_hhmm


def court_view(c):
    return {"code": c.code, "name": c.name, "sport": c.sport, "rate_paise": c.rate_paise}


def member_view(m):
    return {"member_id": m.member_id, "name": m.name}


def booking_view(b):
    return {
        "booking_id": b.id,
        "member_id": b.member_id,
        "court": b.court_id,
        "date": b.date.isoformat(),
        "start": format_hhmm(b.start_min),
        "end": format_hhmm(b.end_min),
        "minutes": b.minutes,
        "status": b.status,
        "price": {"base": b.base_paise, "peak": b.peak_paise, "gst": b.gst_paise, "total": b.total_paise},
    }
