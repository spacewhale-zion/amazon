"""Turns request bodies into clean values or raises BadRequest. No database access here."""
import re

from . import rules
from .errors import BadRequest
from .timefmt import parse_date, parse_hhmm

_MEMBER_ID = re.compile(r"^[A-Za-z0-9-]{2,20}$")


def _whole_number(value):
    return isinstance(value, int) and not isinstance(value, bool)


def member_in(body: dict) -> dict:
    member_id = body.get("member_id")
    name = body.get("name")
    if not isinstance(member_id, str) or not _MEMBER_ID.match(member_id):
        raise BadRequest("member_id must be 2-20 letters, digits or dashes")
    if not isinstance(name, str) or not name.strip():
        raise BadRequest("name is required")
    return {"member_id": member_id, "name": name.strip()}


def booking_in(body: dict) -> dict:
    """{member_id, court, date: YYYY-MM-DD, start: HH:MM, minutes}"""
    if not isinstance(body.get("member_id"), str) or not body["member_id"]:
        raise BadRequest("member_id is required")
    if not isinstance(body.get("court"), str) or not body["court"]:
        raise BadRequest("court is required")

    day = parse_date(body.get("date"))
    if day is None:
        raise BadRequest("date must be YYYY-MM-DD")

    start = parse_hhmm(body.get("start"))
    if start is None:
        raise BadRequest("start must be HH:MM")
    if start % rules.SLOT_MINUTES != 0:
        raise BadRequest("start must be on the hour or half hour")
    if start < rules.OPEN_AT:
        raise BadRequest("the club opens at 06:00")

    minutes = body.get("minutes")
    if not _whole_number(minutes):
        raise BadRequest("minutes must be a whole number")
    if minutes % rules.SLOT_MINUTES != 0:
        raise BadRequest("minutes must be a multiple of 30")
    if minutes < rules.MIN_MINUTES:
        raise BadRequest("a booking lasts 30 to 120 minutes")
    if start + minutes > rules.CLOSE_AT:
        raise BadRequest("a booking must end by 22:00")

    return {"member_id": body["member_id"], "court": body["court"], "date": day, "start": start, "minutes": minutes}
