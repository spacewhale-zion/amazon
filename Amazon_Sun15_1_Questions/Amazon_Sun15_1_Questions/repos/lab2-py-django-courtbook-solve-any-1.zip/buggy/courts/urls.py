from django.urls import path

from . import views

urlpatterns = [
    path("courts", views.courts),
    path("courts/<str:code>/schedule", views.court_schedule),
    path("members", views.members),
    path("members/<str:member_id>/bookings", views.member_bookings),
    path("bookings", views.bookings),
    path("bookings/<int:booking_id>", views.booking_detail),
    path("bookings/<int:booking_id>/cancel", views.cancel),
]
