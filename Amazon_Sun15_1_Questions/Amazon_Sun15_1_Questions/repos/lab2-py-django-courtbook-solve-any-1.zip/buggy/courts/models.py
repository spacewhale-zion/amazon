from django.db import models


class Court(models.Model):
    code = models.CharField(max_length=4, primary_key=True)
    name = models.CharField(max_length=60)
    sport = models.CharField(max_length=20)
    rate_paise = models.IntegerField()          # per hour
    active = models.BooleanField(default=True)


class Member(models.Model):
    member_id = models.CharField(max_length=20, primary_key=True)
    name = models.CharField(max_length=80)


class Booking(models.Model):
    BOOKED = "BOOKED"
    CANCELLED = "CANCELLED"

    member = models.ForeignKey(Member, on_delete=models.CASCADE, related_name="bookings")
    court = models.ForeignKey(Court, on_delete=models.CASCADE, related_name="bookings")
    date = models.DateField()
    start_min = models.IntegerField()           # minutes after midnight
    minutes = models.IntegerField()
    status = models.CharField(max_length=10, default=BOOKED)
    base_paise = models.IntegerField()
    peak_paise = models.IntegerField()
    gst_paise = models.IntegerField()
    total_paise = models.IntegerField()

    @property
    def end_min(self):
        return self.start_min + self.minutes
