from . import rules
from .models import Court


def ensure_courts():
    """Creates the club's courts the first time they are needed. Safe to call many times."""
    if Court.objects.exists():
        return
    Court.objects.bulk_create(
        [Court(code=c, name=n, sport=s, rate_paise=r) for c, n, s, r in rules.SEED_COURTS]
    )
