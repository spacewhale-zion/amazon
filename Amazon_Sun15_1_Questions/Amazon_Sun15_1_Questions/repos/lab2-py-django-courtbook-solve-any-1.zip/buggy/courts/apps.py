from django.apps import AppConfig


class CourtsConfig(AppConfig):
    name = "courts"
    default_auto_field = "django.db.models.BigAutoField"
