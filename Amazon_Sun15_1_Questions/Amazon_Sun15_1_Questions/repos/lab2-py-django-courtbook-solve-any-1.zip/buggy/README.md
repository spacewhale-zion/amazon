# CourtBook sports club bookings (Django)

> **Repository questions: there are 3 in this test, one per tech stack (Node, Django, Spring Boot). Solve ANY ONE of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | PassDesk college bus passes | Node.js / Express |
> | 2 | CourtBook sports club bookings | Python / Django |
>
> Pick the one you are most comfortable with. Only one is counted, so finish one completely rather than
> starting both.
>
> **Every test in `tests/` fails on the starting code.** Each failing test points at a bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. When all of them pass you are almost done:
> two hidden tests run on submit, and they check **the same rules** as the visible tests (with other data), so fix
> the rule properly instead of special-casing the test values.

CourtBook runs the booking desk of a sports club: courts, members, bookings, peak pricing, GST and cancellations.
It answers JSON over HTTP.

**Your task: fix the bugs in `courts/` so the service behaves as described below.** Do not edit `tests/`.
`courts/clock.py`, `courtsite/` and `manage.py` are provided and read-only.

```
pip install -r requirements.txt
pytest            # run the tests
```

## Code map

| File | What is in it |
|---|---|
| `courts/views.py`, `courts/urls.py`, `courts/views_format.py` | HTTP layer only (no rules) |
| `courts/services.py` | the business rules: booking, overlaps, cancelling, listings |
| `courts/validation.py` | checks request bodies |
| `courts/pricing.py`, `courts/money.py` | price of a booking, percentage helper |
| `courts/rules.py`, `courts/seed.py`, `courts/models.py` | constants, seed courts, database tables |

Every request and response body is JSON. Errors are `{"error": "<message>"}` with status `400` (bad request),
`404` (not found) or `409` (conflict). Money is in **paise** (100 paise = Rs 1). Times are `HH:MM`, dates `YYYY-MM-DD`.

## Courts

| Code | Court | Rate per hour (paise) |
|---|---|---|
| C1 | Badminton Court A | 40000 |
| C2 | Badminton Court B | 35050 |
| S1 | Squash Court | 45000 |
| T1 | Tennis Court | 60000 |

## Endpoints

| Method and path | Notes |
|---|---|
| `GET /courts` | all courts, by code |
| `GET /courts/{code}/schedule?date=` | BOOKED bookings on that court and day, by start time |
| `POST /members` | `{member_id, name}` -> `201`; an existing `member_id` is `409` |
| `GET /members/{member_id}/bookings` | the member's bookings (rule 8) |
| `POST /bookings` | `{member_id, court, date, start, minutes}` -> `201` |
| `GET /bookings/{id}`, `POST /bookings/{id}/cancel` | |

Booking view: `{booking_id, member_id, court, date, start, end, minutes, status, price: {base, peak, gst, total}}`.

## Rules

### Making a booking
1. `start` is `HH:MM` on the hour or half hour, from 06:00. A booking lasts **30 to 120 minutes**, in steps of 30,
   and must end by 22:00. A booking longer than 120 minutes is `400` with
   `{"error": "a booking lasts 30 to 120 minutes"}`.
2. A booking must start in the future (`400`).
3. A court cannot be double-booked: a new booking that shares any minute with a BOOKED booking on the same court
   and day is a **conflict, `409`**. Back-to-back bookings (one ends at 10:00, the next starts at 10:00) are fine.
4. A member can hold at most 2 BOOKED bookings on one day (`409`).

### Price (fixed when the booking is made)
5. `base = hourly rate x minutes / 60`. A booking that **starts at 18:00 or later** is peak: `peak = 50% of base`,
   otherwise `peak = 0`. `gst = 18% of (base + peak)`. `total = base + peak + gst`.
6. Every percentage is **rounded half up** to whole paise (18% of 17525 = 3154.5 -> 3155).

### Cancelling
7. Only a BOOKED booking that has not started can be cancelled (`409`). Cancelling sets the status to CANCELLED
   **permanently** and frees the court at once: anyone can book that time again.

### Listings
8. `GET /members/{member_id}/bookings` lists all of the member's bookings **earliest first**: by date, then start
   time, then booking id.
