from django.urls import include, path

urlpatterns = [path("", include("courts.urls"))]
