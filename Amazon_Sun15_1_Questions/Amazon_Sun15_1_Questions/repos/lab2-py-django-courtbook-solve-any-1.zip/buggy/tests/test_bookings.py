"""Every test in this file FAILS on the starting code. Fix the bugs in courts/ until they all pass.
Two hidden tests check the same rules again with other data."""


def test_gst_is_18_percent_rounded_half_up(api):
    api.member("m1")
    b = api.booked("m1", "C2", "07:00", minutes=30)
    # base 35050 x 30 / 60 = 17525; GST 18% = 3154.5 -> 3155
    assert b["price"] == {"base": 17525, "peak": 0, "gst": 3155, "total": 20680}


def test_a_booking_starting_exactly_at_18_00_is_peak(api):
    api.member("m1")
    b = api.booked("m1", "C1", "18:00", minutes=60)
    assert b["price"] == {"base": 40000, "peak": 20000, "gst": 10800, "total": 70800}


def test_a_booking_longer_than_120_minutes_is_a_validation_error(api):
    api.member("m1")
    r = api.book("m1", "T1", "08:00", minutes=150)
    assert r.status_code == 400
    assert r.json() == {"error": "a booking lasts 30 to 120 minutes"}


def test_an_overlapping_booking_on_the_same_court_is_409(api):
    api.member("m1")
    api.member("m2")
    api.booked("m1", "S1", "09:00", minutes=60)
    r = api.book("m2", "S1", "09:30", minutes=60)
    assert r.status_code == 409


def test_a_cancelled_booking_frees_the_court(api):
    api.member("m1")
    api.member("m2")
    b = api.booked("m1", "C1", "10:00", minutes=60)
    assert api.cancel(b["booking_id"]).status_code == 200
    r = api.book("m2", "C1", "10:00", minutes=60)
    assert r.status_code == 201


def test_member_bookings_are_listed_by_date_then_start_time(api):
    api.member("m1")
    evening = api.booked("m1", "C1", "19:00", minutes=60)
    morning = api.booked("m1", "T1", "07:00", minutes=60)
    r = api.get("/members/m1/bookings")
    assert r.status_code == 200
    assert [b["booking_id"] for b in r.json()] == [morning["booking_id"], evening["booking_id"]]
