import os

import django

# the runner's pytest config names no settings module, so load Django here, before any test imports a model
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "courtsite.settings")
django.setup()

import json  # noqa: E402
from datetime import datetime, timezone  # noqa: E402

import pytest  # noqa: E402

from courts import clock  # noqa: E402

# Monday 1 June 2026, 06:00 UTC
START = datetime(2026, 6, 1, 6, 0, tzinfo=timezone.utc)


@pytest.fixture(autouse=True)
def clean_state(db):
    clock.set_now(START)
    yield
    clock.reset()


@pytest.fixture
def api(client):
    class Api:
        def get(self, url):
            return client.get(url)

        def post(self, url, body=None):
            return client.post(url, data=json.dumps(body if body is not None else {}),
                               content_type="application/json")

        def member(self, member_id="m1", name=None):
            r = self.post("/members", {"member_id": member_id, "name": name or member_id.upper()})
            assert r.status_code == 201, r.content
            return member_id

        def book(self, member_id, court, start, minutes=60, date="2026-06-02"):
            return self.post("/bookings", {"member_id": member_id, "court": court, "date": date,
                                           "start": start, "minutes": minutes})

        def booked(self, member_id, court, start, minutes=60, date="2026-06-02"):
            r = self.book(member_id, court, start, minutes, date)
            assert r.status_code == 201, r.content
            return r.json()

        def cancel(self, booking_id):
            return self.post(f"/bookings/{booking_id}/cancel")

    return Api()

# Courts (rate per hour in paise): C1 Badminton A 40000, C2 Badminton B 35050, S1 Squash 45000, T1 Tennis 60000
