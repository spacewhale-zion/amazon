"""Business rules. Views call these; nothing here knows about HTTP."""
from datetime import datetime, timezone

from . import clock, pricing, rules
from .errors import BadRequest, Conflict, NotFound
from .models import Booking, Court, Member
from .seed import ensure_courts


def courts():
    ensure_courts()
    return list(Court.objects.filter(active=True).order_by("code"))


def get_court(code):
    ensure_courts()
    court = Court.objects.filter(code=code).first()
    if court is None:
        raise NotFound(f"court {code} not found")
    return court


def add_member(data):
    if Member.objects.filter(member_id=data["member_id"]).exists():
        raise Conflict(f"member {data['member_id']} already exists")
    return Member.objects.create(**data)


def get_member(member_id):
    member = Member.objects.filter(member_id=member_id).first()
    if member is None:
        raise NotFound(f"member {member_id} not found")
    return member


def _starts_at(day, start_min):
    return datetime(day.year, day.month, day.day, start_min // 60, start_min % 60, tzinfo=timezone.utc)


def _overlapping(court, day, start, end):
    """BOOKED bookings on this court and day that share at least one minute with [start, end)."""
    return [
        b for b in Booking.objects.filter(court=court, date=day, status=Booking.BOOKED)
        if b.start_min < end and start < b.end_min
    ]


def book(data):
    member = get_member(data["member_id"])
    court = get_court(data["court"])
    if not court.active:
        raise Conflict(f"court {court.code} is closed")
    start, minutes, day = data["start"], data["minutes"], data["date"]

    if _starts_at(day, start) <= clock.now():
        raise BadRequest("a booking must start in the future")
    if _overlapping(court, day, start, start + minutes):
        raise Conflict(f"court {court.code} is already booked at that time")
    if Booking.objects.filter(member=member, date=day, status=Booking.BOOKED).count() >= rules.MAX_BOOKINGS_PER_DAY:
        raise Conflict("a member can hold at most 2 bookings a day")

    price = pricing.quote(court, start, minutes)
    return Booking.objects.create(
        member=member, court=court, date=day, start_min=start, minutes=minutes,
        base_paise=price["base"], peak_paise=price["peak"], gst_paise=price["gst"], total_paise=price["total"],
    )


def get_booking(booking_id):
    booking = Booking.objects.filter(id=booking_id).first()
    if booking is None:
        raise NotFound(f"booking {booking_id} not found")
    return booking


def cancel(booking_id):
    booking = get_booking(booking_id)
    if booking.status != Booking.BOOKED:
        raise Conflict("only a BOOKED booking can be cancelled")
    if _starts_at(booking.date, booking.start_min) <= clock.now():
        raise Conflict("a booking that has started cannot be cancelled")
    booking.status = Booking.CANCELLED
    booking.save(update_fields=["status"])
    return booking


def member_bookings(member_id):
    """All of a member's bookings, earliest first: by date, then start time, then booking id."""
    member = get_member(member_id)
    return list(member.bookings.order_by("date", "start_min", "id"))


def court_schedule(code, day):
    """BOOKED bookings on one court and day, in start-time order."""
    court = get_court(code)
    return list(Booking.objects.filter(court=court, date=day, status=Booking.BOOKED).order_by("start_min"))
