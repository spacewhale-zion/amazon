def percent_of(amount: int, pct: int) -> int:
    """pct% of an amount in paise, rounded half up to whole paise: percent_of(17525, 18) == 3155 (3154.5)."""
    return (amount * pct + 50) // 100


def rupees(paise: int) -> str:
    return f"Rs {paise / 100:.2f}"
