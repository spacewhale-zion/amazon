def test_peak_surcharge_and_gst_are_rounded_half_up(api):
    api.member("h1")
    b = api.booked("h1", "C2", "19:00", minutes=90)
    # base 52575; peak 50% = 26287.5 -> 26288; GST 18% of 78863 = 14195.34 -> 14195
    assert b["price"] == {"base": 52575, "peak": 26288, "gst": 14195, "total": 93058}


def test_peak_starts_at_18_00_not_after(api):
    api.member("h1")
    before = api.booked("h1", "S1", "17:30", minutes=60)
    at_six = api.booked("h1", "T1", "18:00", minutes=30)
    assert before["price"]["peak"] == 0
    assert at_six["price"] == {"base": 30000, "peak": 15000, "gst": 8100, "total": 53100}
