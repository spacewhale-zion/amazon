# Planted bugs (author only, never shown to students)

CourtBook sports club bookings (Django).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Tracker | Kind | Symptom | File | Fixed code | Buggy code | Visible test | Hidden test |
|---|---|---|---|---|---|---|---|---|
| 1 | RP-07 | Rounding | Percentages are truncated instead of rounded half up | `courts/money.py` | `return (amount * pct + 50) // 100` | `return amount * pct // 100` | test_gst_is_18_percent_rounded_half_up | test_peak_surcharge_and_gst_are_rounded_half_up |
| 2 | RP-06 | Boundary (> vs >=) | A booking starting exactly at 18:00 is not charged as peak | `courts/pricing.py` | `return start_min >= rules.PEAK_FROM` | `return start_min > rules.PEAK_FROM` | test_a_booking_starting_exactly_at_18_00_is_peak | test_peak_starts_at_18_00_not_after |
| 3 | RP-05 | Missing validation | Bookings longer than 120 minutes are accepted | `courts/validation.py` | `if minutes < rules.MIN_MINUTES or minutes > rules.MAX_MINUTES:` | `if minutes < rules.MIN_MINUTES:` | test_a_booking_longer_than_120_minutes_is_a_validation_error | none |
| 4 | RP-03 | Wrong status code | An overlapping booking is 400 instead of 409 | `courts/services.py` | `raise Conflict(f"court {court.code} is already booked at that time")` | `raise BadRequest(f"court {court.code} is already booked at that time")` | test_an_overlapping_booking_on_the_same_court_is_409 | none |
| 5 | RP-04 | Change never saved | Cancelling never saves the new status, so the court stays blocked | `courts/services.py` | `booking.status = Booking.CANCELLED     booking.save(update_fields=["status"])` | `booking.status = Booking.CANCELLED (save line removed)` | test_a_cancelled_booking_frees_the_court | none |
| 6 | RP-08 | Wrong sort order | A member's bookings ignore the start time when sorting | `courts/services.py` | `return list(member.bookings.order_by("date", "start_min", "id"))` | `return list(member.bookings.order_by("date", "id"))` | test_member_bookings_are_listed_by_date_then_start_time | none |
