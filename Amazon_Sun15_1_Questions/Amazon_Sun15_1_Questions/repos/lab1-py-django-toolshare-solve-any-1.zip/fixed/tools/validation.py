"""Turns request bodies into clean values or raises BadRequest. No database access here."""
import re

from . import rules
from .errors import BadRequest

_CODE = re.compile(r"^[A-Z]{2,4}-[0-9]{2,4}$")
_FLAT = re.compile(r"^[A-D]-[0-9]{3}$")


def _whole_number(value):
    return isinstance(value, int) and not isinstance(value, bool)


def tool_in(body):
    code, name, deposit = body.get("code"), body.get("name"), body.get("deposit_paise")
    if not isinstance(code, str) or not _CODE.match(code):
        raise BadRequest("code must look like DRL-01")
    if not isinstance(name, str) or not name.strip():
        raise BadRequest("name is required")
    if not _whole_number(deposit) or deposit < 0:
        raise BadRequest("deposit_paise must be a whole number of paise, 0 or more")
    return {"code": code, "name": name.strip(), "deposit_paise": deposit}


def resident_in(body):
    flat, name = body.get("flat"), body.get("name")
    if not isinstance(flat, str) or not _FLAT.match(flat):
        raise BadRequest("flat must look like B-204")
    if not isinstance(name, str) or not name.strip():
        raise BadRequest("name is required")
    return {"flat": flat, "name": name.strip()}


def lend_in(body):
    tool, flat, days = body.get("tool"), body.get("flat"), body.get("days")
    if not isinstance(tool, str) or not tool:
        raise BadRequest("tool is required")
    if not isinstance(flat, str) or not flat:
        raise BadRequest("flat is required")
    if not _whole_number(days):
        raise BadRequest("days must be a whole number")
    if days < rules.MIN_DAYS or days > rules.MAX_DAYS:
        raise BadRequest("days must be 1 to 7")
    return {"tool": tool, "flat": flat, "days": days}
