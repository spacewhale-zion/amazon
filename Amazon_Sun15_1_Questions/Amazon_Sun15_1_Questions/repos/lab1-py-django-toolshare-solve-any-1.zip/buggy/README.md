# ToolShare society tool library (Django)

> **Repository questions: there are 3 in this lab, one per tech stack (Node, Django, Spring Boot). Solve ANY ONE of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | DonorDesk blood donation camps | Node.js / Express |
> | 2 | ToolShare society tool library | Python / Django |
>
> **Every test in `tests/` fails on the starting code.** Each failing test points at one bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. One hidden test runs on submit and checks
> **the same rules** with other data, so fix the rule properly instead of special-casing the test values.

ToolShare lets the flats of an apartment society share tools: a drill, a ladder, a saw... It answers JSON over HTTP.

**Your task: fix the 3 bugs in `tools/` so the service behaves as described below.** Do not edit `tests/`.
`tools/clock.py`, `toolsite/` and `manage.py` are provided and read-only.

```
pip install -r requirements.txt
pytest            # run the tests
```

## How to work (the method you will use in the real test)
1. Run the tests. Read **one** failing test: what request does it send, and what status / body does it expect?
2. Find the view in `tools/urls.py` and `tools/views.py`, then follow it into `tools/services.py` and `tools/validation.py`.
3. Compare the code with the rule below. Make the **smallest** change that follows the rule.
4. Run **all** the tests again. Then move to the next failing test.

Errors are `{"error": "<message>"}` with status `400` (bad request), `404` (not found) or `409` (conflict).

## Endpoints

| Method and path | Notes |
|---|---|
| `POST /tools`, `GET /tools`, `GET /tools/{code}` | `{code, name, deposit_paise}`; `?available=true` keeps tools on the shelf |
| `POST /residents` | `{flat, name}` |
| `GET /residents/{flat}/lends` | tools the flat still holds |
| `POST /lends` | `{tool, flat, days}` -> `201` |
| `POST /lends/{lend_id}/return` | -> `200` |

## Rules
1. `days` must be a whole number from **1 to 7**. Anything else is `400` with `{"error": "days must be 1 to 7"}`.
2. A tool that is already lent out cannot be lent again: that is a **conflict, `409`**.
3. A flat can hold at most 2 tools at once (`409`).
4. Returning a tool puts it back on the shelf **permanently**: `GET /tools/{code}` shows `"available": true` and
   another flat can borrow it.
