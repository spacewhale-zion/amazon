"""Every test in this file FAILS on the starting code. Fix the bugs in tools/ until they all pass.
One hidden test checks the same rules again with other data."""


def test_borrowing_a_tool_that_is_already_lent_is_409(api):
    api.tool("DRL-01")
    api.resident("A-101")
    api.resident("B-204")
    assert api.lend("DRL-01", "A-101").status_code == 201
    assert api.lend("DRL-01", "B-204").status_code == 409


def test_a_returned_tool_can_be_borrowed_again(api):
    api.tool("LAD-02", "Ladder")
    api.resident("A-101")
    api.resident("C-310")
    lend = api.lend("LAD-02", "A-101").json()
    assert api.post(f"/lends/{lend['lend_id']}/return").status_code == 200
    assert api.get("/tools/LAD-02").json()["available"] is True
    assert api.lend("LAD-02", "C-310").status_code == 201


def test_lending_for_more_than_7_days_is_a_validation_error(api):
    api.tool("SAW-03", "Hand saw")
    api.resident("A-101")
    r = api.lend("SAW-03", "A-101", days=10)
    assert r.status_code == 400
    assert r.json() == {"error": "days must be 1 to 7"}
