import os

import django

# the runner's pytest config names no settings module, so load Django here, before any test imports a model
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "toolsite.settings")
django.setup()

import json  # noqa: E402
from datetime import date  # noqa: E402

import pytest  # noqa: E402

from tools import clock  # noqa: E402

START = date(2026, 6, 1)


@pytest.fixture(autouse=True)
def clean_state(db):
    clock.set_today(START)
    yield
    clock.reset()


@pytest.fixture
def api(client):
    class Api:
        def get(self, url):
            return client.get(url)

        def post(self, url, body=None):
            return client.post(url, data=json.dumps(body if body is not None else {}),
                               content_type="application/json")

        def tool(self, code="DRL-01", name="Power drill", deposit_paise=50000):
            r = self.post("/tools", {"code": code, "name": name, "deposit_paise": deposit_paise})
            assert r.status_code == 201, r.content
            return code

        def resident(self, flat="A-101", name=None):
            r = self.post("/residents", {"flat": flat, "name": name or f"Resident {flat}"})
            assert r.status_code == 201, r.content
            return flat

        def lend(self, tool, flat, days=3):
            return self.post("/lends", {"tool": tool, "flat": flat, "days": days})

    return Api()
