class ApiError(Exception):
    """Raised by the services and validation; the views turn it into {"error": message} with this status."""

    status = 400

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class BadRequest(ApiError):
    status = 400


class NotFound(ApiError):
    status = 404


class Conflict(ApiError):
    status = 409
