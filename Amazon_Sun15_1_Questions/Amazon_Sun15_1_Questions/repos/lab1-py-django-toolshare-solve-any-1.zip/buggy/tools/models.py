from django.db import models


class Tool(models.Model):
    code = models.CharField(max_length=12, primary_key=True)
    name = models.CharField(max_length=80)
    deposit_paise = models.IntegerField()
    available = models.BooleanField(default=True)


class Resident(models.Model):
    flat = models.CharField(max_length=8, primary_key=True)
    name = models.CharField(max_length=80)


class Lend(models.Model):
    tool = models.ForeignKey(Tool, on_delete=models.CASCADE, related_name="lends")
    resident = models.ForeignKey(Resident, on_delete=models.CASCADE, related_name="lends")
    lent_on = models.DateField()
    due_on = models.DateField()
    returned_on = models.DateField(null=True)
