"""Business rules. Views call these; nothing here knows about HTTP."""
from datetime import timedelta

from . import clock, rules
from .errors import BadRequest, Conflict, NotFound  # noqa: F401
from .models import Lend, Resident, Tool


def add_tool(data):
    if Tool.objects.filter(code=data["code"]).exists():
        raise Conflict(f"tool {data['code']} already exists")
    return Tool.objects.create(**data)


def get_tool(code):
    tool = Tool.objects.filter(code=code).first()
    if tool is None:
        raise NotFound(f"tool {code} not found")
    return tool


def list_tools(only_available=False):
    qs = Tool.objects.all().order_by("code")
    return list(qs.filter(available=True) if only_available else qs)


def add_resident(data):
    if Resident.objects.filter(flat=data["flat"]).exists():
        raise Conflict(f"flat {data['flat']} is already registered")
    return Resident.objects.create(**data)


def get_resident(flat):
    resident = Resident.objects.filter(flat=flat).first()
    if resident is None:
        raise NotFound(f"flat {flat} not found")
    return resident


def open_lends(resident):
    return resident.lends.filter(returned_on__isnull=True)


def lend(data):
    tool = get_tool(data["tool"])
    resident = get_resident(data["flat"])
    if not tool.available:
        raise BadRequest(f"{tool.name} is already lent out")
    if open_lends(resident).count() >= rules.MAX_OPEN_LENDS:
        raise Conflict("a flat can hold at most 2 tools at once")
    today = clock.today()
    record = Lend.objects.create(tool=tool, resident=resident, lent_on=today, due_on=today + timedelta(days=data["days"]))
    tool.available = False
    tool.save(update_fields=["available"])
    return record


def return_tool(lend_id):
    record = Lend.objects.filter(id=lend_id).select_related("tool").first()
    if record is None:
        raise NotFound(f"lend {lend_id} not found")
    if record.returned_on is not None:
        raise Conflict("this tool was already returned")
    record.returned_on = clock.today()
    record.save(update_fields=["returned_on"])
    tool = record.tool
    tool.available = True
    return record
