from django.urls import path

from . import views

urlpatterns = [
    path("tools", views.tools),
    path("tools/<str:code>", views.tool_detail),
    path("residents", views.residents),
    path("residents/<str:flat>/lends", views.resident_lends),
    path("lends", views.lends),
    path("lends/<int:lend_id>/return", views.return_lend),
]
