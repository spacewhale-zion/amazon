MIN_DAYS = 1
MAX_DAYS = 7
MAX_OPEN_LENDS = 2      # tools a flat can hold at once
