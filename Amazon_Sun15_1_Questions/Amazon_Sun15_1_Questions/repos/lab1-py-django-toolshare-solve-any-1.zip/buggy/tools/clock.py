"""Today's date for the service. Provided and read-only: the tests set it to control due dates."""
from datetime import date

_today = None


def today() -> date:
    return _today or date.today()


def set_today(d: date) -> None:
    global _today
    _today = d


def reset() -> None:
    global _today
    _today = None
