import json

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from . import services, validation
from .errors import ApiError, BadRequest


def api(methods):
    """Parses the JSON body, allows only `methods`, and turns ApiError into {"error": ...}."""
    def wrap(fn):
        @csrf_exempt
        def inner(request, *args, **kwargs):
            if request.method not in methods:
                return JsonResponse({"error": "method not allowed"}, status=405)
            try:
                body = {}
                if request.method == "POST" and request.body:
                    try:
                        body = json.loads(request.body)
                    except ValueError:
                        raise BadRequest("body is not valid JSON")
                    if not isinstance(body, dict):
                        raise BadRequest("body must be a JSON object")
                return fn(request, body, *args, **kwargs)
            except ApiError as e:
                return JsonResponse({"error": e.message}, status=e.status)
        return inner
    return wrap


def tool_view(t):
    return {"code": t.code, "name": t.name, "deposit_paise": t.deposit_paise, "available": t.available}


def lend_view(r):
    return {"lend_id": r.id, "tool": r.tool_id, "flat": r.resident_id, "lent_on": r.lent_on.isoformat(),
            "due_on": r.due_on.isoformat(), "returned_on": r.returned_on.isoformat() if r.returned_on else None}


@api(["GET", "POST"])
def tools(request, body):
    if request.method == "POST":
        return JsonResponse(tool_view(services.add_tool(validation.tool_in(body))), status=201)
    only = request.GET.get("available") == "true"
    return JsonResponse([tool_view(t) for t in services.list_tools(only)], safe=False)


@api(["GET"])
def tool_detail(request, body, code):
    return JsonResponse(tool_view(services.get_tool(code)))


@api(["POST"])
def residents(request, body):
    r = services.add_resident(validation.resident_in(body))
    return JsonResponse({"flat": r.flat, "name": r.name}, status=201)


@api(["GET"])
def resident_lends(request, body, flat):
    resident = services.get_resident(flat)
    return JsonResponse([lend_view(r) for r in services.open_lends(resident).order_by("due_on", "id")], safe=False)


@api(["POST"])
def lends(request, body):
    return JsonResponse(lend_view(services.lend(validation.lend_in(body))), status=201)


@api(["POST"])
def return_lend(request, body, lend_id):
    return JsonResponse(lend_view(services.return_tool(lend_id)))
