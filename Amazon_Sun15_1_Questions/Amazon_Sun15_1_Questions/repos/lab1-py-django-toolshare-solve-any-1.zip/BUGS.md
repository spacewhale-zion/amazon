# Planted bugs (author only, never shown to students)

ToolShare society tool library (Django).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Tracker | Kind | Symptom | File | Fixed code | Buggy code | Visible test | Hidden test |
|---|---|---|---|---|---|---|---|---|
| 1 | RP-03 | Wrong status code | Borrowing a tool that is out is 400 instead of 409 | `tools/services.py` | `raise Conflict(f"{tool.name} is already lent out")` | `raise BadRequest(f"{tool.name} is already lent out")` | test_borrowing_a_tool_that_is_already_lent_is_409 | none |
| 2 | RP-04 | Change never saved | Returning a tool never saves available = True | `tools/services.py` | `tool.available = True     tool.save(update_fields=["available"])` | `tool.available = True (save line removed)` | test_a_returned_tool_can_be_borrowed_again | none |
| 3 | RP-05 | Missing validation | Lends longer than 7 days are accepted | `tools/validation.py` | `if days < rules.MIN_DAYS or days > rules.MAX_DAYS:` | `if days < rules.MIN_DAYS:` | test_lending_for_more_than_7_days_is_a_validation_error | test_days_must_be_1_to_7 |
