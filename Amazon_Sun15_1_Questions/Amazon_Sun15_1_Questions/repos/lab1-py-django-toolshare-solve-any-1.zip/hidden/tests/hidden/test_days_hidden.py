def test_days_must_be_1_to_7(api):
    api.tool("VAC-04", "Vacuum cleaner")
    api.resident("D-402")
    assert api.lend("VAC-04", "D-402", days=8).status_code == 400
    assert api.lend("VAC-04", "D-402", days=7).status_code == 201
