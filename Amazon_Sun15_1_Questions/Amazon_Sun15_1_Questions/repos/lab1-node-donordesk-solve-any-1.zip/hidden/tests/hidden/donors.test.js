const { makeApp, donorBody } = require('../helpers');

describe('hidden: donors', () => {
  test('age must be 18 to 65: 65 is accepted, 70 is refused', async () => {
    const ctx = makeApp();
    expect((await ctx.api.post('/donors', donorBody({ age: 65 }))).status).toBe(201);
    const old = await ctx.api.post('/donors', donorBody({ age: 70 }));
    expect(old.status).toBe(400);
    expect(old.body.error).toBe('VALIDATION_FAILED');
  });
});
