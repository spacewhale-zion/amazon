const request = require('supertest');
const { createApp } = require('../src/app');

const NOW = '2026-06-01T06:00:00Z';
let counter = 0;

function makeApp(start = NOW) {
  let now = new Date(start);
  const clock = { set(iso) { now = new Date(iso); } };
  const app = createApp({ clock: () => new Date(now) });
  const as = (role) => ({
    get: (url) => request(app).get(url).set('X-Role', role),
    post: (url, body) => request(app).post(url).set('X-Role', role).send(body || {}),
    patch: (url, body) => request(app).patch(url).set('X-Role', role).send(body || {}),
  });
  return { app, clock, api: as('donor'), staff: as('staff') };
}

/** A valid donor body; override any field. */
function donorBody(extra = {}) {
  counter += 1;
  return { name: `Donor ${counter}`, phone: `98${String(76500000 + counter)}`, bloodGroup: 'O+', age: 30, weightKg: 62, ...extra };
}

async function newDonor(ctx, extra = {}) {
  const res = await ctx.api.post('/donors', donorBody(extra));
  if (res.status !== 201) throw new Error(`donor not created: ${res.status} ${JSON.stringify(res.body)}`);
  return res.body;
}

module.exports = { request, makeApp, donorBody, newDonor, NOW };
