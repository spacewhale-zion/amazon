const { makeApp, donorBody, newDonor } = require('./helpers');

/**
 * Every test here FAILS on the starting code. Fix the bugs in src/ until they all pass.
 * One hidden test checks the same rules again with other data.
 */
describe('DonorDesk', () => {
  test('registering a phone number that is already used is 409 DUPLICATE', async () => {
    const ctx = makeApp();
    const first = await newDonor(ctx);
    const res = await ctx.api.post('/donors', donorBody({ phone: first.phone }));
    expect(res.status).toBe(409);
    expect(res.body.error).toBe('DUPLICATE');
  });

  test("a staff correction to a donor's weight is saved", async () => {
    const ctx = makeApp();
    const donor = await newDonor(ctx, { weightKg: 55 });
    expect((await ctx.staff.patch(`/donors/${donor.id}`, { weightKg: 58 })).status).toBe(200);
    const read = await ctx.api.get(`/donors/${donor.id}`);
    expect(read.body.weightKg).toBe(58);
  });

  test('a donor older than 65 is a validation error', async () => {
    const ctx = makeApp();
    const res = await ctx.api.post('/donors', donorBody({ age: 66 }));
    expect(res.status).toBe(400);
    expect(res.body.details).toEqual([{ field: 'age', issue: 'must be 18 to 65' }]);
  });
});
