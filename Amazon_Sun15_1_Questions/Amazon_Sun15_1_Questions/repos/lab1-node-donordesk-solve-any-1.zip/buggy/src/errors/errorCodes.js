'use strict';

/** Every error the API can return, with its HTTP status. Must match the table in README.md. */
const ERROR_CODES = Object.freeze({
  VALIDATION_FAILED: 400,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  DUPLICATE: 409,
  TOO_SOON: 409,
  CAMP_FULL: 409,
  LOW_HEMOGLOBIN: 422,
});

function statusFor(code) {
  return ERROR_CODES[code] || 500;
}

module.exports = { ERROR_CODES, statusFor };
