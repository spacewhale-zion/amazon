'use strict';

const config = require('../config');
const { createChecker, isNonEmptyString } = require('./common');

function checkAge(check, age) {
  check.require(Number.isInteger(age) && age >= config.MIN_AGE, 'age', 'must be 18 to 65');
}

function checkWeight(check, weightKg) {
  check.require(typeof weightKg === 'number' && weightKg >= config.MIN_WEIGHT_KG, 'weightKg', 'must be at least 50');
}

function checkPhone(check, phone) {
  check.require(typeof phone === 'string' && config.PHONE_PATTERN.test(phone), 'phone', 'must be a 10-digit mobile number');
}

/** Body of POST /donors: { name, phone, bloodGroup, age, weightKg } */
function validateNewDonor(body) {
  const check = createChecker();
  check.require(isNonEmptyString(body.name), 'name', 'is required');
  checkPhone(check, body.phone);
  check.require(config.BLOOD_GROUPS.includes(body.bloodGroup), 'bloodGroup', 'must be one of A+, A-, B+, B-, AB+, AB-, O+, O-');
  checkAge(check, body.age);
  checkWeight(check, body.weightKg);
  check.throwIfAny();
  return { name: body.name.trim(), phone: body.phone, bloodGroup: body.bloodGroup, age: body.age, weightKg: body.weightKg };
}

/** Body of PATCH /donors/:id: any of { phone, weightKg } */
function validateDonorPatch(body) {
  const check = createChecker();
  const patch = {};
  if (body.phone !== undefined) { checkPhone(check, body.phone); patch.phone = body.phone; }
  if (body.weightKg !== undefined) { checkWeight(check, body.weightKg); patch.weightKg = body.weightKg; }
  check.require(Object.keys(patch).length > 0, 'body', 'send phone and/or weightKg');
  check.throwIfAny();
  return patch;
}

/** Body of POST /donations: { donorId, campId, hemoglobin } */
function validateDonation(body) {
  const check = createChecker();
  check.require(isNonEmptyString(body.donorId), 'donorId', 'is required');
  check.require(isNonEmptyString(body.campId), 'campId', 'is required');
  check.require(typeof body.hemoglobin === 'number' && body.hemoglobin > 0 && body.hemoglobin < 25, 'hemoglobin', 'must be a reading in g/dL');
  check.throwIfAny();
  return { donorId: body.donorId, campId: body.campId, hemoglobin: body.hemoglobin };
}

module.exports = { validateNewDonor, validateDonorPatch, validateDonation };
