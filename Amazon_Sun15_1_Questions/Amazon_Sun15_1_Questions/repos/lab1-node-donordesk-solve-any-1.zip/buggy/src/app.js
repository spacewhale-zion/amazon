'use strict';

const express = require('express');
const { createStore } = require('./store/createStore');
const { createContainer } = require('./container');
const { mountRoutes } = require('./routes');
const { errorHandler, notFoundRoute } = require('./errors/errorHandler');

/**
 * Builds one independent app with its own in-memory data (seed camps included).
 * @param {{ clock?: () => Date }} [options] clock defaults to real time; tests pass a movable clock
 */
function createApp(options = {}) {
  const clock = options.clock || (() => new Date());
  const store = createStore();
  const container = createContainer(store, clock);
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '100kb' }));
  mountRoutes(app, container);
  app.use(notFoundRoute);
  app.use(errorHandler);
  app.locals.container = container;
  return app;
}

module.exports = { createApp };
