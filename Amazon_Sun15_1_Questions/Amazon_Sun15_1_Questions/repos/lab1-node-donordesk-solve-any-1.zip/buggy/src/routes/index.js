'use strict';

const { asyncHandler } = require('../middleware/asyncHandler');
const { requireStaff } = require('../middleware/requireRole');

/** HTTP layer only: every rule lives in src/services. */
function mountRoutes(app, c) {
  app.get('/camps', asyncHandler((req, res) => res.json(c.campService.list())));
  app.get('/camps/:id', asyncHandler((req, res) => res.json(c.campService.get(req.params.id))));

  app.post('/donors', asyncHandler((req, res) => res.status(201).json(c.donorService.register(req.body))));
  app.get('/donors/:id', asyncHandler((req, res) => res.json(c.donorService.get(req.params.id))));
  app.patch('/donors/:id', requireStaff, asyncHandler((req, res) => res.json(c.donorService.update(req.params.id, req.body))));

  app.post('/donations', requireStaff, asyncHandler((req, res) => res.status(201).json(c.donationService.donate(req.body))));
}

module.exports = { mountRoutes };
