'use strict';

const { SEED_CAMPS } = require('../config/seedCamps');
const { createIdGenerator } = require('../utils/ids');

/** One in-memory database: a Map per table plus an id generator. */
function createStore() {
  const store = { camps: new Map(), donors: new Map(), donations: new Map(), ids: createIdGenerator() };
  for (const camp of SEED_CAMPS) store.camps.set(camp.id, { ...camp });
  return store;
}

module.exports = { createStore };
