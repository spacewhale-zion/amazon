'use strict';

const { AppError } = require('../errors/AppError');

/** Staff-only routes need the header X-Role: staff (or admin). */
function requireStaff(req, res, next) {
  const role = String(req.get('X-Role') || '').toLowerCase();
  if (role === 'staff' || role === 'admin') return next();
  return next(new AppError('FORBIDDEN', 'Only blood bank staff can do this'));
}

module.exports = { requireStaff };
