'use strict';

const { createBaseRepository } = require('./baseRepository');

function createCampRepository(store) {
  return createBaseRepository(store.camps);
}

module.exports = { createCampRepository };
