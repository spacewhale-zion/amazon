'use strict';

const { createBaseRepository } = require('./baseRepository');

function createDonorRepository(store) {
  const base = createBaseRepository(store.donors);
  return {
    ...base,
    findByPhone(phone) {
      return base.findAll((d) => d.phone === phone)[0] || null;
    },
  };
}

module.exports = { createDonorRepository };
