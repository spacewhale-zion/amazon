'use strict';

const { createBaseRepository } = require('./baseRepository');

function createDonationRepository(store) {
  const base = createBaseRepository(store.donations);
  return {
    ...base,
    findByDonor(donorId) {
      return base.findAll((d) => d.donorId === donorId);
    },
    findByCamp(campId) {
      return base.findAll((d) => d.campId === campId);
    },
  };
}

module.exports = { createDonationRepository };
