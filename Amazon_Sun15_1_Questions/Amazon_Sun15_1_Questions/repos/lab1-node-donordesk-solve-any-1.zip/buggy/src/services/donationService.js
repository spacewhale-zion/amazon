'use strict';

const config = require('../config');
const { AppError } = require('../errors/AppError');
const { validateDonation } = require('../validators/donorValidator');
const { daysBetween } = require('../utils/time');

/** A donation is taken at a camp, on the camp's date. */
function createDonationService({ donationRepository, donorRepository, donorService, campService, ids }) {
  function donate(body) {
    const input = validateDonation(body || {});
    const donor = donorService.requireDonor(input.donorId);
    const camp = campService.requireCamp(input.campId);

    if (input.hemoglobin < config.MIN_HEMOGLOBIN) {
      throw new AppError('LOW_HEMOGLOBIN', `Hemoglobin must be at least ${config.MIN_HEMOGLOBIN} g/dL`);
    }
    if (donor.lastDonationOn && daysBetween(donor.lastDonationOn, camp.date) < config.DAYS_BETWEEN_DONATIONS) {
      throw new AppError('TOO_SOON', `Wait ${config.DAYS_BETWEEN_DONATIONS} days between donations`);
    }
    if (donationRepository.findByCamp(camp.id).length >= camp.capacity) {
      throw new AppError('CAMP_FULL', `${camp.name} is full`);
    }

    const donation = { id: ids.next('don'), donorId: donor.id, campId: camp.id, on: camp.date, hemoglobin: input.hemoglobin };
    donationRepository.save(donation);
    donorRepository.save({ ...donor, lastDonationOn: camp.date, donations: donor.donations + 1 });
    return donation;
  }

  return { donate };
}

module.exports = { createDonationService };
