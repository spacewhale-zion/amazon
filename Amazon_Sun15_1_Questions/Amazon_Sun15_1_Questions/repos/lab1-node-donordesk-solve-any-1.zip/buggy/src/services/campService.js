'use strict';

const { notFound } = require('../errors/AppError');

function createCampService({ campRepository, donationRepository }) {
  function requireCamp(id) {
    const camp = campRepository.findById(id);
    if (!camp) throw notFound('Camp', id);
    return camp;
  }

  function view(camp) {
    const taken = donationRepository.findByCamp(camp.id).length;
    return { ...camp, donations: taken, seatsLeft: camp.capacity - taken };
  }

  function list() {
    return campRepository.findAll().sort((a, b) => (a.date < b.date ? -1 : 1)).map(view);
  }

  function get(id) {
    return view(requireCamp(id));
  }

  return { list, get, requireCamp, view };
}

module.exports = { createCampService };
