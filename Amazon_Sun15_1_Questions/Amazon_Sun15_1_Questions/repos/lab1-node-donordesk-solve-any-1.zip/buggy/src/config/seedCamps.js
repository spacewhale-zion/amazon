'use strict';

const SEED_CAMPS = [
  { id: 'cmp_1', name: 'Campus Auditorium Drive', date: '2026-06-02', capacity: 40 },
  { id: 'cmp_2', name: 'Hitech City Office Drive', date: '2026-06-05', capacity: 25 },
  { id: 'cmp_3', name: 'Railway Station Mobile Van', date: '2026-06-09', capacity: 3 },
];

module.exports = { SEED_CAMPS };
