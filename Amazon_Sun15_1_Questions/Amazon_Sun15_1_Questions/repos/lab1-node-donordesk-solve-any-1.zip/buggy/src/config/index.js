'use strict';

module.exports = Object.freeze({
  BLOOD_GROUPS: Object.freeze(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']),
  MIN_AGE: 18,
  MAX_AGE: 65,
  MIN_WEIGHT_KG: 50,
  MIN_HEMOGLOBIN: 12.5,
  DAYS_BETWEEN_DONATIONS: 90,
  PHONE_PATTERN: /^[6-9][0-9]{9}$/,
});
