'use strict';

const { createCampRepository } = require('./repositories/campRepository');
const { createDonorRepository } = require('./repositories/donorRepository');
const { createDonationRepository } = require('./repositories/donationRepository');
const { createDonorService } = require('./services/donorService');
const { createDonationService } = require('./services/donationService');
const { createCampService } = require('./services/campService');

/** Wires repositories and services for one app instance. */
function createContainer(store, clock) {
  const c = {
    ids: store.ids,
    clock,
    campRepository: createCampRepository(store),
    donorRepository: createDonorRepository(store),
    donationRepository: createDonationRepository(store),
  };
  c.donorService = createDonorService(c);
  c.campService = createCampService(c);
  c.donationService = createDonationService(c);
  return c;
}

module.exports = { createContainer };
