# DonorDesk blood donation camp API (Express)

> **Repository questions: there are 3 in this lab, one per tech stack (Node, Django, Spring Boot). Solve ANY ONE of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | DonorDesk blood donation camps | Node.js / Express |
> | 2 | ToolShare society tool library | Python / Django |
>
> **Every test in `tests/` fails on the starting code.** Each failing test points at one bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. One hidden test runs on submit and checks
> **the same rules** with other data, so fix the rule properly instead of special-casing the test values.

DonorDesk runs a blood bank's donation camps: camps, donors and donations.

**Your task: find and fix the 3 bugs in `src/` so that the API behaves as this README says.** Do not change the
tests, `package.json` or this file.

```
npm install
npx jest          # run the tests
```

## How to work (the method you will use in the real test)
1. Run the tests. Read **one** failing test: what request does it send, and what status / body does it expect?
2. Find the route in `src/routes/index.js`, then follow it into `src/services/` and `src/validators/`.
3. Compare the code with the rule below. Make the **smallest** change that follows the rule.
4. Run **all** the tests again. Then move to the next failing test.

## Code map

| Folder | What is in it |
|---|---|
| `src/routes/` | HTTP layer only (no rules) |
| `src/services/` | business rules: `donorService`, `donationService`, `campService` |
| `src/validators/` | input checks for each request body |
| `src/repositories/` | in-memory tables. **Reads return copies**: a change is stored only when you `save` it |
| `src/errors/`, `src/config/`, `src/utils/` | error codes, constants, helpers |

Staff endpoints need the header `X-Role: staff`. Errors: `{ "error": CODE, "message": text, "details"?: [{ "field", "issue" }] }`.

| Code | HTTP | Code | HTTP |
|---|---|---|---|
| VALIDATION_FAILED | 400 | DUPLICATE, TOO_SOON, CAMP_FULL | 409 |
| FORBIDDEN | 403 | LOW_HEMOGLOBIN | 422 |
| NOT_FOUND | 404 | | |

## Endpoints

| Method and path | Who | Notes |
|---|---|---|
| `GET /camps`, `GET /camps/:id` | anyone | |
| `POST /donors`, `GET /donors/:id` | anyone | `{ name, phone, bloodGroup, age, weightKg }` |
| `PATCH /donors/:id` | staff | any of `{ phone, weightKg }` |
| `POST /donations` | staff | `{ donorId, campId, hemoglobin }` |

## Rules
1. A donor must be **18 to 65 years old** (inclusive), weigh at least 50 kg, have a 10-digit mobile number and a
   valid blood group. Anything else is 400 VALIDATION_FAILED; for age the detail is
   `{ "field": "age", "issue": "must be 18 to 65" }`.
2. A phone number can belong to only one donor. Registering a phone that is already used is **409 DUPLICATE**.
3. A staff correction (`PATCH`) is **permanent**: later reads show the new values.
4. A donation needs hemoglobin of at least 12.5 g/dL (422), 90 days since the donor's last donation (409 TOO_SOON),
   and a seat at the camp (409 CAMP_FULL).
