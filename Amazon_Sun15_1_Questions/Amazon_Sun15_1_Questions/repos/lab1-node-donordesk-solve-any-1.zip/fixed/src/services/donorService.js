'use strict';

const { AppError, notFound } = require('../errors/AppError');
const { validateNewDonor, validateDonorPatch } = require('../validators/donorValidator');

function createDonorService({ donorRepository, ids }) {
  function register(body) {
    const input = validateNewDonor(body || {});
    if (donorRepository.findByPhone(input.phone)) {
      throw new AppError('DUPLICATE', `A donor with phone ${input.phone} is already registered`);
    }
    return donorRepository.save({ id: ids.next('dnr'), ...input, lastDonationOn: null, donations: 0 });
  }

  function requireDonor(id) {
    const donor = donorRepository.findById(id);
    if (!donor) throw notFound('Donor', id);
    return donor;
  }

  /** Staff corrections (new phone, new weight). The change must be permanent. */
  function update(id, body) {
    const patch = validateDonorPatch(body || {});
    const donor = requireDonor(id);
    if (patch.phone && patch.phone !== donor.phone && donorRepository.findByPhone(patch.phone)) {
      throw new AppError('DUPLICATE', `A donor with phone ${patch.phone} is already registered`);
    }
    const updated = { ...donor, ...patch };
    const saved = donorRepository.save(updated);
    return saved;
  }

  return { register, requireDonor, update, get: requireDonor };
}

module.exports = { createDonorService };
