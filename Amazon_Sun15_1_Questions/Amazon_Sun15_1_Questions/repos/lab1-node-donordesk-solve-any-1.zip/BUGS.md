# Planted bugs (author only, never shown to students)

DonorDesk blood donation camp API (Express).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Tracker | Kind | Symptom | File | Fixed code | Buggy code | Visible test | Hidden test |
|---|---|---|---|---|---|---|---|---|
| 1 | RP-03 | Wrong status code | A duplicate phone is reported as VALIDATION_FAILED (400) instead of DUPLICATE (409) | `src/services/donorService.js` | `if (donorRepository.findByPhone(input.phone)) {       throw new AppError('DUPLICATE',` | `if (donorRepository.findByPhone(input.phone)) {       throw new AppError('VALIDATION_FAILED',` | registering a phone number that is already used is 409 DUPLICATE | none |
| 2 | RP-04 | Change never saved | Staff corrections are returned but never stored | `src/services/donorService.js` | `const saved = donorRepository.save(updated);` | `const saved = updated;` | a staff correction to a donor's weight is saved | none |
| 3 | RP-05 | Missing validation | Donors older than 65 are accepted | `src/validators/donorValidator.js` | `age >= config.MIN_AGE && age <= config.MAX_AGE, 'age'` | `age >= config.MIN_AGE, 'age'` | a donor older than 65 is a validation error | age must be 18 to 65: 65 is accepted, 70 is refused |
