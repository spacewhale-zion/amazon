# HostelDesk: hostel room allocation API (Spring Boot)

> **Repository questions: there are 3 in this lab, one per tech stack (Node, Django, Spring Boot). Solve ANY ONE of them. 45 minutes.**

HostelDesk gives students beds in hostel rooms. Wardens create rooms; students are allocated a bed for a number of
nights and check out at the end of the stay.

Some rules below are broken in the code. The visible tests in `src/test/java` describe them and **all fail right now**.
Fix the code in `src/main/java` until every test passes. Do not edit the tests. One hidden test re-checks the same rules.

```bash
mvn test                                   # run all tests
mvn test -Dtest=HostelApiTest#aFullRoomAnswers409RoomFull   # run one test
```

## Rules

**Rooms**
- Blocks are A, B and C. Nightly rate per bed: A Rs 450.00, B Rs 525.00, C Rs 600.00.
- A room has 1 to 4 beds (`capacity`). Block + room number is unique (`DUPLICATE_ROOM`).
- `occupied` = beds in use, `freeBeds` = capacity − occupied.

**Allocations**
- A stay is **1 to 30 nights**. Anything else is a validation error.
- A student (roll number) has at most one ACTIVE allocation (`ALREADY_ALLOCATED`).
- A room with no free bed takes nobody: **409 `ROOM_FULL`**.
- Allocating takes one bed. **Checking out gives the bed back**: the room's `occupied` goes down by 1 and stays down.
- Fee = nights × nightly rate; stays of 14 nights or more get 10% off (rounded half up to the paisa).

## API

| Method | Path | Body | Success |
|---|---|---|---|
| POST | `/rooms` | `{"block":"A","number":101,"capacity":2}` | 201 room |
| GET | `/rooms`, `/rooms/{roomId}` | | 200 |
| GET | `/rooms/{roomId}/allocations` | | 200 active allocations |
| POST | `/allocations` | `{"roomId":"ROOM-1","rollNo":"21CS101","studentName":"Asha","nights":5}` | 201 allocation |
| GET | `/allocations/{allocationId}` | | 200 |
| POST | `/allocations/{allocationId}/checkout` | | 200 allocation (status `CHECKED_OUT`) |

## Errors

Every error body is `{"code": "...", "message": "...", "fields": [...]}`.

| Code | Status | When |
|---|---|---|
| VALIDATION_FAILED | 400 | a body field breaks a rule; `fields` lists them |
| MALFORMED_REQUEST | 400 | the body is not valid JSON |
| ROOM_NOT_FOUND, ALLOCATION_NOT_FOUND | 404 | unknown id |
| DUPLICATE_ROOM | 409 | block + number already used |
| ROOM_FULL | 409 | no free bed in the room |
| ALREADY_ALLOCATED | 409 | the student already has an ACTIVE allocation |
| NOT_ACTIVE | 409 | checking out an allocation that is already checked out |
| UNKNOWN_BLOCK | 422 | block is not A, B or C |
