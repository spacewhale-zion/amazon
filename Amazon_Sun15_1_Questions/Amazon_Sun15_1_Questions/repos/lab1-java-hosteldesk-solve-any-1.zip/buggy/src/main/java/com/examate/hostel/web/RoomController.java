package com.examate.hostel.web;

import com.examate.hostel.domain.Room;
import com.examate.hostel.service.AllocationService;
import com.examate.hostel.service.RoomService;
import com.examate.hostel.web.dto.AllocationResponse;
import com.examate.hostel.web.dto.CreateRoomRequest;
import com.examate.hostel.web.dto.RoomResponse;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RoomController {

    private final RoomService rooms;
    private final AllocationService allocations;

    public RoomController(RoomService rooms, AllocationService allocations) {
        this.rooms = rooms;
        this.allocations = allocations;
    }

    @PostMapping("/rooms")
    @ResponseStatus(HttpStatus.CREATED)
    public RoomResponse create(@Valid @RequestBody CreateRoomRequest body) {
        return view(rooms.create(body.block(), body.number(), body.capacity()));
    }

    @GetMapping("/rooms")
    public List<RoomResponse> all() {
        return rooms.all().stream().map(this::view).toList();
    }

    @GetMapping("/rooms/{roomId}")
    public RoomResponse get(@PathVariable("roomId") String roomId) {
        return view(rooms.get(roomId));
    }

    @GetMapping("/rooms/{roomId}/allocations")
    public List<AllocationResponse> residents(@PathVariable("roomId") String roomId) {
        return allocations.activeInRoom(roomId).stream().map(AllocationResponse::from).toList();
    }

    private RoomResponse view(Room room) {
        return RoomResponse.from(room, rooms.nightlyRate(room));
    }
}
