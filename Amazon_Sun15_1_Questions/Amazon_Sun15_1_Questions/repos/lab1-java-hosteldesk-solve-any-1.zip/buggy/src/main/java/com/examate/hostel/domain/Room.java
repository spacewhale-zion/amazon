package com.examate.hostel.domain;

/** A hostel room. Rooms are immutable: a change is a new Room that must be saved. */
public record Room(String id, String block, int number, int capacity, int occupied) {

    public int freeBeds() {
        return capacity - occupied;
    }

    public boolean isFull() {
        return occupied >= capacity;
    }

    public Room withOccupied(int newOccupied) {
        return new Room(id, block, number, capacity, newOccupied);
    }
}
