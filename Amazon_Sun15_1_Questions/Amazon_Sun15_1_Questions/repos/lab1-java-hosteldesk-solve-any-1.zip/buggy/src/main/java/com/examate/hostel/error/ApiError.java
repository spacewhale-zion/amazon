package com.examate.hostel.error;

import java.util.List;

/** The body of every error response. {@code fields} lists the invalid fields for VALIDATION_FAILED, else it is empty. */
public record ApiError(String code, String message, List<String> fields) {
}
