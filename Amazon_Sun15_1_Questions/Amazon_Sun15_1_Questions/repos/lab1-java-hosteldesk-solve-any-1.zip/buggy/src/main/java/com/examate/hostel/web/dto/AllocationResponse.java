package com.examate.hostel.web.dto;

import com.examate.hostel.domain.Allocation;
import java.time.Instant;

public record AllocationResponse(String id, String roomId, String rollNo, String studentName, int nights, long feePaise,
                                 String status, Instant createdAt, Instant checkedOutAt) {

    public static AllocationResponse from(Allocation a) {
        return new AllocationResponse(a.id(), a.roomId(), a.rollNo(), a.studentName(), a.nights(), a.feePaise(),
                a.status().name(), a.createdAt(), a.checkedOutAt());
    }
}
