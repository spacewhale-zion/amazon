package com.examate.hostel.web.dto;

import com.examate.hostel.domain.Room;

public record RoomResponse(String id, String block, int number, int capacity, int occupied, int freeBeds,
                           long nightlyRatePaise) {

    public static RoomResponse from(Room r, long nightlyRate) {
        return new RoomResponse(r.id(), r.block(), r.number(), r.capacity(), r.occupied(), r.freeBeds(), nightlyRate);
    }
}
