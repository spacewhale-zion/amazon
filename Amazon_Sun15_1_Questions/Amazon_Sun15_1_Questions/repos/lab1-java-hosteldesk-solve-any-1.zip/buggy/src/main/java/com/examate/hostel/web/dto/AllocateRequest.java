package com.examate.hostel.web.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record AllocateRequest(@NotBlank String roomId,
                              @NotBlank @Size(min = 4, max = 15) String rollNo,
                              @NotBlank @Size(min = 2, max = 60) String studentName,
                              @NotNull @Min(1) Integer nights) {
}
