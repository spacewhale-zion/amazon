package com.examate.hostel.support;

import java.util.Comparator;

/** Ids look like PREFIX-NUMBER (SKU-7, ORD-12). They are compared by prefix, then by number: SKU-2 before SKU-10. */
public final class Ids {

    public static final Comparator<String> NATURAL = Comparator.comparing(Ids::prefix).thenComparingLong(Ids::number);

    private Ids() {
    }

    static String prefix(String id) {
        int dash = id.lastIndexOf('-');
        return dash < 0 ? id : id.substring(0, dash);
    }

    static long number(String id) {
        int dash = id.lastIndexOf('-');
        try {
            return dash < 0 ? 0 : Long.parseLong(id.substring(dash + 1));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
