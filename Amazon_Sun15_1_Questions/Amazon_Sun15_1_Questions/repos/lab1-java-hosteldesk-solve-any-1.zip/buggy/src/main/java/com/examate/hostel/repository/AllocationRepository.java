package com.examate.hostel.repository;

import com.examate.hostel.domain.Allocation;
import com.examate.hostel.domain.AllocationStatus;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** In-memory table. Records are immutable: a changed record is only kept after save(). */
@Repository
public class AllocationRepository {

    private final Map<String, Allocation> rows = new LinkedHashMap<>();

    public synchronized Allocation save(Allocation row) {
        rows.put(row.id(), row);
        return row;
    }

    public synchronized Optional<Allocation> findById(String id) {
        return Optional.ofNullable(rows.get(id));
    }

    public synchronized Optional<Allocation> findActiveByRollNo(String rollNo) {
        return rows.values().stream()
                .filter(a -> a.rollNo().equals(rollNo) && a.status() == AllocationStatus.ACTIVE)
                .findFirst();
    }

    public synchronized List<Allocation> findActiveByRoom(String roomId) {
        return rows.values().stream()
                .filter(a -> a.roomId().equals(roomId) && a.status() == AllocationStatus.ACTIVE)
                .toList();
    }
}
