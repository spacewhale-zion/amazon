package com.examate.hostel.repository;

import com.examate.hostel.domain.Room;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** In-memory table. Records are immutable: a changed record is only kept after save(). */
@Repository
public class RoomRepository {

    private final Map<String, Room> rows = new LinkedHashMap<>();

    public synchronized Room save(Room row) {
        rows.put(row.id(), row);
        return row;
    }

    public synchronized Optional<Room> findById(String id) {
        return Optional.ofNullable(rows.get(id));
    }

    public synchronized Optional<Room> findByBlockAndNumber(String block, int number) {
        return rows.values().stream().filter(r -> r.block().equals(block) && r.number() == number).findFirst();
    }

    public synchronized List<Room> findAll() {
        return List.copyOf(rows.values());
    }
}
