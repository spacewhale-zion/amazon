package com.examate.hostel.error;

/** A business rule was broken. The handler turns it into the error body for its code. */
public class HostelException extends RuntimeException {

    private final ErrorCode code;

    public HostelException(ErrorCode code, String message) {
        super(message);
        this.code = code;
    }

    public ErrorCode code() {
        return code;
    }
}
