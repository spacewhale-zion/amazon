package com.examate.hostel.support;

import java.util.Map;

/** Business rules from README.md, in one place. */
public final class HostelRules {

    /** The longest stay one allocation can book. */
    public static final int MAX_NIGHTS = 30;

    /** Beds per room are between 1 and 4. */
    public static final int MAX_BEDS = 4;

    /** Nightly rate per bed, in paise, by block. */
    public static final Map<String, Long> NIGHTLY_RATE_PAISE = Map.of(
            "A", 45_000L,
            "B", 52_500L,
            "C", 60_000L);

    /** Stays of this many nights or more get the long-stay discount. */
    public static final int LONG_STAY_NIGHTS = 14;

    public static final int LONG_STAY_DISCOUNT_PERCENT = 10;

    private HostelRules() {
    }
}
