package com.examate.hostel.service;

import com.examate.hostel.domain.Room;
import com.examate.hostel.error.ErrorCode;
import com.examate.hostel.error.HostelException;
import com.examate.hostel.repository.IdGenerator;
import com.examate.hostel.repository.RoomRepository;
import com.examate.hostel.support.HostelRules;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class RoomService {

    private final RoomRepository rooms;
    private final IdGenerator ids;

    public RoomService(RoomRepository rooms, IdGenerator ids) {
        this.rooms = rooms;
        this.ids = ids;
    }

    public Room get(String roomId) {
        return rooms.findById(roomId)
                .orElseThrow(() -> new HostelException(ErrorCode.ROOM_NOT_FOUND, "Room " + roomId + " was not found"));
    }

    /** A new room starts empty. Block + number is unique. */
    public Room create(String block, int number, int capacity) {
        String b = block.trim().toUpperCase();
        if (!HostelRules.NIGHTLY_RATE_PAISE.containsKey(b)) {
            throw new HostelException(ErrorCode.UNKNOWN_BLOCK, "Block " + b + " does not exist");
        }
        if (rooms.findByBlockAndNumber(b, number).isPresent()) {
            throw new HostelException(ErrorCode.DUPLICATE_ROOM, "Room " + b + "-" + number + " already exists");
        }
        return rooms.save(new Room(ids.next("ROOM"), b, number, capacity, 0));
    }

    public List<Room> all() {
        return rooms.findAll();
    }

    public long nightlyRate(Room room) {
        return HostelRules.NIGHTLY_RATE_PAISE.get(room.block());
    }
}
