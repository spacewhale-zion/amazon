package com.examate.hostel.web;

import com.examate.hostel.service.AllocationService;
import com.examate.hostel.web.dto.AllocateRequest;
import com.examate.hostel.web.dto.AllocationResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AllocationController {

    private final AllocationService allocations;

    public AllocationController(AllocationService allocations) {
        this.allocations = allocations;
    }

    @PostMapping("/allocations")
    @ResponseStatus(HttpStatus.CREATED)
    public AllocationResponse allocate(@Valid @RequestBody AllocateRequest body) {
        return AllocationResponse.from(
                allocations.allocate(body.roomId(), body.rollNo(), body.studentName(), body.nights()));
    }

    @GetMapping("/allocations/{allocationId}")
    public AllocationResponse get(@PathVariable("allocationId") String allocationId) {
        return AllocationResponse.from(allocations.get(allocationId));
    }

    @PostMapping("/allocations/{allocationId}/checkout")
    public AllocationResponse checkout(@PathVariable("allocationId") String allocationId) {
        return AllocationResponse.from(allocations.checkout(allocationId));
    }
}
