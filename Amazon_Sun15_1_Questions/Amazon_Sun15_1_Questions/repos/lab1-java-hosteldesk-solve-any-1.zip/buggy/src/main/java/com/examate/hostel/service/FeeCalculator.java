package com.examate.hostel.service;

import com.examate.hostel.support.HostelRules;
import com.examate.hostel.support.Money;
import org.springframework.stereotype.Component;

/** Works out what a stay costs. */
@Component
public class FeeCalculator {

    /** nights x nightly rate of the block, minus the long-stay discount (rounded half up) for long stays. */
    public long feeFor(long nightlyRatePaise, int nights) {
        long gross = nightlyRatePaise * nights;
        if (nights >= HostelRules.LONG_STAY_NIGHTS) {
            return gross - Money.percentOf(gross, HostelRules.LONG_STAY_DISCOUNT_PERCENT);
        }
        return gross;
    }
}
