package com.examate.hostel.web.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record CreateRoomRequest(@NotBlank String block,
                                @NotNull @Min(1) @Max(999) Integer number,
                                @NotNull @Min(1) @Max(4) Integer capacity) {
}
