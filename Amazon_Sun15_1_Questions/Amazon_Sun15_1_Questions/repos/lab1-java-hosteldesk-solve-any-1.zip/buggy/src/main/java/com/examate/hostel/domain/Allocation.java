package com.examate.hostel.domain;

import java.time.Instant;

/** One student's bed in one room. Allocations are immutable: a change is a new Allocation that must be saved. */
public record Allocation(String id, String roomId, String rollNo, String studentName, int nights, long feePaise,
                         AllocationStatus status, Instant createdAt, Instant checkedOutAt) {

    public Allocation checkedOut(Instant at) {
        return new Allocation(id, roomId, rollNo, studentName, nights, feePaise, AllocationStatus.CHECKED_OUT, createdAt, at);
    }
}
