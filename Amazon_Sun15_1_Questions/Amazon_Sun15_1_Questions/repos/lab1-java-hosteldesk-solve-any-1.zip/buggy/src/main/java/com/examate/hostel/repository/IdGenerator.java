package com.examate.hostel.repository;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.stereotype.Component;

/** Hands out ids per prefix: SKU-1, SKU-2, ORD-1 ... */
@Component
public class IdGenerator {

    private final Map<String, AtomicLong> sequences = new ConcurrentHashMap<>();

    public String next(String prefix) {
        return prefix + "-" + sequences.computeIfAbsent(prefix, p -> new AtomicLong()).incrementAndGet();
    }
}
