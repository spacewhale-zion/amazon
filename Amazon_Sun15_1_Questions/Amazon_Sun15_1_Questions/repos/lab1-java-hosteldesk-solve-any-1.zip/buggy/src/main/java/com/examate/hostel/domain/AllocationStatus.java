package com.examate.hostel.domain;

public enum AllocationStatus {
    ACTIVE,
    CHECKED_OUT
}
