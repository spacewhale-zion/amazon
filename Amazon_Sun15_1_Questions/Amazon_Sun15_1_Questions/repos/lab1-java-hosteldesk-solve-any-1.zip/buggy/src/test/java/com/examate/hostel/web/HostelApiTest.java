package com.examate.hostel.web;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.hostel.support.WebTestBase;
import org.junit.jupiter.api.Test;

/**
 * These tests describe behaviour from README.md that is broken right now: every one of them FAILS on the starting
 * code. Fix the bugs in src/main/java until they all pass. One hidden test checks the same rules again.
 */
class HostelApiTest extends WebTestBase {

    @Test
    void aFullRoomAnswers409RoomFull() throws Exception {
        String room = newRoom(2);
        allocate(room, newRollNo(), 5).andExpect(status().isCreated());
        allocate(room, newRollNo(), 5).andExpect(status().isCreated());
        allocate(room, newRollNo(), 5)
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("ROOM_FULL"));
    }

    @Test
    void checkingOutGivesTheBedBack() throws Exception {
        String room = newRoom(2);
        String allocation = idOf(allocate(room, newRollNo(), 3).andExpect(status().isCreated()));
        checkout(allocation)
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("CHECKED_OUT"));
        room(room)
                .andExpect(jsonPath("$.occupied").value(0))
                .andExpect(jsonPath("$.freeBeds").value(2));
    }

    @Test
    void aStayLongerThan30NightsIsAValidationError() throws Exception {
        String room = newRoom(2);
        allocate(room, newRollNo(), 31)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_FAILED"))
                .andExpect(jsonPath("$.fields[0]").value("nights"));
        room(room).andExpect(jsonPath("$.occupied").value(0));
    }
}
