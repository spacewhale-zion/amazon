package com.examate.hostel.support;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.hostel.HostelApplication;
import com.jayway.jsonpath.JsonPath;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/**
 * Every web test extends this class, so all of them share ONE Spring context and ONE clock. Nothing is reset between
 * tests: each test creates its own rooms and students.
 */
@SpringBootTest(classes = {HostelApplication.class, TestClockConfig.class})
@AutoConfigureMockMvc
public abstract class WebTestBase {

    private static final AtomicInteger SEQ = new AtomicInteger(100);

    @Autowired
    protected MockMvc mvc;

    @Autowired
    protected MutableClock clock;

    protected ResultActions postJson(String url, String json) throws Exception {
        return mvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(json));
    }

    protected ResultActions getUrl(String url) throws Exception {
        return mvc.perform(get(url));
    }

    protected static String idOf(ResultActions result) throws Exception {
        return JsonPath.read(result.andReturn().getResponse().getContentAsString(), "$.id");
    }

    /** A new empty room in block A with the given number of beds; returns its id. */
    protected String newRoom(int capacity) throws Exception {
        return idOf(postJson("/rooms", "{\"block\":\"A\",\"number\":" + SEQ.incrementAndGet() + ",\"capacity\":" + capacity + "}")
                .andExpect(status().isCreated()));
    }

    /** A roll number nobody has used yet. */
    protected static String newRollNo() {
        return "21CS" + SEQ.incrementAndGet();
    }

    protected ResultActions allocate(String roomId, String rollNo, int nights) throws Exception {
        return postJson("/allocations", "{\"roomId\":\"" + roomId + "\",\"rollNo\":\"" + rollNo
                + "\",\"studentName\":\"Student " + rollNo + "\",\"nights\":" + nights + "}");
    }

    protected ResultActions checkout(String allocationId) throws Exception {
        return postJson("/allocations/" + allocationId + "/checkout", "");
    }

    protected ResultActions room(String roomId) throws Exception {
        return getUrl("/rooms/" + roomId);
    }
}
