package com.examate.hostel.hidden;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.hostel.support.WebTestBase;
import org.junit.jupiter.api.Test;

class HostelRulesHiddenTest extends WebTestBase {

    @Test
    void aSingleRoomCanBeGivenToTheNextStudentAfterCheckout() throws Exception {
        String room = newRoom(1);
        String first = idOf(allocate(room, newRollNo(), 7).andExpect(status().isCreated()));
        checkout(first).andExpect(status().isOk());
        allocate(room, newRollNo(), 2)
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("ACTIVE"));
    }
}
