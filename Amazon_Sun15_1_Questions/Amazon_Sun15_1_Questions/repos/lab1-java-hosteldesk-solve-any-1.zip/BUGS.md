# Planted bugs (author only, never shown to students)

HostelDesk hostel room allocation API (Spring Boot).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). The hidden test re-checks the same rule with other data.

| # | Kind | Symptom | File | Fixed code | Buggy code | Visible tests | Hidden tests |
|---|---|---|---|---|---|---|---|
| 1 | RP-03 Wrong status code | A full room answers 400 instead of 409 | `src/main/java/com/examate/hostel/error/ErrorCode.java` | `ROOM_FULL(HttpStatus.CONFLICT)` | `ROOM_FULL(HttpStatus.BAD_REQUEST)` | aFullRoomAnswers409RoomFull | none |
| 2 | RP-04 Change never saved (immutable record) | Checkout never gives the bed back | `src/main/java/com/examate/hostel/service/AllocationService.java` | `rooms.save(room.withOccupied(room.occupied() - 1));` | `room.withOccupied(room.occupied() - 1);` | checkingOutGivesTheBedBack | aSingleRoomCanBeGivenToTheNextStudentAfterCheckout |
| 3 | RP-05 Validation missing | Stays longer than 30 nights are accepted | `src/main/java/com/examate/hostel/web/dto/AllocateRequest.java` | `@NotNull @Min(1) @Max(30) Integer nights` | `@NotNull @Min(1) Integer nights` | aStayLongerThan30NightsIsAValidationError | none |

Fix notes:

1. ROOM_FULL is a conflict with the room's current state: HttpStatus.CONFLICT (409).
2. withOccupied returns a new Room; it must be stored with rooms.save(...).
3. Add @Max(30) to nights (HostelRules.MAX_NIGHTS).
