package com.examate.hostel.service;

import com.examate.hostel.domain.Allocation;
import com.examate.hostel.domain.AllocationStatus;
import com.examate.hostel.domain.Room;
import com.examate.hostel.error.ErrorCode;
import com.examate.hostel.error.HostelException;
import com.examate.hostel.repository.AllocationRepository;
import com.examate.hostel.repository.IdGenerator;
import com.examate.hostel.repository.RoomRepository;
import java.time.Clock;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class AllocationService {

    private final AllocationRepository allocations;
    private final RoomRepository rooms;
    private final RoomService roomService;
    private final FeeCalculator fees;
    private final IdGenerator ids;
    private final Clock clock;

    public AllocationService(AllocationRepository allocations, RoomRepository rooms, RoomService roomService,
                             FeeCalculator fees, IdGenerator ids, Clock clock) {
        this.allocations = allocations;
        this.rooms = rooms;
        this.roomService = roomService;
        this.fees = fees;
        this.ids = ids;
        this.clock = clock;
    }

    public Allocation get(String allocationId) {
        return allocations.findById(allocationId).orElseThrow(
                () -> new HostelException(ErrorCode.ALLOCATION_NOT_FOUND, "Allocation " + allocationId + " was not found"));
    }

    /** Gives a student one bed. A student has at most one ACTIVE allocation; a full room takes nobody. */
    public Allocation allocate(String roomId, String rollNo, String studentName, int nights) {
        Room room = roomService.get(roomId);
        String roll = rollNo.trim().toUpperCase();
        if (allocations.findActiveByRollNo(roll).isPresent()) {
            throw new HostelException(ErrorCode.ALREADY_ALLOCATED, "Student " + roll + " already has a bed");
        }
        if (room.isFull()) {
            throw new HostelException(ErrorCode.ROOM_FULL, "Room " + room.block() + "-" + room.number() + " has no free bed");
        }
        rooms.save(room.withOccupied(room.occupied() + 1));
        long fee = fees.feeFor(roomService.nightlyRate(room), nights);
        return allocations.save(new Allocation(ids.next("ALLOC"), room.id(), roll, studentName.trim(), nights, fee,
                AllocationStatus.ACTIVE, clock.instant(), null));
    }

    /** Ends an ACTIVE allocation and gives the bed back to the room. */
    public Allocation checkout(String allocationId) {
        Allocation allocation = get(allocationId);
        if (allocation.status() != AllocationStatus.ACTIVE) {
            throw new HostelException(ErrorCode.NOT_ACTIVE, "Allocation " + allocationId + " is already checked out");
        }
        Room room = roomService.get(allocation.roomId());
        rooms.save(room.withOccupied(room.occupied() - 1));
        return allocations.save(allocation.checkedOut(clock.instant()));
    }

    public List<Allocation> activeInRoom(String roomId) {
        roomService.get(roomId);
        return allocations.findActiveByRoom(roomId);
    }
}
