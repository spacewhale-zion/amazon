package com.examate.hostel.error;

import org.springframework.http.HttpStatus;

/** Every error the API can return, with its HTTP status. Must match the error table in README.md. */
public enum ErrorCode {
    VALIDATION_FAILED(HttpStatus.BAD_REQUEST),
    MALFORMED_REQUEST(HttpStatus.BAD_REQUEST),
    ROOM_NOT_FOUND(HttpStatus.NOT_FOUND),
    ALLOCATION_NOT_FOUND(HttpStatus.NOT_FOUND),
    DUPLICATE_ROOM(HttpStatus.CONFLICT),
    ROOM_FULL(HttpStatus.CONFLICT),
    ALREADY_ALLOCATED(HttpStatus.CONFLICT),
    NOT_ACTIVE(HttpStatus.CONFLICT),
    UNKNOWN_BLOCK(HttpStatus.UNPROCESSABLE_ENTITY);

    private final HttpStatus status;

    ErrorCode(HttpStatus status) {
        this.status = status;
    }

    public HttpStatus status() {
        return status;
    }
}
