# RentEase rent invoicing API (Django)

> **Repository questions: there are 6 in this test. Solve ANY TWO of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | EventPass ticketing | Node.js / Express |
> | 2 | QuizHub online quizzes | Node.js / Express |
> | 3 | PharmaCart pharmacy orders | Java / Spring Boot |
> | 4 | DeskSpace coworking desks | Java / Spring Boot |
> | 5 | TutorMatch tutoring sessions | Python / Django |
> | 6 | RentEase rent invoices | Python / Django |
>
> Pick any two, from the same stack or from different stacks. Only your best two are counted, so finish two
> completely rather than starting several.
>
> **Every visible test fails on the starting code.** Each failing test points at a bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. When all of them pass you are almost done:
> one or two hidden tests run on submit, and they check **the same rules** as the visible tests (with other data),
> so fix the rule properly instead of special-casing the test values.

RentEase bills tenants of a residential building: leases with a monthly rent and due day, one invoice per month,
payments with a grace period and late fees, and a paginated invoice history.

The property manager has reported problems. **Your task: find and fix the bugs in `billing/` so that the API behaves
as this README says.** Do not change the tests, `requirements.txt`, `billing/config.py`, `billing/money.py`,
`rentsite/`, `manage.py` or this file. When the code and the README disagree, the README is right.

```
pip install -r requirements.txt
pytest -q                          # every test gets a fresh in-memory SQLite database
python manage.py runserver         # optional
```

## Code map

| Path | What is in it |
|---|---|
| `billing/api/` | views and the JSON/error wrapper (no business rules) |
| `billing/services/` | `leases.py`, `invoices.py` (raise, pay, list), `late_fees.py` |
| `billing/models.py` | Lease, Invoice. `save(update_fields=[...])` writes only the listed columns |
| `billing/validation.py`, `billing/errors.py` | request checks and error classes (each class has its HTTP status) |
| `billing/money.py` | `div_round_half_up` |

## Conventions

* Money is whole paise. Dates are YYYY-MM-DD; months are YYYY-MM.
* Errors: `{ "error": CODE, "message": text }`.

| Code | HTTP | Code | HTTP |
|---|---|---|---|
| VALIDATION_FAILED | 400 | DUPLICATE, INVALID_STATE | 409 |
| NOT_FOUND | 404 | LEASE_ENDED, TOO_EARLY | 422 |

## Endpoints

| Method and path | Notes |
|---|---|
| `POST /leases` | `{ tenant, unit, monthly_rent, due_day }` -> 201 |
| `POST /leases/{id}/invoices` | `{ month }` -> 201 invoice |
| `GET /leases/{id}/invoices?page=&size=` | newest month first; pages start at 1 |
| `GET /invoices/{id}`, `POST /invoices/{id}/pay` | pay takes `{ paid_on }` |

## Business rules

1. `due_day` is **1 to 28**, so every month has it; `monthly_rent` is at least 1 paisa (400 VALIDATION_FAILED).
2. One invoice per lease per month: a second one is 409 DUPLICATE. Its due date is the due day in that month.
3. Paying settles the invoice in full: it becomes PAID for good (409 INVALID_STATE if paid again).
4. Grace period: rent paid **on or before due date + 5 days** is on time (due 5 June: on time until 10 June).
5. Late fee: 2% of the monthly rent for every **started** week after the grace period (1 to 7 days late = 1 week,
   8 to 14 days = 2 weeks), **rounded half up** to the paisa.
6. The invoice list is ordered **newest month first**.
