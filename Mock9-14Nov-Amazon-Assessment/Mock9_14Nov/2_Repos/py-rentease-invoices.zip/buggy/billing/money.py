"""Rounding helpers. Provided: use them, do not change them."""


def div_round_half_up(numerator: int, denominator: int) -> int:
    """numerator / denominator rounded half up, for non-negative whole numbers: 7 / 2 -> 4, 5 / 3 -> 2."""
    return (2 * numerator + denominator) // (2 * denominator)
