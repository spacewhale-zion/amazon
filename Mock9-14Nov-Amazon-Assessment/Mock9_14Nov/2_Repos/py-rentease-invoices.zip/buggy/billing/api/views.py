from .. import validation
from ..services import invoices, leases
from .common import api


def lease_view(l):
    return {"lease_id": l.id, "tenant": l.tenant, "unit": l.unit, "monthly_rent": l.monthly_rent, "due_day": l.due_day}


def invoice_view(i):
    return {"invoice_id": i.id, "lease_id": i.lease_id, "month": i.month, "amount": i.amount,
            "due_date": i.due_date.isoformat(), "status": i.status, "late_fee": i.late_fee,
            "paid_amount": i.paid_amount, "paid_on": i.paid_on.isoformat() if i.paid_on else None}


@api("POST")
def create_lease(request, body):
    return 201, lease_view(leases.create(validation.lease_in(body)))


@api("GET", "POST")
def lease_invoices(request, body, lease_id):
    if request.method == "POST":
        return 201, invoice_view(invoices.raise_invoice(lease_id, validation.month_in(body)))
    page, size = validation.page_in(request)
    return 200, [invoice_view(i) for i in invoices.for_lease(lease_id, page, size)]


@api("GET")
def invoice_detail(request, body, invoice_id):
    return 200, invoice_view(invoices.get(invoice_id))


@api("POST")
def pay(request, body, invoice_id):
    return 200, invoice_view(invoices.pay(invoice_id, validation.paid_on_in(body)))
