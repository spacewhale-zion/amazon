import json
from functools import wraps

from django.http import JsonResponse

from ..errors import ApiError, BadRequest


def iso(t):
    return t.strftime("%Y-%m-%dT%H:%M:%SZ") if t else None


def api(*methods):
    """Allow only `methods`, parse a JSON object body for POST/PUT, and turn ApiError into
    {"error": code, "message": message}. The view returns (status, data)."""

    def decorate(view):
        @wraps(view)
        def wrapper(request, *args, **kwargs):
            if request.method not in methods:
                return JsonResponse({"error": "METHOD_NOT_ALLOWED", "message": "method not allowed"}, status=405)
            try:
                body = {}
                if request.method in ("POST", "PUT") and request.body:
                    try:
                        body = json.loads(request.body)
                    except ValueError:
                        raise BadRequest("the body must be JSON")
                    if not isinstance(body, dict):
                        raise BadRequest("the body must be a JSON object")
                status, data = view(request, body, *args, **kwargs)
            except ApiError as e:
                return JsonResponse({"error": e.code, "message": e.message}, status=e.status)
            if status == 204:
                return JsonResponse({}, status=204)
            return JsonResponse(data, status=status, safe=False)

        return wrapper

    return decorate
