from django.urls import path

from .api import views

urlpatterns = [
    path("leases", views.create_lease),
    path("leases/<int:lease_id>/invoices", views.lease_invoices),
    path("invoices/<int:invoice_id>", views.invoice_detail),
    path("invoices/<int:invoice_id>/pay", views.pay),
]
