"""RentEase data model. Money is whole paise."""
from django.db import models


class Lease(models.Model):
    tenant = models.CharField(max_length=100)
    unit = models.CharField(max_length=20)
    monthly_rent = models.IntegerField()
    due_day = models.IntegerField()                         # day of the month, 1 to 28
    active = models.BooleanField(default=True)


class Invoice(models.Model):
    DUE, PAID = "DUE", "PAID"
    lease = models.ForeignKey(Lease, on_delete=models.CASCADE, related_name="invoices")
    month = models.CharField(max_length=7)                  # YYYY-MM
    amount = models.IntegerField()
    due_date = models.DateField()
    status = models.CharField(max_length=6, default=DUE)
    late_fee = models.IntegerField(default=0)
    paid_amount = models.IntegerField(default=0)
    paid_on = models.DateField(null=True, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["lease", "month"], name="one_invoice_per_month")]
