"""Settings. Provided and read-only. Money is whole paise."""
GRACE_DAYS = 5                 # rent paid up to 5 days after the due date is on time
LATE_FEE_PERCENT_PER_WEEK = 2  # for every started week after the grace period
MAX_DUE_DAY = 28               # so that every month has the due day
DEFAULT_PAGE_SIZE = 12
