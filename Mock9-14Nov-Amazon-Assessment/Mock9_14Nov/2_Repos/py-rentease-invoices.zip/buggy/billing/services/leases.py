from ..errors import NotFound
from ..models import Lease


def create(data) -> Lease:
    return Lease.objects.create(**data)


def get(lease_id) -> Lease:
    lease = Lease.objects.filter(pk=lease_id).first()
    if lease is None:
        raise NotFound("lease not found")
    return lease
