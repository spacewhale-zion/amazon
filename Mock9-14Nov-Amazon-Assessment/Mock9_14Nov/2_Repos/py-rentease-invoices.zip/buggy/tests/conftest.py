import os

import django

# the runner's pytest config names no settings module, so load Django here, before any test imports a model
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "rentsite.settings")
django.setup()

import json  # noqa: E402

import pytest  # noqa: E402


@pytest.fixture
def rent(client, db):
    class Rent:
        def get(self, url):
            return client.get(url)

        def post(self, url, body=None):
            return client.post(url, data=json.dumps(body if body is not None else {}), content_type="application/json")

        def lease(self, monthly_rent=2500000, due_day=5):
            r = self.post("/leases", {"tenant": "Nikhil", "unit": "B-402", "monthly_rent": monthly_rent, "due_day": due_day})
            assert r.status_code == 201, r.content
            return r.json()["lease_id"]

        def invoice(self, lease_id, month):
            r = self.post(f"/leases/{lease_id}/invoices", {"month": month})
            assert r.status_code == 201, r.content
            return r.json()["invoice_id"]

        def pay(self, invoice_id, paid_on):
            return self.post(f"/invoices/{invoice_id}/pay", {"paid_on": paid_on})

    return Rent()
