"""These tests describe behaviour from README.md that is broken right now: every one of them FAILS on the starting
code. Fix the bugs in billing/ until they all pass. One or two hidden tests check the same rules again."""


def test_a_second_invoice_for_the_same_month_is_409(rent):
    lease = rent.lease()
    rent.invoice(lease, "2026-06")
    r = rent.post(f"/leases/{lease}/invoices", {"month": "2026-06"})
    assert r.status_code == 409
    assert r.json()["error"] == "DUPLICATE"


def test_a_paid_invoice_stays_paid(rent):
    inv = rent.invoice(rent.lease(), "2026-06")
    assert rent.pay(inv, "2026-06-03").status_code == 200
    assert rent.get(f"/invoices/{inv}").json()["status"] == "PAID"


def test_a_due_day_after_the_28th_is_a_validation_error(rent):
    r = rent.post("/leases", {"tenant": "Ira", "unit": "A-101", "monthly_rent": 1800000, "due_day": 31})
    assert r.status_code == 400
    assert r.json()["error"] == "VALIDATION_FAILED"


def test_paying_on_the_last_day_of_the_grace_period_has_no_late_fee(rent):
    inv = rent.invoice(rent.lease(due_day=5), "2026-06")                 # due 5 June, grace until 10 June
    r = rent.pay(inv, "2026-06-10")
    assert r.json()["late_fee"] == 0


def test_the_late_fee_is_rounded_half_up_to_the_paisa(rent):
    inv = rent.invoice(rent.lease(monthly_rent=2505025, due_day=5), "2026-06")
    r = rent.pay(inv, "2026-06-13")                                      # 3 days after 10 June
    assert r.json()["late_fee"] == 50101                               # 2% of 2505025 paise = 50100.5 -> 50101


def test_invoices_are_listed_newest_month_first(rent):
    lease = rent.lease()
    for month in ("2026-03", "2026-05", "2026-04"):
        rent.invoice(lease, month)
    r = rent.get(f"/leases/{lease}/invoices?page=1&size=2")
    assert [i["month"] for i in r.json()] == ["2026-05", "2026-04"]
