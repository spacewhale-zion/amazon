"""Late fee (README rules 4 and 5).

Rent is on time when paid on or before due_date + 5 days (the grace period). After that, the tenant pays 2% of the
monthly rent for every STARTED week: 1 to 7 days late is one week, 8 to 14 days is two weeks, and so on. The fee is
rounded half up to the paisa.
"""
from datetime import timedelta

from .. import config
from ..money import div_round_half_up


def grace_end(due_date):
    return due_date + timedelta(days=config.GRACE_DAYS)


def late_days(due_date, paid_on) -> int:
    end = grace_end(due_date)
    if paid_on > end:
        return (paid_on - end).days
    return 0


def late_fee(rent: int, due_date, paid_on) -> int:
    days = late_days(due_date, paid_on)
    weeks = -(-days // 7)
    return div_round_half_up(rent * config.LATE_FEE_PERCENT_PER_WEEK * weeks, 100)
