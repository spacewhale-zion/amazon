from datetime import date

from django.db import transaction

from ..errors import BadRequest, Conflict, NotFound, Unprocessable  # noqa: F401
from ..models import Invoice
from . import late_fees, leases


@transaction.atomic
def raise_invoice(lease_id, month: str) -> Invoice:
    """One invoice per lease per month (README rule 2). The due date is the lease's due day in that month."""
    lease = leases.get(lease_id)
    if not lease.active:
        raise Unprocessable("this lease has ended", "LEASE_ENDED")
    if Invoice.objects.filter(lease=lease, month=month).exists():
        raise Conflict(f"{month} is already invoiced", "DUPLICATE")
    year, mon = map(int, month.split("-"))
    return Invoice.objects.create(lease=lease, month=month, amount=lease.monthly_rent,
                                  due_date=date(year, mon, lease.due_day))


def get(invoice_id) -> Invoice:
    inv = Invoice.objects.select_related("lease").filter(pk=invoice_id).first()
    if inv is None:
        raise NotFound("invoice not found")
    return inv


@transaction.atomic
def pay(invoice_id, paid_on) -> Invoice:
    """Pays the rent plus any late fee in full (README rule 3)."""
    inv = get(invoice_id)
    if inv.status == Invoice.PAID:
        raise Conflict("this invoice is already paid", "INVALID_STATE")
    if paid_on < inv.due_date.replace(day=1):
        raise Unprocessable("rent cannot be paid before its month starts", "TOO_EARLY")
    inv.late_fee = late_fees.late_fee(inv.amount, inv.due_date, paid_on)
    inv.paid_amount = inv.amount + inv.late_fee
    inv.paid_on = paid_on
    inv.status = Invoice.PAID
    inv.save(update_fields=["late_fee", "paid_amount", "paid_on", "status"])
    return inv


def for_lease(lease_id, page: int, size: int):
    """Newest month first (README rule 6). Pages start at 1."""
    leases.get(lease_id)
    rows = Invoice.objects.filter(lease_id=lease_id).order_by("-month")
    start = (page - 1) * size
    return list(rows[start:start + size])
