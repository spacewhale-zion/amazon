"""Checks for request bodies. Each function returns cleaned values or raises BadRequest (400)."""
import re
from datetime import date

from . import config
from .errors import BadRequest

MONTH = re.compile(r"\d{4}-(0[1-9]|1[0-2])")


def _text(body, key, max_length=100):
    value = body.get(key)
    if not isinstance(value, str) or not value.strip():
        raise BadRequest(f"{key} is required")
    if len(value.strip()) > max_length:
        raise BadRequest(f"{key} is too long")
    return value.strip()


def _int(body, key, low, high):
    value = body.get(key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise BadRequest(f"{key} must be a whole number")
    if not low <= value <= high:
        raise BadRequest(f"{key} must be from {low} to {high}")
    return value


def lease_in(body):
    return {"tenant": _text(body, "tenant"), "unit": _text(body, "unit", 20),
            "monthly_rent": _int(body, "monthly_rent", 1, 10_000_000_00),
            "due_day": _int(body, "due_day", 1, config.MAX_DUE_DAY)}


def month_in(body):
    month = _text(body, "month", 7)
    if not MONTH.fullmatch(month):
        raise BadRequest("month must look like 2026-06")
    return month


def paid_on_in(body):
    try:
        return date.fromisoformat(_text(body, "paid_on", 10))
    except ValueError:
        raise BadRequest("paid_on must be YYYY-MM-DD")


def page_in(request):
    try:
        page = int(request.GET.get("page", 1))
        size = int(request.GET.get("size", config.DEFAULT_PAGE_SIZE))
    except ValueError:
        raise BadRequest("page and size must be whole numbers")
    if page < 1 or not 1 <= size <= 100:
        raise BadRequest("page starts at 1 and size is 1 to 100")
    return page, size
