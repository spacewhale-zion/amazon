# Planted bugs (author only, never shown to students)

RentEase rent invoicing API (Django).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Kind | Symptom | File | Fixed code | Buggy code | Visible tests | Hidden tests |
|---|---|---|---|---|---|---|---|
| 1 | RP-03 Status codes | A duplicate invoice is 400 instead of 409 | `billing/services/invoices.py` | `raise Conflict(f"{month} is already invoiced", "DUPLICATE")` | `raise BadRequest(f"{month} is already invoiced", "DUPLICATE")` | test_a_second_invoice_for_the_same_month_is_409 | none |
| 2 | RP-04 Persistence (update_fields) | A paid invoice goes back to DUE | `billing/services/invoices.py` | `inv.save(update_fields=["late_fee", "paid_amount", "paid_on", "status"])` | `inv.save(update_fields=["late_fee", "paid_amount", "paid_on"])` | test_a_paid_invoice_stays_paid | none |
| 3 | RP-05 Validation | A due day of 31 is accepted | `billing/validation.py` | `"due_day": _int(body, "due_day", 1, config.MAX_DUE_DAY)}` | `"due_day": _int(body, "due_day", 1, 31)}` | test_a_due_day_after_the_28th_is_a_validation_error | none |
| 4 | RP-06 Boundary (off by one) | Paying on the last day of the grace period is charged as late | `billing/services/late_fees.py` | `return due_date + timedelta(days=config.GRACE_DAYS)` | `return due_date + timedelta(days=config.GRACE_DAYS - 1)` | test_paying_on_the_last_day_of_the_grace_period_has_no_late_fee | none |
| 5 | RP-07 Arithmetic (rounding) | The late fee is truncated instead of rounded half up | `billing/services/late_fees.py` | `return div_round_half_up(rent * config.LATE_FEE_PERCENT_PER_WEEK * weeks, 100)` | `return rent * config.LATE_FEE_PERCENT_PER_WEEK * weeks // 100` | test_the_late_fee_is_rounded_half_up_to_the_paisa | test_eight_days_late_is_two_started_weeks |
| 6 | RP-08 Ordering | Invoices are listed oldest month first | `billing/services/invoices.py` | `rows = Invoice.objects.filter(lease_id=lease_id).order_by("-month")` | `rows = Invoice.objects.filter(lease_id=lease_id).order_by("month")` | test_invoices_are_listed_newest_month_first | test_second_page_holds_the_older_months |

Fix notes:

1. A duplicate is a conflict with existing data: raise Conflict (409), not BadRequest (400).
2. save(update_fields=...) writes only the listed columns: add status.
3. Due days are limited to 1..28 (MAX_DUE_DAY) so that every month has that day.
4. The grace period ends 5 full days after the due date (due 5 June -> on time until 10 June). GRACE_DAYS - 1 ends it a day early.
5. // drops the fraction of a paisa. The README rounds half up: use div_round_half_up.
6. The README lists the newest month first: order_by("-month").
