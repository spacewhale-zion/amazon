def test_eight_days_late_is_two_started_weeks(rent):
    inv = rent.invoice(rent.lease(monthly_rent=1000013, due_day=1), "2026-07")      # grace until 6 July
    assert rent.pay(inv, "2026-07-14").json()["late_fee"] == 40001                  # 4% of 1000013 = 40000.52


def test_second_page_holds_the_older_months(rent):
    lease = rent.lease()
    for month in ("2026-01", "2026-02", "2026-03", "2026-04"):
        rent.invoice(lease, month)
    r = rent.get(f"/leases/{lease}/invoices?page=2&size=1")
    assert [i["month"] for i in r.json()] == ["2026-03"]
