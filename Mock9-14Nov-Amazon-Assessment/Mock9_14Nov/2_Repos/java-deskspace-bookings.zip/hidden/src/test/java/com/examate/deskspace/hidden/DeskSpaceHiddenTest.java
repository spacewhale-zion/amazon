package com.examate.deskspace.hidden;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.deskspace.support.WebTestBase;
import org.junit.jupiter.api.Test;

class DeskSpaceHiddenTest extends WebTestBase {

    @Test
    void secondPageKeepsTheDateThenHourOrder() throws Exception {
        booked("M-5", "D-10", "2026-06-06", 16, 2);
        booked("M-5", "D-11", "2026-06-06", 8, 2);
        booked("M-5", "D-12", "2026-06-06", 11, 2);
        getUrl("/members/M-5/bookings?page=2&size=1").andExpect(jsonPath("$[0].startHour").value(11));
    }

    @Test
    void exactlyThreeNoShowsBlocksEveryDesk() throws Exception {
        book("M-3", "D-9", "2026-06-08", 15, 1).andExpect(status().isForbidden());
    }
}
