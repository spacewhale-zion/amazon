# Planted bugs (author only, never shown to students)

DeskSpace coworking desks API (Spring Boot).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Kind | Symptom | File | Fixed code | Buggy code | Visible tests | Hidden tests |
|---|---|---|---|---|---|---|---|
| 1 | RP-05 Validation | Bookings longer than 10 hours are accepted | `src/main/java/com/examate/deskspace/web/dto/BookDeskRequest.java` | `@Min(1) @Max(10) int hours) {` | `@Min(1) int hours) {` | bookingMoreThanTenHoursIsAValidationError | none |
| 2 | RP-06 Boundary (dates) | A desk cannot be booked exactly 14 days ahead | `src/main/java/com/examate/deskspace/service/BookingPolicy.java` | `if (date.isAfter(today.plusDays(MAX_DAYS_AHEAD))) {` | `if (!date.isBefore(today.plusDays(MAX_DAYS_AHEAD))) {` | aDeskCanBeBookedExactly14DaysAhead | none |
| 3 | RP-03 Status codes | DESK_TAKEN is returned as 400 instead of 409 | `src/main/java/com/examate/deskspace/error/ErrorCode.java` | `DESK_TAKEN(HttpStatus.CONFLICT),` | `DESK_TAKEN(HttpStatus.BAD_REQUEST),` | anOverlappingBookingOnTheSameDeskIsAConflict | none |
| 4 | RP-04 Persistence (immutable record) | A cancelled booking goes back to ACTIVE | `src/main/java/com/examate/deskspace/service/BookingService.java` | `Booking cancelled = b.withStatus(BookingStatus.CANCELLED); bookings.save(cancelled);` | `Booking cancelled = b.withStatus(BookingStatus.CANCELLED);` | aCancelledBookingStaysCancelled | none |
| 5 | RP-08 Ordering / tie-break | Bookings on the same date are not ordered by start hour | `src/main/java/com/examate/deskspace/service/BookingService.java` | `static final Comparator<Booking> MEMBER_ORDER = Comparator.comparing(Booking::date) .thenComparingInt(Booking::startHour) .thenComparingLong` | `static final Comparator<Booking> MEMBER_ORDER = Comparator.comparing(Booking::date) .thenComparingLong` | aMembersBookingsAreListedByDateThenStartHour | secondPageKeepsTheDateThenHourOrder |
| 6 | RP-10 Blocklist | A member with exactly 3 no-shows can still book | `src/main/java/com/examate/deskspace/service/BookingPolicy.java` | `if (m.noShows() >= NO_SHOW_LIMIT) {` | `if (m.noShows() > NO_SHOW_LIMIT) {` | aMemberWithThreeNoShowsIsBlocked | exactlyThreeNoShowsBlocksEveryDesk |

Fix notes:

1. The DTO must limit hours to 1..10 with @Max(10), so 11 hours is a 400 VALIDATION_FAILED.
2. !isBefore(limit) also refuses the limit day itself. Only dates AFTER today + 14 are too far.
3. The README error table maps DESK_TAKEN to 409 Conflict.
4. withStatus returns a new record; save it, or the repository keeps the ACTIVE one.
5. After the date, order by start hour, and only then by id.
6. The README blocks members with 3 OR MORE no-shows: >=.
