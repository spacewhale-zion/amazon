package com.examate.deskspace.domain;

public enum BookingStatus {
    ACTIVE,
    CANCELLED
}
