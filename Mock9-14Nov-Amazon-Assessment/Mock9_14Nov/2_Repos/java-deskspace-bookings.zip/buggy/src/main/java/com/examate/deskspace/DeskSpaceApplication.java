package com.examate.deskspace;

import java.time.Clock;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DeskSpaceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DeskSpaceApplication.class, args);
    }

    /** Every service reads the time from this clock, so tests can move time. */
    @Bean
    public Clock clock() {
        return Clock.systemUTC();
    }
}
