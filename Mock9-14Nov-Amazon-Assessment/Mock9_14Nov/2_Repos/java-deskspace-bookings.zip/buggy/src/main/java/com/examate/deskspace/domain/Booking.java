package com.examate.deskspace.domain;

import java.time.Instant;
import java.time.LocalDate;

/** Immutable booking row: hours [startHour, startHour + hours) on one date. withStatus returns a changed copy. */
public record Booking(String id, String memberId, String deskId, LocalDate date, int startHour, int hours,
                      BookingStatus status, Instant createdAt) {

    public int endHour() {
        return startHour + hours;
    }

    public boolean overlaps(LocalDate otherDate, int otherStart, int otherEnd) {
        return date.equals(otherDate) && startHour < otherEnd && otherStart < endHour();
    }

    public Booking withStatus(BookingStatus newStatus) {
        return new Booking(id, memberId, deskId, date, startHour, hours, newStatus, createdAt);
    }
}
