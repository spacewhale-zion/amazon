package com.examate.deskspace.web.dto;

import com.examate.deskspace.domain.Booking;

public record BookingResponse(String id, String memberId, String deskId, String date, int startHour, int endHour,
                              String status) {

    public static BookingResponse from(Booking b) {
        return new BookingResponse(b.id(), b.memberId(), b.deskId(), b.date().toString(), b.startHour(), b.endHour(),
                b.status().name());
    }
}
