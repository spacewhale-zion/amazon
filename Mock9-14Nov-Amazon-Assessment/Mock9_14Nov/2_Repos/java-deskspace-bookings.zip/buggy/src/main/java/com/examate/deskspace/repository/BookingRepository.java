package com.examate.deskspace.repository;

import com.examate.deskspace.domain.Booking;
import com.examate.deskspace.domain.BookingStatus;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** In-memory table. Records are immutable: a changed record is only kept after save(). */
@Repository
public class BookingRepository {

    private final Map<String, Booking> rows = new LinkedHashMap<>();

    public synchronized Booking save(Booking row) {
        rows.put(row.id(), row);
        return row;
    }

    public synchronized Optional<Booking> findById(String id) {
        return Optional.ofNullable(rows.get(id));
    }

    public synchronized List<Booking> activeForDesk(String deskId, LocalDate date) {
        return rows.values().stream()
                .filter(b -> b.deskId().equals(deskId) && b.date().equals(date) && b.status() == BookingStatus.ACTIVE)
                .toList();
    }

    public synchronized List<Booking> findByMember(String memberId) {
        return rows.values().stream().filter(b -> b.memberId().equals(memberId)).toList();
    }
}
