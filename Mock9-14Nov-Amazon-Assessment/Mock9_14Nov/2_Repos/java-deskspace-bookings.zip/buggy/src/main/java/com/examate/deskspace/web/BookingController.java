package com.examate.deskspace.web;

import com.examate.deskspace.error.DeskException;
import com.examate.deskspace.error.ErrorCode;
import com.examate.deskspace.service.BookingService;
import com.examate.deskspace.web.dto.BookDeskRequest;
import com.examate.deskspace.web.dto.BookingResponse;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookingController {

    private final BookingService bookings;

    public BookingController(BookingService bookings) {
        this.bookings = bookings;
    }

    @PostMapping("/bookings")
    @ResponseStatus(HttpStatus.CREATED)
    public BookingResponse book(@Valid @RequestBody BookDeskRequest r) {
        return BookingResponse.from(bookings.book(r.memberId(), r.deskId(), r.date(), r.startHour(), r.hours()));
    }

    @GetMapping("/bookings/{bookingId}")
    public BookingResponse get(@PathVariable("bookingId") String bookingId) {
        return BookingResponse.from(bookings.get(bookingId));
    }

    @PostMapping("/bookings/{bookingId}/cancel")
    public BookingResponse cancel(@PathVariable("bookingId") String bookingId) {
        return BookingResponse.from(bookings.cancel(bookingId));
    }

    @GetMapping("/members/{memberId}/bookings")
    public List<BookingResponse> forMember(@PathVariable("memberId") String memberId,
                                           @RequestParam(name = "page", defaultValue = "1") int page,
                                           @RequestParam(name = "size", defaultValue = "20") int size) {
        if (page < 1 || size < 1 || size > 100) {
            throw new DeskException(ErrorCode.VALIDATION_FAILED, "page starts at 1 and size is 1 to 100");
        }
        return bookings.forMember(memberId, page, size).stream().map(BookingResponse::from).toList();
    }
}
