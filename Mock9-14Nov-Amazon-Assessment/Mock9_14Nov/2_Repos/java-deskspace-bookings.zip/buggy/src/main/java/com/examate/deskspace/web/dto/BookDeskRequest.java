package com.examate.deskspace.web.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

/** startHour is 7 to 21 (24-hour clock); hours is 1 to 10. date is YYYY-MM-DD. */
public record BookDeskRequest(@NotBlank String memberId,
                              @NotBlank String deskId,
                              @NotBlank String date,
                              @Min(7) @Max(21) int startHour,
                              @Min(1) int hours) {
}
