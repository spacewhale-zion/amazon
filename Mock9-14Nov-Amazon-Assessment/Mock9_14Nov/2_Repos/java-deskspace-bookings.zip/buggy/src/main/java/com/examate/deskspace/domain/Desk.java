package com.examate.deskspace.domain;

public record Desk(String id, int floor, String zone, boolean hasMonitor) {
}
