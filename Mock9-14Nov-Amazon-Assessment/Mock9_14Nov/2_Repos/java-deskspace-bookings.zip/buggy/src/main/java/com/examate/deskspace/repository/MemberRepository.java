package com.examate.deskspace.repository;

import com.examate.deskspace.domain.Member;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Repository;

@Repository
public class MemberRepository {

    private final Map<String, Member> rows = new LinkedHashMap<>();

    public MemberRepository() {
        save(new Member("M-1", "Ananya", 0));
        save(new Member("M-2", "Rohit", 2));
        save(new Member("M-3", "Farah", 3));
        save(new Member("M-4", "Kiran", 5));
        save(new Member("M-5", "Leela", 0));
        save(new Member("M-6", "Vikram", 1));
    }

    public synchronized Member save(Member row) {
        rows.put(row.id(), row);
        return row;
    }

    public synchronized Optional<Member> findById(String id) {
        return Optional.ofNullable(rows.get(id));
    }
}
