package com.examate.deskspace.error;

/** A business rule was broken. The handler turns it into the error body for its code. */
public class DeskException extends RuntimeException {

    private final ErrorCode code;

    public DeskException(ErrorCode code, String message) {
        super(message);
        this.code = code;
    }

    public ErrorCode code() {
        return code;
    }
}
