package com.examate.deskspace.repository;

import com.examate.deskspace.domain.Desk;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** Seeded desks D-1 to D-12: floors 1 to 3, four desks each. */
@Repository
public class DeskRepository {

    private final Map<String, Desk> rows = new LinkedHashMap<>();

    public DeskRepository() {
        String[] zones = {"QUIET", "COLLAB", "WINDOW", "QUIET"};
        for (int i = 1; i <= 12; i++) {
            rows.put("D-" + i, new Desk("D-" + i, (i - 1) / 4 + 1, zones[(i - 1) % 4], i % 2 == 0));
        }
    }

    public synchronized Optional<Desk> findById(String id) {
        return Optional.ofNullable(rows.get(id));
    }

    public synchronized List<Desk> findAll() {
        return List.copyOf(rows.values());
    }
}
