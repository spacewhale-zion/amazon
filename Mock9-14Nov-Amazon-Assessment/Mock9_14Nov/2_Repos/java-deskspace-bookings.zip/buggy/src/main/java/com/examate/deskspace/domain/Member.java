package com.examate.deskspace.domain;

/** noShows counts bookings the member did not turn up for. */
public record Member(String id, String name, int noShows) {
}
