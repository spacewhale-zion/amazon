package com.examate.deskspace.support;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;

/** A clock that only moves when a test moves it. */
public class MutableClock extends Clock {

    private Instant now;

    public MutableClock(Instant start) {
        this.now = start;
    }

    public synchronized void advance(Duration amount) {
        now = now.plus(amount);
    }

    /** Sets the time, e.g. clock.set("2026-06-01T10:00:00Z"). Tests that care about the time set it first. */
    public synchronized void set(String isoInstant) {
        now = Instant.parse(isoInstant);
    }

    @Override
    public synchronized Instant instant() {
        return now;
    }

    @Override
    public ZoneId getZone() {
        return ZoneOffset.UTC;
    }

    @Override
    public Clock withZone(ZoneId zone) {
        throw new UnsupportedOperationException("MutableClock is always UTC");
    }
}
