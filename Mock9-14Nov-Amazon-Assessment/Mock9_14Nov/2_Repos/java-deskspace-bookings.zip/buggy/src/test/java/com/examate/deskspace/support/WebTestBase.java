package com.examate.deskspace.support;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.deskspace.DeskSpaceApplication;
import com.jayway.jsonpath.JsonPath;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/**
 * Every web test extends this class, so all of them share ONE Spring context and ONE clock (Mon 1 June 2026, 09:00
 * UTC). Nothing is reset between tests, so each test uses its own desks.
 * Seed members: M-1 (0 no-shows), M-2 (2), M-3 (3), M-4 (5), M-5 (0), M-6 (1). Desks D-1 to D-12.
 */
@SpringBootTest(classes = {DeskSpaceApplication.class, TestClockConfig.class})
@AutoConfigureMockMvc
public abstract class WebTestBase {

    @Autowired
    protected MockMvc mvc;

    @Autowired
    protected MutableClock clock;

    protected ResultActions postJson(String url, String json) throws Exception {
        return mvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(json));
    }

    protected ResultActions getUrl(String url) throws Exception {
        return mvc.perform(get(url));
    }

    protected static String idOf(ResultActions result) throws Exception {
        return JsonPath.read(result.andReturn().getResponse().getContentAsString(), "$.id");
    }

    protected ResultActions book(String member, String desk, String date, int startHour, int hours) throws Exception {
        return postJson("/bookings", "{\"memberId\":\"" + member + "\",\"deskId\":\"" + desk + "\",\"date\":\"" + date
                + "\",\"startHour\":" + startHour + ",\"hours\":" + hours + "}");
    }

    protected String booked(String member, String desk, String date, int startHour, int hours) throws Exception {
        return idOf(book(member, desk, date, startHour, hours).andExpect(status().isCreated()));
    }
}
