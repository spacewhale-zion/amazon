package com.examate.deskspace.web;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.deskspace.support.WebTestBase;
import org.junit.jupiter.api.Test;

/**
 * These tests describe behaviour from README.md that is broken right now: every one of them FAILS on the starting
 * code. Fix the bugs in src/main/java until they all pass. One or two hidden tests check the same rules again.
 */
class DeskSpaceApiTest extends WebTestBase {

    @Test
    void bookingMoreThanTenHoursIsAValidationError() throws Exception {
        book("M-1", "D-1", "2026-06-02", 8, 11)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_FAILED"));
    }

    @Test
    void aDeskCanBeBookedExactly14DaysAhead() throws Exception {
        book("M-1", "D-2", "2026-06-15", 9, 4).andExpect(status().isCreated());
    }

    @Test
    void anOverlappingBookingOnTheSameDeskIsAConflict() throws Exception {
        booked("M-1", "D-3", "2026-06-04", 10, 3);
        book("M-6", "D-3", "2026-06-04", 12, 2)
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("DESK_TAKEN"));
    }

    @Test
    void aCancelledBookingStaysCancelled() throws Exception {
        String id = booked("M-1", "D-4", "2026-06-05", 9, 2);
        postJson("/bookings/" + id + "/cancel", "").andExpect(status().isOk());
        getUrl("/bookings/" + id).andExpect(jsonPath("$.status").value("CANCELLED"));
    }

    @Test
    void aMembersBookingsAreListedByDateThenStartHour() throws Exception {
        booked("M-2", "D-5", "2026-06-03", 14, 2);
        booked("M-2", "D-6", "2026-06-03", 9, 2);
        getUrl("/members/M-2/bookings")
                .andExpect(jsonPath("$[0].startHour").value(9))
                .andExpect(jsonPath("$[1].startHour").value(14));
    }

    @Test
    void aMemberWithThreeNoShowsIsBlocked() throws Exception {
        book("M-3", "D-7", "2026-06-02", 9, 2)
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("MEMBER_BLOCKED"));
    }
}
