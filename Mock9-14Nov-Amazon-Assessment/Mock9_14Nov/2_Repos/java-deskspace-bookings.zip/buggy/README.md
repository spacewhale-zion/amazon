# DeskSpace coworking desks API (Spring Boot)

> **Repository questions: there are 6 in this test. Solve ANY TWO of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | EventPass ticketing | Node.js / Express |
> | 2 | QuizHub online quizzes | Node.js / Express |
> | 3 | PharmaCart pharmacy orders | Java / Spring Boot |
> | 4 | DeskSpace coworking desks | Java / Spring Boot |
> | 5 | TutorMatch tutoring sessions | Python / Django |
> | 6 | RentEase rent invoices | Python / Django |
>
> Pick any two, from the same stack or from different stacks. Only your best two are counted, so finish two
> completely rather than starting several.
>
> **Every visible test fails on the starting code.** Each failing test points at a bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. When all of them pass you are almost done:
> one or two hidden tests run on submit, and they check **the same rules** as the visible tests (with other data),
> so fix the rule properly instead of special-casing the test values.

DeskSpace books hot desks in a coworking space: 12 desks on 3 floors, hourly bookings up to two weeks ahead, a no-show
blocklist, cancellations and a member's own booking list.

Members and the front desk have reported problems. **Your task: find and fix the bugs in `src/main/java` so that the
API behaves as this README says.** Do not change the tests, `pom.xml`, `application.properties` or this file. When the
code and the README disagree, the README is right.

```
mvn test          # run the tests (Java 17)
mvn spring-boot:run
```

## Code map

| Package | What is in it |
|---|---|
| `web` | `BookingController` and DTOs (validation annotations live on the DTOs) |
| `service` | `BookingPolicy` (dates, hours, blocklist), `BookingService` (book, cancel, list) |
| `repository` | in-memory tables. **Records are immutable: a changed copy is only kept after `save()`** |
| `domain` | `Desk`, `Member`, `Booking`, `BookingStatus` |
| `error` | `ErrorCode` (code -> HTTP status), `DeskException`, the exception handler |

## Conventions

* Dates are YYYY-MM-DD; "today" is the date of the injected `Clock` (UTC). Hours use the 24-hour clock.
* Errors: `{ "code": CODE, "message": text, "fields": [...] }`.

| Code | HTTP | Code | HTTP |
|---|---|---|---|
| VALIDATION_FAILED, MALFORMED_REQUEST | 400 | DESK_TAKEN, INVALID_STATE | 409 |
| MEMBER_BLOCKED | 403 | OUTSIDE_HOURS, BAD_DATE | 422 |
| NOT_FOUND | 404 | | |

## Endpoints

| Method and path | Notes |
|---|---|
| `POST /bookings` | `{ memberId, deskId, date, startHour, hours }` -> 201 `{ id, deskId, date, startHour, endHour, status }` |
| `GET /bookings/{id}`, `POST /bookings/{id}/cancel` | |
| `GET /members/{id}/bookings?page=&size=` | pages start at 1, default size 20 |

Seed members: M-1 Ananya (0 no-shows), M-2 Rohit (2), M-3 Farah (3), M-4 Kiran (5), M-5 Leela (0), M-6 Vikram (1).

## Business rules

1. `startHour` is 7 to 21 and `hours` is **1 to 10** (400 VALIDATION_FAILED). The space closes at 22:00:
   `startHour + hours` above 22 is 422 OUTSIDE_HOURS.
2. A desk can be booked from today up to and including **14 days ahead**; a past date or a date further ahead is 422
   BAD_DATE.
3. A member with **3 or more** no-shows is blocked: 403 MEMBER_BLOCKED.
4. A booking may not overlap an ACTIVE booking of the same desk on the same date (409 DESK_TAKEN). Hours are
   half-open: 10-13 and 13-15 do not overlap.
5. Cancelling makes the booking CANCELLED for good (409 INVALID_STATE if already cancelled) and frees the desk.
6. A member's list is ordered by date, then start hour, then booking id by number (BK-2 before BK-10).
