package com.examate.deskspace.service;

import com.examate.deskspace.domain.Booking;
import com.examate.deskspace.domain.BookingStatus;
import com.examate.deskspace.domain.Member;
import com.examate.deskspace.error.DeskException;
import com.examate.deskspace.error.ErrorCode;
import com.examate.deskspace.repository.BookingRepository;
import com.examate.deskspace.repository.DeskRepository;
import com.examate.deskspace.repository.IdGenerator;
import com.examate.deskspace.repository.MemberRepository;
import java.time.Clock;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

    /** README rule 6: date, then start hour, then booking id by number (BK-2 before BK-10). Ids look like BK-7. */
    static final Comparator<Booking> MEMBER_ORDER = Comparator.comparing(Booking::date)
            .thenComparingInt(Booking::startHour)
            .thenComparingLong(b -> Long.parseLong(b.id().substring(3)));

    private final BookingRepository bookings;
    private final DeskRepository desks;
    private final MemberRepository members;
    private final BookingPolicy policy;
    private final IdGenerator ids;
    private final Clock clock;

    public BookingService(BookingRepository bookings, DeskRepository desks, MemberRepository members,
                          BookingPolicy policy, IdGenerator ids, Clock clock) {
        this.bookings = bookings;
        this.desks = desks;
        this.members = members;
        this.policy = policy;
        this.ids = ids;
        this.clock = clock;
    }

    public Booking book(String memberId, String deskId, String dateText, int startHour, int hours) {
        Member member = members.findById(memberId)
                .orElseThrow(() -> new DeskException(ErrorCode.NOT_FOUND, "No member " + memberId));
        policy.checkNotBlocked(member);
        desks.findById(deskId).orElseThrow(() -> new DeskException(ErrorCode.NOT_FOUND, "No desk " + deskId));
        LocalDate date = policy.checkDate(dateText);
        policy.checkHours(startHour, hours);
        boolean clash = bookings.activeForDesk(deskId, date).stream()
                .anyMatch(b -> b.overlaps(date, startHour, startHour + hours));
        if (clash) {
            throw new DeskException(ErrorCode.DESK_TAKEN, deskId + " is already booked at that time");
        }
        return bookings.save(new Booking(ids.next("BK"), memberId, deskId, date, startHour, hours, BookingStatus.ACTIVE,
                clock.instant()));
    }

    public Booking get(String id) {
        return bookings.findById(id).orElseThrow(() -> new DeskException(ErrorCode.NOT_FOUND, "No booking " + id));
    }

    public Booking cancel(String id) {
        Booking b = get(id);
        if (b.status() != BookingStatus.ACTIVE) {
            throw new DeskException(ErrorCode.INVALID_STATE, "Booking " + id + " is already cancelled");
        }
        Booking cancelled = b.withStatus(BookingStatus.CANCELLED);
        bookings.save(cancelled);
        return cancelled;
    }

    /** Pages start at 1. */
    public List<Booking> forMember(String memberId, int page, int size) {
        List<Booking> all = bookings.findByMember(memberId).stream().sorted(MEMBER_ORDER).toList();
        int from = Math.min((page - 1) * size, all.size());
        int to = Math.min(from + size, all.size());
        return all.subList(from, to);
    }
}
