package com.examate.deskspace.error;

import org.springframework.http.HttpStatus;

/** Every error the API can return, with its HTTP status. Must match the error table in README.md. */
public enum ErrorCode {
    VALIDATION_FAILED(HttpStatus.BAD_REQUEST),
    MALFORMED_REQUEST(HttpStatus.BAD_REQUEST),
    MEMBER_BLOCKED(HttpStatus.FORBIDDEN),
    NOT_FOUND(HttpStatus.NOT_FOUND),
    DESK_TAKEN(HttpStatus.CONFLICT),
    INVALID_STATE(HttpStatus.CONFLICT),
    OUTSIDE_HOURS(HttpStatus.UNPROCESSABLE_ENTITY),
    BAD_DATE(HttpStatus.UNPROCESSABLE_ENTITY);

    private final HttpStatus status;

    ErrorCode(HttpStatus status) {
        this.status = status;
    }

    public HttpStatus status() {
        return status;
    }
}
