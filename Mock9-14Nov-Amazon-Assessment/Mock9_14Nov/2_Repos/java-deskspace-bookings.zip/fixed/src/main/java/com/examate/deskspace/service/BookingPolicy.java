package com.examate.deskspace.service;

import com.examate.deskspace.domain.Member;
import com.examate.deskspace.error.DeskException;
import com.examate.deskspace.error.ErrorCode;
import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import org.springframework.stereotype.Component;

/** README rules 2, 3 and 7: dates, opening hours and the no-show blocklist. */
@Component
public class BookingPolicy {

    static final int MAX_DAYS_AHEAD = 14;
    static final int CLOSING_HOUR = 22;
    static final int NO_SHOW_LIMIT = 3;

    private final Clock clock;

    public BookingPolicy(Clock clock) {
        this.clock = clock;
    }

    public LocalDate checkDate(String text) {
        LocalDate date;
        try {
            date = LocalDate.parse(text);
        } catch (DateTimeParseException e) {
            throw new DeskException(ErrorCode.VALIDATION_FAILED, "date must be YYYY-MM-DD");
        }
        LocalDate today = LocalDate.now(clock);
        if (date.isBefore(today)) {
            throw new DeskException(ErrorCode.BAD_DATE, "That date has passed");
        }
        if (date.isAfter(today.plusDays(MAX_DAYS_AHEAD))) {
            throw new DeskException(ErrorCode.BAD_DATE, "Desks can be booked at most 14 days ahead");
        }
        return date;
    }

    public void checkHours(int startHour, int hours) {
        if (startHour + hours > CLOSING_HOUR) {
            throw new DeskException(ErrorCode.OUTSIDE_HOURS, "The space closes at 22:00");
        }
    }

    public void checkNotBlocked(Member m) {
        if (m.noShows() >= NO_SHOW_LIMIT) {
            throw new DeskException(ErrorCode.MEMBER_BLOCKED, m.name() + " has " + m.noShows() + " no-shows");
        }
    }
}
