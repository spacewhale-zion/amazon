# Planted bugs (author only, never shown to students)

QuizHub online quiz API (Express).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Kind | Symptom | File | Fixed code | Buggy code | Visible tests | Hidden tests |
|---|---|---|---|---|---|---|---|
| 1 | RP-03 Status codes | Starting an attempt returns 200 instead of 201 | `src/routes/quizzes.js` | `res.status(201).json(attemptService.start(` | `res.json(attemptService.start(` | starting an attempt returns 201 Created | none |
| 2 | RP-04 Persistence | Answers are never kept, so every score is 0 | `src/services/attemptService.js` | `a.answers[questionId] = choice; attemptRepository.save(a);` | `a.answers[questionId] = choice;` | saved answers are used for the score | none |
| 3 | RP-05 Validation | An answer to a question that is not in the quiz is accepted | `src/services/attemptService.js` | `if (!question) throw validationError([{ field: 'questionId', issue: 'is not a question of this quiz' }]); if (choice >= question.options.len` | `if (question && choice >= question.options.length)` | an answer to a question that is not in the quiz is a validation error | none |
| 4 | RP-06 Boundary | Submitting exactly at the deadline is refused | `src/services/attemptService.js` | `if (clock().getTime() > new Date(a.deadline).getTime())` | `if (clock().getTime() >= new Date(a.deadline).getTime())` | submitting exactly at the deadline is accepted | none |
| 5 | RP-08 Pagination | Page 2 of the leaderboard skips a page | `src/utils/paginate.js` | `const start = (page - 1) * size;` | `const start = page * size;` | page 2 of the leaderboard continues where page 1 stopped | the last page of the leaderboard holds the slowest student |
| 6 | RP-09 Middleware order | Students can create quizzes: the instructor guard runs after the routes | `src/app.js` | `app.use('/admin', requireRole('instructor')); mountRoutes(app, container);` | `mountRoutes(app, container); app.use('/admin', requireRole('instructor'));` | a student cannot create a quiz | an instructor can create a quiz but a student still cannot |

Fix notes:

1. Creating an attempt creates a resource: the README says 201 Created. res.json alone sends 200.
2. The attempt from the repository is a copy: save it after recording the answer.
3. An unknown questionId must be a 400 VALIDATION_FAILED, not silently stored.
4. The deadline itself is still allowed: only times after it are TIME_UP.
5. Pages are numbered from 1, so page p starts at (p - 1) x size.
6. Express runs middleware in the order it is added. The guard must be added BEFORE the routes, or the route answers first.
