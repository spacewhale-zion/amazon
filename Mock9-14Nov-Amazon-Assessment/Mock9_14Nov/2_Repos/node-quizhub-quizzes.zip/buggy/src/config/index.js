'use strict';

module.exports = Object.freeze({
  DEFAULT_PAGE_SIZE: 10,
  MAX_PAGE_SIZE: 50,
  MAX_QUESTIONS: 50,
});
