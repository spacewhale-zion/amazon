'use strict';

/** One published quiz loaded into every new app. `answer` is the index (0 to 3) of the correct option. */
const QUIZZES = [
  {
    title: 'Amazon OA Warm-up: Arrays and Hashing',
    timeLimitMinutes: 30,
    published: true,
    questions: [
      { id: 'q1', text: 'Time to look up a key in a hash map, on average?', options: ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)'], answer: 0 },
      { id: 'q2', text: 'Which structure gives the max of a sliding window in O(n)?', options: ['Stack', 'Deque', 'Heap', 'Trie'], answer: 1 },
      { id: 'q3', text: 'Prefix sums answer which query in O(1)?', options: ['Range min', 'Range sum', 'Sort', 'Median'], answer: 1 },
      { id: 'q4', text: 'Two pointers on a sorted array find a pair with a given sum in?', options: ['O(n^2)', 'O(n log n)', 'O(n)', 'O(1)'], answer: 2 },
    ],
  },
];

module.exports = { QUIZZES };
