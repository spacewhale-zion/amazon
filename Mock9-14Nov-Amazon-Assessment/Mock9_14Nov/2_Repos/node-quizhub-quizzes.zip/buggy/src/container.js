'use strict';

const { createQuizRepository } = require('./repositories/quizRepository');
const { createAttemptRepository } = require('./repositories/attemptRepository');
const { createQuizService } = require('./services/quizService');
const { createScoringService } = require('./services/scoringService');
const { createAttemptService } = require('./services/attemptService');
const { createLeaderboardService } = require('./services/leaderboardService');

function createContainer(store, clock) {
  const c = { ids: store.ids, clock, quizRepository: createQuizRepository(store), attemptRepository: createAttemptRepository(store) };
  c.quizService = createQuizService(c);
  c.scoringService = createScoringService(c);
  c.attemptService = createAttemptService(c);
  c.leaderboardService = createLeaderboardService(c);
  return c;
}

module.exports = { createContainer };
