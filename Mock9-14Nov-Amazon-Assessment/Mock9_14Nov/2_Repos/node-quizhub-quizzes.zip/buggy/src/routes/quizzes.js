'use strict';

const express = require('express');
const { asyncHandler } = require('../middleware/asyncHandler');
const { requireUser } = require('../middleware/requireUser');
const { validateAnswer, validatePage } = require('../validators/quizValidator');

function quizzesRouter({ quizService, attemptService, leaderboardService }) {
  const r = express.Router();
  r.get('/quizzes/:id', asyncHandler((req, res) => res.json(quizService.publicView(quizService.get(req.params.id)))));
  r.post('/quizzes/:id/attempts', requireUser, asyncHandler((req, res) => {
    res.json(attemptService.start(req.params.id, req.context.userId));
  }));
  r.post('/attempts/:id/answers', requireUser, asyncHandler((req, res) => {
    res.json(attemptService.answer(req.params.id, req.context.userId, validateAnswer(req.body)));
  }));
  r.post('/attempts/:id/submit', requireUser, asyncHandler((req, res) => {
    res.json(attemptService.submit(req.params.id, req.context.userId));
  }));
  r.get('/quizzes/:id/leaderboard', asyncHandler((req, res) => {
    const { page, size } = validatePage(req.query);
    res.json(leaderboardService.page(req.params.id, page, size));
  }));
  return r;
}

module.exports = { quizzesRouter };
