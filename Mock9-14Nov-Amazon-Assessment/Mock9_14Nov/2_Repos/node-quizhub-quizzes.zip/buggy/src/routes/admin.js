'use strict';

const express = require('express');
const { asyncHandler } = require('../middleware/asyncHandler');
const { validateQuiz } = require('../validators/quizValidator');

/** Instructor routes. They are mounted under /admin, which app.js guards with requireRole('instructor'). */
function adminRouter({ quizService }) {
  const r = express.Router();
  r.post('/quizzes', asyncHandler((req, res) => {
    const quiz = quizService.create(req.context.userId, validateQuiz(req.body));
    res.status(201).json({ id: quiz.id, title: quiz.title });
  }));
  return r;
}

module.exports = { adminRouter };
