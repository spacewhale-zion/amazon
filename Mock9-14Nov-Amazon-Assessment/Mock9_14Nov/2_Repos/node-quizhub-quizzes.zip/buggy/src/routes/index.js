'use strict';

const { quizzesRouter } = require('./quizzes');
const { adminRouter } = require('./admin');

function mountRoutes(app, container) {
  app.use(quizzesRouter(container));
  app.use('/admin', adminRouter(container));
}

module.exports = { mountRoutes };
