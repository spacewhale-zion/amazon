'use strict';

const config = require('../config');
const { createChecker } = require('./common');

function validateQuiz(body) {
  const ck = createChecker(body);
  const title = ck.string('title', { max: 120 });
  const timeLimitMinutes = ck.integer('timeLimitMinutes', { min: 5, max: 180 });
  const questions = ck.data.questions;
  if (!Array.isArray(questions) || questions.length < 1 || questions.length > config.MAX_QUESTIONS) {
    ck.fail('questions', `must be a list of 1 to ${config.MAX_QUESTIONS} questions`);
  }
  ck.done();
  return { title, timeLimitMinutes, questions };
}

function validateAnswer(body) {
  const ck = createChecker(body);
  const questionId = ck.string('questionId', { max: 20 });
  const choice = ck.integer('choice', { min: 0, max: 9 });
  ck.done();
  return { questionId, choice };
}

function validatePage(query) {
  const ck = createChecker({ page: Number(query.page || 1), size: Number(query.size || config.DEFAULT_PAGE_SIZE) });
  const page = ck.integer('page', { min: 1 });
  const size = ck.integer('size', { min: 1, max: config.MAX_PAGE_SIZE });
  ck.done();
  return { page, size };
}

module.exports = { validateQuiz, validateAnswer, validatePage };
