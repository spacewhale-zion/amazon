'use strict';

const { createBaseRepository } = require('./baseRepository');

function createAttemptRepository(store) {
  const base = createBaseRepository(store.tables.attempts);
  return {
    ...base,
    findOne(quizId, studentId) {
      return base.findAll((a) => a.quizId === quizId && a.studentId === studentId)[0] || null;
    },
    submittedFor(quizId) {
      return base.findAll((a) => a.quizId === quizId && a.status === 'SUBMITTED');
    },
  };
}

module.exports = { createAttemptRepository };
