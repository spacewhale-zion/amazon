'use strict';

const { createBaseRepository } = require('./baseRepository');

function createQuizRepository(store) {
  return createBaseRepository(store.tables.quizzes);
}

module.exports = { createQuizRepository };
