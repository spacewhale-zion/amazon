'use strict';

/**
 * Attaches `req.context` with the caller's id (X-User header) and role (X-Role header: `instructor`, otherwise
 * `student`).
 */
function requestContext(ids) {
  return function attach(req, res, next) {
    const role = String(req.get('X-Role') || '').trim().toLowerCase() === 'instructor' ? 'instructor' : 'student';
    const userId = String(req.get('X-User') || '').trim() || null;
    req.context = { requestId: req.get('X-Request-Id') || ids.next('req'), role, userId };
    res.set('X-Request-Id', req.context.requestId);
    next();
  };
}

module.exports = { requestContext };
