'use strict';

const express = require('express');
const { createStore } = require('./store/createStore');
const { createContainer } = require('./container');
const { mountRoutes } = require('./routes');
const { requestContext } = require('./middleware/requestContext');
const { requireRole } = require('./middleware/requireRole');
const { errorHandler, notFoundRoute } = require('./errors/errorHandler');

/**
 * Builds one independent app with its own in-memory data (one seed quiz included).
 * @param {{ clock?: () => Date }} [options] clock defaults to real time; tests pass a movable clock
 */
function createApp(options = {}) {
  const clock = options.clock || (() => new Date());
  const store = createStore();
  const container = createContainer(store, clock);
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '100kb' }));
  app.use(requestContext(store.ids));
  mountRoutes(app, container);
  app.use('/admin', requireRole('instructor'));
  app.use(notFoundRoute);
  app.use(errorHandler);
  app.locals.container = container;
  return app;
}

module.exports = { createApp };
