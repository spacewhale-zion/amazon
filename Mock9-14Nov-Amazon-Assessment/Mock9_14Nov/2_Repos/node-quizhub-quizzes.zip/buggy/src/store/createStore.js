'use strict';

const { QUIZZES } = require('../config/seed');
const { createIdGenerator } = require('../utils/ids');

/** The in-memory database for one app instance: one Map per table and the id generator. */
function createStore() {
  const ids = createIdGenerator();
  const tables = { quizzes: new Map(), attempts: new Map() };
  for (const q of QUIZZES) {
    const id = ids.next('quiz');
    tables.quizzes.set(id, { id, ...q, createdBy: 'seed' });
  }
  return { tables, ids };
}

module.exports = { createStore };
