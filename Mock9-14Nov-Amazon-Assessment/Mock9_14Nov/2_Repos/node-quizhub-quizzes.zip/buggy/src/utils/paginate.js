'use strict';

/** Pages are numbered from 1. Returns { items, page, size, total, pages }. */
function paginate(rows, page, size) {
  const start = page * size;
  return {
    items: rows.slice(start, start + size),
    page,
    size,
    total: rows.length,
    pages: Math.ceil(rows.length / size),
  };
}

module.exports = { paginate };
