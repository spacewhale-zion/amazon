'use strict';

/** Every error the API can return, with its HTTP status. Must match the table in README.md. */
const ERROR_CODES = Object.freeze({
  VALIDATION_FAILED: 400,
  UNAUTHENTICATED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  ALREADY_ATTEMPTED: 409,
  INVALID_STATE: 409,
  TIME_UP: 422,
});

function statusFor(code) {
  return ERROR_CODES[code] || 500;
}

module.exports = { ERROR_CODES, statusFor };
