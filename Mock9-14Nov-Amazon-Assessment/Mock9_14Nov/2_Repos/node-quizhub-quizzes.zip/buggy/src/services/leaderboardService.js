'use strict';

const { paginate } = require('../utils/paginate');

/** README rule 6: higher score first; same score: less time taken first; still tied: submitted earlier first. */
function createLeaderboardService({ attemptRepository, quizService }) {
  return {
    page(quizId, page, size) {
      quizService.get(quizId);
      const rows = attemptRepository.submittedFor(quizId).sort((x, y) =>
        y.score - x.score || x.timeTakenSeconds - y.timeTakenSeconds || x.submittedAt.localeCompare(y.submittedAt));
      const result = paginate(rows, page, size);
      result.items = result.items.map((a, i) => ({ rank: (page - 1) * size + i + 1, studentId: a.studentId,
        score: a.score, percent: a.percent, timeTakenSeconds: a.timeTakenSeconds }));
      return result;
    },
  };
}

module.exports = { createLeaderboardService };
