'use strict';

/** Score = number of correct answers; percent = score / questions x 100, rounded to a whole number. */
function createScoringService() {
  return {
    score(quiz, answers) {
      let correct = 0;
      for (const q of quiz.questions) {
        if (answers[q.id] === q.answer) correct += 1;
      }
      const total = quiz.questions.length;
      return { score: correct, total, percent: Math.round((correct * 100) / total) };
    },
  };
}

module.exports = { createScoringService };
