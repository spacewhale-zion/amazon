'use strict';

const { notFound } = require('../errors/AppError');

function createQuizService({ quizRepository, ids }) {
  /** What a student sees: no correct answers. */
  function publicView(q) {
    return { id: q.id, title: q.title, timeLimitMinutes: q.timeLimitMinutes,
      questions: q.questions.map((x) => ({ id: x.id, text: x.text, options: x.options })) };
  }
  return {
    publicView,
    get(id) {
      const q = quizRepository.findById(id);
      if (!q || !q.published) throw notFound('Quiz', id);
      return q;
    },
    create(instructorId, data) {
      const quiz = { id: ids.next('quiz'), ...data, published: true, createdBy: instructorId };
      return quizRepository.insert(quiz);
    },
  };
}

module.exports = { createQuizService };
