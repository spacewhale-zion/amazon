# QuizHub online quiz API (Express)

> **Repository questions: there are 6 in this test. Solve ANY TWO of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | EventPass ticketing | Node.js / Express |
> | 2 | QuizHub online quizzes | Node.js / Express |
> | 3 | PharmaCart pharmacy orders | Java / Spring Boot |
> | 4 | DeskSpace coworking desks | Java / Spring Boot |
> | 5 | TutorMatch tutoring sessions | Python / Django |
> | 6 | RentEase rent invoices | Python / Django |
>
> Pick any two, from the same stack or from different stacks. Only your best two are counted, so finish two
> completely rather than starting several.
>
> **Every visible test fails on the starting code.** Each failing test points at a bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. When all of them pass you are almost done:
> one or two hidden tests run on submit, and they check **the same rules** as the visible tests (with other data),
> so fix the rule properly instead of special-casing the test values.

QuizHub runs timed online quizzes for a training institute: instructors publish quizzes, students start one attempt,
answer questions against a deadline, submit, and see a ranked, paginated leaderboard.

Students and instructors have reported problems. **Your task: find and fix the bugs in `src/` so that the API behaves
as this README says.** Do not change the tests, `package.json` or this file. When the code and the README disagree, the
README is right.

```
npm install
npx jest          # run the tests
node src/server.js
```

## Code map

| Folder | What is in it |
|---|---|
| `src/app.js` | builds the app: body parser, request context, the `/admin` guard, routes, error handler |
| `src/routes/` | `quizzes.js` (student routes), `admin.js` (instructor routes, mounted under `/admin`) |
| `src/services/` | `attemptService` (start, answer, submit, deadline), `scoringService`, `leaderboardService`, `quizService` |
| `src/repositories/` | data access. **Every read returns a copy: a change is only kept after `save()`** |
| `src/utils/paginate.js` | page slicing for lists |
| `src/middleware/` | request context (X-User, X-Role), `requireUser`, `requireRole` |
| `src/errors/` | `AppError`, the error-code table and the error handler |

## Conventions

* `X-User` header = the caller's id (needed for attempts). `X-Role: instructor` marks an instructor; anyone else is a
  student.
* Errors: `{ "error": CODE, "message": text }` (plus `details` for validation errors).

| Code | HTTP | Code | HTTP |
|---|---|---|---|
| VALIDATION_FAILED | 400 | ALREADY_ATTEMPTED | 409 |
| UNAUTHENTICATED | 401 | INVALID_STATE | 409 |
| FORBIDDEN | 403 | TIME_UP | 422 |
| NOT_FOUND | 404 | | |

## Endpoints

| Method and path | Notes |
|---|---|
| `POST /admin/quizzes` | instructors only: `{ title, timeLimitMinutes, questions }` -> 201 |
| `GET /quizzes/:id` | questions without the answers |
| `POST /quizzes/:id/attempts` | starts your attempt -> **201 Created** with `deadline` |
| `POST /attempts/:id/answers` | `{ questionId, choice }`; answering a question again replaces the earlier choice |
| `POST /attempts/:id/submit` | -> `{ score, total, percent, timeTakenSeconds }` |
| `GET /quizzes/:id/leaderboard?page=&size=` | pages start at 1; `{ items, page, size, total, pages }` |

## Business rules

1. Everything under `/admin` is for instructors only: anyone else gets 403 FORBIDDEN, whatever the route.
2. Each student gets **one** attempt per quiz (409 ALREADY_ATTEMPTED). The deadline is start + the quiz's time limit.
3. An answer must name a question **of this quiz** and a valid option (400 VALIDATION_FAILED). Saved answers count for
   the score.
4. Answers and the submission are accepted **up to and including the deadline**; after it they are 422 TIME_UP.
5. Score = number of correct answers; percent = score / total x 100, rounded to a whole number.
6. Leaderboard order: higher score first; same score: less time taken first; still tied: submitted earlier first.
   `rank` counts from 1 across all pages. Page `p` of size `s` holds ranks `(p - 1) x s + 1` to `p x s`.
