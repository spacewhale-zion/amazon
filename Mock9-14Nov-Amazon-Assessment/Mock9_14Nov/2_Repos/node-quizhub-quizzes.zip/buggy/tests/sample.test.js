const { makeApp, started, answer, submit } = require('./helpers');

/**
 * These tests describe behaviour from README.md that is broken right now: every one of them FAILS on the starting
 * code. Fix the bugs in src/ until they all pass. One or two hidden tests check the same rules again.
 */
describe('QuizHub', () => {
  test('starting an attempt returns 201 Created', async () => {
    const ctx = makeApp();
    const res = await ctx.as('stu_1').post('/quizzes/quiz_1/attempts');
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ status: 'IN_PROGRESS', deadline: '2026-06-01T10:30:00.000Z' });
  });

  test('saved answers are used for the score', async () => {
    const ctx = makeApp();
    const id = await started(ctx, 'stu_1');
    await answer(ctx, 'stu_1', id, 'q1', 0);
    await answer(ctx, 'stu_1', id, 'q2', 1);
    await answer(ctx, 'stu_1', id, 'q3', 3);
    const res = await submit(ctx, 'stu_1', id);
    expect(res.body).toMatchObject({ score: 2, total: 4, percent: 50 });
  });

  test('an answer to a question that is not in the quiz is a validation error', async () => {
    const ctx = makeApp();
    const id = await started(ctx, 'stu_1');
    const res = await answer(ctx, 'stu_1', id, 'q9', 0);
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_FAILED');
  });

  test('submitting exactly at the deadline is accepted', async () => {
    const ctx = makeApp();
    const id = await started(ctx, 'stu_1');
    ctx.clock.set('2026-06-01T10:30:00Z');
    const res = await submit(ctx, 'stu_1', id);
    expect(res.status).toBe(200);
    expect(res.body.timeTakenSeconds).toBe(1800);
  });

  test('page 2 of the leaderboard continues where page 1 stopped', async () => {
    const ctx = makeApp();
    const order = [];
    for (const [i, s] of ['stu_a', 'stu_b', 'stu_c', 'stu_d', 'stu_e'].entries()) {
      ctx.clock.set('2026-06-01T10:00:00Z');
      const id = await started(ctx, s);
      ctx.clock.set(`2026-06-01T10:0${i + 1}:00Z`);               // stu_a fastest ... stu_e slowest
      await submit(ctx, s, id);
      order.push(s);
    }
    const res = await ctx.as('stu_x').get('/quizzes/quiz_1/leaderboard?page=2&size=2');
    expect(res.body.items.map((r) => [r.rank, r.studentId])).toEqual([[3, 'stu_c'], [4, 'stu_d']]);
  });

  test('a student cannot create a quiz', async () => {
    const ctx = makeApp();
    const res = await ctx.as('stu_1').post('/admin/quizzes', {
      title: 'My quiz', timeLimitMinutes: 10, questions: [{ id: 'a', text: 'x?', options: ['1', '2'], answer: 0 }] });
    expect(res.status).toBe(403);
  });
});
