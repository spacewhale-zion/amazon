const request = require('supertest');
const { createApp } = require('../src/app');

// Monday 1 June 2026, 10:00 UTC
const NOW = '2026-06-01T10:00:00Z';

/** A fresh app with a clock the test can move: `ctx.clock.set('2026-06-01T10:30:00Z')`. */
function makeApp(start = NOW) {
  let now = new Date(start);
  const clock = { set(iso) { now = new Date(iso); } };
  const app = createApp({ clock: () => new Date(now) });
  const as = (user, role = 'student') => ({
    get: (url) => request(app).get(url).set('X-User', user).set('X-Role', role),
    post: (url, body) => request(app).post(url).set('X-User', user).set('X-Role', role).send(body || {}),
  });
  return { app, clock, as };
}

/** Starts an attempt on the seed quiz (quiz_1: 4 questions, 30 minutes) and returns its id. */
async function started(ctx, student) {
  const res = await ctx.as(student).post('/quizzes/quiz_1/attempts');
  if (res.status !== 201 && res.status !== 200) throw new Error(`attempt not started: ${res.status} ${JSON.stringify(res.body)}`);
  return res.body.id;
}

const answer = (ctx, student, attemptId, questionId, choice) =>
  ctx.as(student).post(`/attempts/${attemptId}/answers`, { questionId, choice });
const submit = (ctx, student, attemptId) => ctx.as(student).post(`/attempts/${attemptId}/submit`);

/* Seed quiz_1 correct choices: q1 -> 0, q2 -> 1, q3 -> 1, q4 -> 2. */
module.exports = { request, makeApp, started, answer, submit, NOW };
