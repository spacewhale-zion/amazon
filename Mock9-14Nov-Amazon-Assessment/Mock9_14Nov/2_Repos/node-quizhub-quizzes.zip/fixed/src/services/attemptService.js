'use strict';

const { AppError, notFound, invalidState, validationError } = require('../errors/AppError');

function createAttemptService(c) {
  const { attemptRepository, quizService, scoringService, ids, clock } = c;

  function view(a) {
    return { id: a.id, quizId: a.quizId, studentId: a.studentId, status: a.status, startedAt: a.startedAt,
      deadline: a.deadline, answered: Object.keys(a.answers).length, score: a.score, total: a.total,
      percent: a.percent, timeTakenSeconds: a.timeTakenSeconds, submittedAt: a.submittedAt };
  }

  function own(attemptId, studentId) {
    const a = attemptRepository.findById(attemptId);
    if (!a || a.studentId !== studentId) throw notFound('Attempt', attemptId);
    return a;
  }

  /** README rule 4: answers and submissions are accepted up to AND INCLUDING the deadline. */
  function checkTime(a) {
    if (clock().getTime() > new Date(a.deadline).getTime()) throw new AppError('TIME_UP', 'The time limit has passed');
  }

  return {
    view,
    start(quizId, studentId) {
      const quiz = quizService.get(quizId);
      if (attemptRepository.findOne(quizId, studentId)) {
        throw new AppError('ALREADY_ATTEMPTED', 'Each student gets one attempt per quiz');
      }
      const now = clock();
      const attempt = { id: ids.next('att'), quizId, studentId, status: 'IN_PROGRESS', answers: {},
        startedAt: now.toISOString(), deadline: new Date(now.getTime() + quiz.timeLimitMinutes * 60000).toISOString(),
        score: null, total: quiz.questions.length, percent: null, timeTakenSeconds: null, submittedAt: null };
      return view(attemptRepository.insert(attempt));
    },

    answer(attemptId, studentId, { questionId, choice }) {
      const a = own(attemptId, studentId);
      if (a.status !== 'IN_PROGRESS') throw invalidState('This attempt is already submitted');
      checkTime(a);
      const quiz = quizService.get(a.quizId);
      const question = quiz.questions.find((q) => q.id === questionId);
      if (!question) throw validationError([{ field: 'questionId', issue: 'is not a question of this quiz' }]);
      if (choice >= question.options.length) throw validationError([{ field: 'choice', issue: 'is not an option' }]);
      a.answers[questionId] = choice;
      attemptRepository.save(a);
      return view(a);
    },

    submit(attemptId, studentId) {
      const a = own(attemptId, studentId);
      if (a.status !== 'IN_PROGRESS') throw invalidState('This attempt is already submitted');
      checkTime(a);
      const quiz = quizService.get(a.quizId);
      const result = scoringService.score(quiz, a.answers);
      const now = clock();
      Object.assign(a, result, { status: 'SUBMITTED', submittedAt: now.toISOString(),
        timeTakenSeconds: Math.round((now.getTime() - new Date(a.startedAt).getTime()) / 1000) });
      attemptRepository.save(a);
      return view(a);
    },
  };
}

module.exports = { createAttemptService };
