const { makeApp, started, submit } = require('../helpers');

describe('QuizHub hidden', () => {
  test('the last page of the leaderboard holds the slowest student', async () => {
    const ctx = makeApp();
    for (const [i, s] of ['s1', 's2', 's3'].entries()) {
      ctx.clock.set('2026-06-01T10:00:00Z');
      const id = await started(ctx, s);
      ctx.clock.set(`2026-06-01T10:1${i}:00Z`);
      await submit(ctx, s, id);
    }
    const res = await ctx.as('x').get('/quizzes/quiz_1/leaderboard?page=3&size=1');
    expect(res.body.items.map((r) => r.studentId)).toEqual(['s3']);
  });

  test('an instructor can create a quiz but a student still cannot', async () => {
    const ctx = makeApp();
    const body = { title: 'Graphs', timeLimitMinutes: 20, questions: [{ id: 'g1', text: 'BFS uses?', options: ['Queue', 'Stack'], answer: 0 }] };
    expect((await ctx.as('ins_1', 'instructor').post('/admin/quizzes', body)).status).toBe(201);
    expect((await ctx.as('stu_9').post('/admin/quizzes', body)).status).toBe(403);
  });
});
