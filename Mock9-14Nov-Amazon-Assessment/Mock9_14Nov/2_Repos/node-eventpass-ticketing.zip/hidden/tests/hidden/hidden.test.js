const { makeApp, book } = require('../helpers');

describe('EventPass hidden', () => {
  test('two bookings by different users both take seats', async () => {
    const ctx = makeApp();
    await book(ctx, 'evt_4', 3, null, 'u_ravi');
    await book(ctx, 'evt_4', 2, null, 'u_meena');
    expect((await ctx.api.get('/events/evt_4')).body.seatsLeft).toBe(75);
  });

  test('a promo discount is capped at its maximum', async () => {
    const ctx = makeApp();
    const res = await book(ctx, 'evt_7', 3, 'SAVE20');           // 2700, 20% = 540, cap 300
    expect(res.body).toMatchObject({ discount: 300, amount: 2490 });
  });
});
