'use strict';

const config = require('../config');

/**
 * Rolling-window limiter for booking attempts (README rule 9). Every attempt counts, also the ones that are later
 * refused, and the limit is per USER across all events.
 */
function createRateLimiter(clock) {
  const attempts = new Map();          // key -> array of timestamps (ms)

  function keyFor(userId) {
    return `user:${userId}`;
  }

  return {
    /** Records one attempt and returns true when the caller is over the limit. */
    hit(userId, eventId) {
      const key = keyFor(userId, eventId);
      const now = clock().getTime();
      const recent = (attempts.get(key) || []).filter((t) => t > now - config.RATE_LIMIT_WINDOW_MS);
      recent.push(now);
      attempts.set(key, recent);
      return recent.length > config.RATE_LIMIT_MAX_ATTEMPTS;
    },
  };
}

module.exports = { createRateLimiter };
