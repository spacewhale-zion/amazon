'use strict';

const config = require('../config');
const { AppError, notFound, invalidState } = require('../errors/AppError');

function createBookingService(c) {
  const { bookingRepository, eventRepository, eventService, pricingService, ids, clock } = c;

  function view(b) {
    return { id: b.id, eventId: b.eventId, userId: b.userId, qty: b.qty, subtotal: b.subtotal, discount: b.discount,
      fees: b.fees, amount: b.amount, promoCode: b.promoCode, status: b.status, refund: b.refund, createdAt: b.createdAt };
  }

  return {
    view,
    async book(userId, { eventId, qty, promoCode }) {
      const event = eventService.get(eventId);
      if (!eventService.salesOpen(event)) {
        throw new AppError('SALES_CLOSED', 'Ticket sales for this event have closed');
      }
      const seatsLeft = event.capacity - event.seatsSold;
      if (qty > seatsLeft) throw new AppError('SOLD_OUT', `Only ${seatsLeft} seats left`);
      const price = await pricingService.quote(event, qty, promoCode);
      event.seatsSold += qty;
      eventRepository.save(event);
      const booking = { id: ids.next('bkg'), eventId, userId, qty, ...price, status: 'CONFIRMED', refund: 0,
        createdAt: clock().toISOString() };
      return view(bookingRepository.insert(booking));
    },

    get(id, userId) {
      const b = bookingRepository.findById(id);
      if (!b || b.userId !== userId) throw notFound('Booking', id);
      return b;
    },

    /** Free cancellation up to 48 hours before the start; later a 25% fee is kept. Seats go back on sale. */
    cancel(id, userId) {
      const b = this.get(id, userId);
      if (b.status !== 'CONFIRMED') throw invalidState('Only a confirmed booking can be cancelled');
      const event = eventService.get(b.eventId);
      const hoursLeft = (new Date(event.startsAt).getTime() - clock().getTime()) / 3600000;
      const keep = hoursLeft >= config.FREE_CANCEL_HOURS_BEFORE_START ? 0 : Math.round((b.subtotal * config.CANCEL_FEE_PERCENT) / 100);
      b.status = 'CANCELLED';
      b.refund = b.amount - b.fees - keep;
      bookingRepository.save(b);
      event.seatsSold -= b.qty;
      eventRepository.save(event);
      return view(b);
    },

    forUser(userId) {
      return bookingRepository.forUser(userId)
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id))
        .map(view);
    },
  };
}

module.exports = { createBookingService };
