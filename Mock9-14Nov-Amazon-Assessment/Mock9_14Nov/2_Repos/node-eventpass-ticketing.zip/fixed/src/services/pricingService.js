'use strict';

const config = require('../config');
const { AppError } = require('../errors/AppError');

/**
 * Prices a booking (README rules 5 and 6):
 *   subtotal = qty x ticket price
 *   discount = promo percent of subtotal, rounded to the nearest rupee, at most promo.maxOff
 *   fees     = qty x convenience fee
 *   amount   = subtotal - discount + fees
 */
function createPricingService({ promoRepository }) {
  async function resolvePromo(code) {
    if (!code) return null;
    const promo = await promoRepository.findByCode(code);
    if (!promo || !promo.active) throw new AppError('PROMO_INVALID', `Promo code ${code} cannot be used`);
    return promo;
  }

  function discountFor(promo, subtotal) {
    if (!promo) return 0;
    const raw = Math.round((subtotal * promo.percent) / 100);
    return Math.min(raw, promo.maxOff);
  }

  return {
    async quote(event, qty, promoCode) {
      const promo = await resolvePromo(promoCode);
      const subtotal = qty * event.price;
      const discount = discountFor(promo, subtotal);
      const fees = qty * config.CONVENIENCE_FEE_PER_TICKET;
      return { subtotal, discount, fees, amount: subtotal - discount + fees, promoCode: promo ? promo.code : null };
    },
  };
}

module.exports = { createPricingService };
