'use strict';

/** Every error the API can return, with its HTTP status. Must match the table in README.md. */
const ERROR_CODES = Object.freeze({
  VALIDATION_FAILED: 400,
  UNAUTHENTICATED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  SOLD_OUT: 409,
  INVALID_STATE: 409,
  SALES_CLOSED: 422,
  PROMO_INVALID: 422,
  RATE_LIMITED: 429,
});

function statusFor(code) {
  return ERROR_CODES[code] || 500;
}

module.exports = { ERROR_CODES, statusFor };
