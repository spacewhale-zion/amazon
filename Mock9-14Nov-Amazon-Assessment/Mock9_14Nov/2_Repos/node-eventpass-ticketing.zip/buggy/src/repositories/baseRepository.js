'use strict';

const { deepClone } = require('../utils/clone');

/**
 * Generic table access. Every read returns a deep copy and every write stores a deep copy, exactly like a real
 * database driver: changing an object you got from findById does NOT change what is stored until you save it.
 */
function createBaseRepository(table) {
  return {
    findById(id) {
      const row = table.get(id);
      return row ? deepClone(row) : null;
    },
    exists(id) {
      return table.has(id);
    },
    findAll(predicate) {
      const rows = [];
      for (const row of table.values()) {
        if (!predicate || predicate(row)) rows.push(deepClone(row));
      }
      return rows;
    },
    insert(row) {
      if (table.has(row.id)) throw new Error(`Duplicate id ${row.id}`);
      table.set(row.id, deepClone(row));
      return deepClone(row);
    },
    save(row) {
      if (!table.has(row.id)) throw new Error(`Cannot save unknown id ${row.id}`);
      table.set(row.id, deepClone(row));
      return deepClone(row);
    },
    count(predicate) {
      let n = 0;
      for (const row of table.values()) if (!predicate || predicate(row)) n += 1;
      return n;
    },
  };
}

module.exports = { createBaseRepository };
