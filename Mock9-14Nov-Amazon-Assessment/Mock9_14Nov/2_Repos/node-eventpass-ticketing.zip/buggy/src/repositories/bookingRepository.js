'use strict';

const { createBaseRepository } = require('./baseRepository');

function createBookingRepository(store) {
  const base = createBaseRepository(store.tables.bookings);
  return {
    ...base,
    forUser(userId) {
      return base.findAll((b) => b.userId === userId);
    },
  };
}

module.exports = { createBookingRepository };
