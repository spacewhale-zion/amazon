'use strict';

const { deepClone } = require('../utils/clone');

/**
 * Promo codes live in a separate pricing service in production, so this repository is ASYNC: findByCode returns a
 * Promise, like a network call would.
 */
function createPromoRepository(store) {
  const table = store.tables.promos;
  return {
    findByCode(code) {
      return new Promise((resolve) => {
        setImmediate(() => {
          const row = table.get(String(code).toUpperCase());
          resolve(row ? deepClone(row) : null);
        });
      });
    },
  };
}

module.exports = { createPromoRepository };
