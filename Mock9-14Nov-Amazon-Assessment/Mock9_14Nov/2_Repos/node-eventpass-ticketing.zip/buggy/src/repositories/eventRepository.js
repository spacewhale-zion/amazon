'use strict';

const { createBaseRepository } = require('./baseRepository');

function createEventRepository(store) {
  const base = createBaseRepository(store.tables.events);
  return {
    ...base,
    upcoming(now) {
      return base.findAll((e) => new Date(e.startsAt) > now).sort((a, b) => a.startsAt.localeCompare(b.startsAt));
    },
  };
}

module.exports = { createEventRepository };
