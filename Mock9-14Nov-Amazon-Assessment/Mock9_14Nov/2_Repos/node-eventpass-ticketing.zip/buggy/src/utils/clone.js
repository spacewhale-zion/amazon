'use strict';

/**
 * Deep copy for plain data (objects, arrays, primitives, Dates). Repositories hand out copies so that callers
 * cannot change stored records by accident: to change a record you must save it back.
 */
function deepClone(value) {
  if (value === null || typeof value !== 'object') return value;
  if (value instanceof Date) return new Date(value.getTime());
  if (Array.isArray(value)) return value.map(deepClone);
  const out = {};
  for (const key of Object.keys(value)) out[key] = deepClone(value[key]);
  return out;
}

/** Copies only the listed keys that are present (not undefined) in the source. */
function pick(source, keys) {
  const out = {};
  for (const key of keys) {
    if (source[key] !== undefined) out[key] = source[key];
  }
  return out;
}

module.exports = { deepClone, pick };
