'use strict';

/**
 * Sequential id generator, one counter per prefix: evt_1, bkg_1, ... Each app has its own generator, so
 * ids restart for every createApp().
 */
function createIdGenerator(startAt = {}) {
  const counters = new Map(Object.entries(startAt));
  return {
    next(prefix) {
      const value = (counters.get(prefix) || 0) + 1;
      counters.set(prefix, value);
      return `${prefix}_${value}`;
    },
    peek(prefix) {
      return counters.get(prefix) || 0;
    },
  };
}

/** Numeric part of an id such as "bkg_12", used to sort ids naturally (bkg_9 before bkg_10). */
function idNumber(id) {
  const match = /_(\d+)$/.exec(String(id));
  return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
}

module.exports = { createIdGenerator, idNumber };
