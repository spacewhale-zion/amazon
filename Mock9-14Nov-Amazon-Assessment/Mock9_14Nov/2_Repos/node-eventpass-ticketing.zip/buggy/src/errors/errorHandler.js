'use strict';

const { AppError } = require('./AppError');

function notFoundRoute(req, res) {
  res.status(404).json({ error: 'NOT_FOUND', message: `No route for ${req.method} ${req.path}` });
}

/**
 * Converts anything thrown in a route into the JSON error format. Unknown errors become 500 and are recorded on
 * the request context so that tests (and logs) can see them.
 */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof AppError) {
    const body = { error: err.code, message: err.message };
    if (err.details) body.details = err.details;
    return res.status(err.status).json(body);
  }
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'VALIDATION_FAILED', message: 'Body is not valid JSON' });
  }
  if (req.context) req.context.lastError = err;
  return res.status(500).json({ error: 'INTERNAL', message: 'Something went wrong' });
}

module.exports = { errorHandler, notFoundRoute };
