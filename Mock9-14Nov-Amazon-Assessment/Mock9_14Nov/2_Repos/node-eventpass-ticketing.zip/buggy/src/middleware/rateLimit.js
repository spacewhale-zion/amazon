'use strict';

const { AppError } = require('../errors/AppError');

/** Counts every booking attempt before anything else is checked (README rule 9). */
function bookingRateLimit(rateLimiter) {
  return function limit(req, res, next) {
    const eventId = req.body && req.body.eventId;
    if (rateLimiter.hit(req.context.userId, eventId)) {
      return next(new AppError('RATE_LIMITED', 'Too many booking attempts, wait a minute'));
    }
    return next();
  };
}

module.exports = { bookingRateLimit };
