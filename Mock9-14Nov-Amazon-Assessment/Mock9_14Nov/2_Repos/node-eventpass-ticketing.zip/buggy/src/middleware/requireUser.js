'use strict';

const { AppError } = require('../errors/AppError');

/** Booking routes need an X-User header. */
function requireUser(req, res, next) {
  if (!req.context || !req.context.userId) return next(new AppError('UNAUTHENTICATED', 'Send your user id in X-User'));
  return next();
}

module.exports = { requireUser };
