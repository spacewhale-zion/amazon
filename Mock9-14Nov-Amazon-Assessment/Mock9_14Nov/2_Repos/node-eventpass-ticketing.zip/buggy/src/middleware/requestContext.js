'use strict';

/** Attaches `req.context` with a request id, the caller's user id (X-User header) and role (X-Role: admin or user). */
function requestContext(ids) {
  return function attach(req, res, next) {
    const role = String(req.get('X-Role') || '').trim().toLowerCase() === 'admin' ? 'admin' : 'user';
    const userId = String(req.get('X-User') || '').trim() || null;
    req.context = { requestId: req.get('X-Request-Id') || ids.next('req'), role, userId };
    res.set('X-Request-Id', req.context.requestId);
    next();
  };
}

module.exports = { requestContext };
