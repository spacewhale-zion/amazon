'use strict';

const { AppError } = require('../errors/AppError');

/** Allows the request only when `req.context.role` is one of the given roles. */
function requireRole(...roles) {
  return function check(req, res, next) {
    const role = req.context ? req.context.role : 'member';
    if (!roles.includes(role)) {
      return next(new AppError('FORBIDDEN', `This action needs one of: ${roles.join(', ')}`));
    }
    return next();
  };
}

module.exports = { requireRole };
