'use strict';

const { createEventRepository } = require('./repositories/eventRepository');
const { createBookingRepository } = require('./repositories/bookingRepository');
const { createPromoRepository } = require('./repositories/promoRepository');
const { createEventService } = require('./services/eventService');
const { createPricingService } = require('./services/pricingService');
const { createBookingService } = require('./services/bookingService');
const { createRateLimiter } = require('./services/rateLimiter');

/** Wires repositories and services for one app instance. */
function createContainer(store, clock) {
  const c = {
    ids: store.ids,
    clock,
    eventRepository: createEventRepository(store),
    bookingRepository: createBookingRepository(store),
    promoRepository: createPromoRepository(store),
  };
  c.rateLimiter = createRateLimiter(clock);
  c.eventService = createEventService(c);
  c.pricingService = createPricingService(c);
  c.bookingService = createBookingService(c);
  return c;
}

module.exports = { createContainer };
