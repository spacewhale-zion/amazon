'use strict';

const { eventsRouter } = require('./events');
const { bookingsRouter } = require('./bookings');

function mountRoutes(app, container) {
  for (const make of [eventsRouter, bookingsRouter]) app.use(make(container));
}

module.exports = { mountRoutes };
