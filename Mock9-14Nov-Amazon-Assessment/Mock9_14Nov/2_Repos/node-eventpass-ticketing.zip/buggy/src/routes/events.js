'use strict';

const express = require('express');
const { asyncHandler } = require('../middleware/asyncHandler');

function eventsRouter({ eventService }) {
  const r = express.Router();
  r.get('/events', asyncHandler((req, res) => res.json(eventService.list())));
  r.get('/events/:id', asyncHandler((req, res) => res.json(eventService.view(eventService.get(req.params.id)))));
  return r;
}

module.exports = { eventsRouter };
