'use strict';

const express = require('express');
const { asyncHandler } = require('../middleware/asyncHandler');
const { requireUser } = require('../middleware/requireUser');
const { bookingRateLimit } = require('../middleware/rateLimit');
const { validateBooking } = require('../validators/bookingValidator');

function bookingsRouter({ bookingService, rateLimiter }) {
  const r = express.Router();
  r.post('/bookings', requireUser, bookingRateLimit(rateLimiter), asyncHandler(async (req, res) => {
    const input = validateBooking(req.body);
    const booking = await bookingService.book(req.context.userId, input);
    res.status(201).json(booking);
  }));
  r.get('/bookings/:id', requireUser, asyncHandler((req, res) => {
    res.json(bookingService.view(bookingService.get(req.params.id, req.context.userId)));
  }));
  r.post('/bookings/:id/cancel', requireUser, asyncHandler((req, res) => {
    res.json(bookingService.cancel(req.params.id, req.context.userId));
  }));
  r.get('/me/bookings', requireUser, asyncHandler((req, res) => res.json(bookingService.forUser(req.context.userId))));
  return r;
}

module.exports = { bookingsRouter };
