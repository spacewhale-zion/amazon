'use strict';

const config = require('../config');
const { notFound } = require('../errors/AppError');

function createEventService({ eventRepository, clock }) {
  function view(e) {
    return { id: e.id, title: e.title, venue: e.venue, category: e.category, startsAt: e.startsAt, price: e.price,
      capacity: e.capacity, seatsSold: e.seatsSold, seatsLeft: e.capacity - e.seatsSold };
  }
  return {
    get(id) {
      const e = eventRepository.findById(id);
      if (!e) throw notFound('Event', id);
      return e;
    },
    view,
    list() {
      return eventRepository.upcoming(clock()).map(view);
    },
    /** Sales are open up to and including SALES_CLOSE_MINUTES_BEFORE_START minutes before the start. */
    salesOpen(e) {
      const closesAt = new Date(e.startsAt).getTime() - config.SALES_CLOSE_MINUTES_BEFORE_START * 60 * 1000;
      return clock().getTime() < closesAt;
    },
  };
}

module.exports = { createEventService };
