'use strict';

/** Events loaded into every new app. Prices are whole rupees per ticket. Times are UTC. */
const EVENTS = [
  { title: 'Sunburn Arena Night', venue: 'Gachibowli Stadium', category: 'MUSIC', startsAt: '2026-06-01T07:00:00Z', capacity: 100, price: 1500 },
  { title: 'Comedy Hour', venue: 'Phoenix Arena', category: 'COMEDY', startsAt: '2026-06-02T14:00:00Z', capacity: 3, price: 499 },
  { title: 'AWS Builders Talk', venue: 'HITEX Hall 3', category: 'TECH', startsAt: '2026-06-05T10:00:00Z', capacity: 200, price: 799 },
  { title: 'Indie Folk Evening', venue: 'Lamakaan', category: 'MUSIC', startsAt: '2026-06-06T13:00:00Z', capacity: 80, price: 650 },
  { title: 'Startup Pitch Day', venue: 'T-Hub', category: 'TECH', startsAt: '2026-06-07T05:30:00Z', capacity: 150, price: 300 },
  { title: 'Kids Science Fair', venue: 'Birla Science Centre', category: 'FAMILY', startsAt: '2026-06-08T04:30:00Z', capacity: 300, price: 200 },
  { title: 'Jazz on the Lake', venue: 'Hussain Sagar Ghat', category: 'MUSIC', startsAt: '2026-06-09T13:30:00Z', capacity: 120, price: 900 },
  { title: 'Stand-up Open Mic', venue: 'Heart Cup Cafe', category: 'COMEDY', startsAt: '2026-06-10T15:00:00Z', capacity: 40, price: 250 },
];

/** Promo codes: percent off the ticket subtotal, rounded to the nearest rupee, never more than maxOff. */
const PROMOS = [
  { code: 'FEST10', percent: 10, maxOff: 500, active: true },
  { code: 'SAVE20', percent: 20, maxOff: 300, active: true },
  { code: 'OLD50', percent: 50, maxOff: 1000, active: false },
];

module.exports = { EVENTS, PROMOS };
