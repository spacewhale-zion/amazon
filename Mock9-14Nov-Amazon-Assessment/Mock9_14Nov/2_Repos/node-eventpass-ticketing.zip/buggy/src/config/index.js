'use strict';

/** Business settings. Changing a value here changes the behaviour described in README.md. */
module.exports = Object.freeze({
  MAX_TICKETS_PER_BOOKING: 6,
  SALES_CLOSE_MINUTES_BEFORE_START: 60,
  FREE_CANCEL_HOURS_BEFORE_START: 48,
  CANCEL_FEE_PERCENT: 25,
  RATE_LIMIT_MAX_ATTEMPTS: 5,
  RATE_LIMIT_WINDOW_MS: 60 * 1000,
  CONVENIENCE_FEE_PER_TICKET: 30,
});
