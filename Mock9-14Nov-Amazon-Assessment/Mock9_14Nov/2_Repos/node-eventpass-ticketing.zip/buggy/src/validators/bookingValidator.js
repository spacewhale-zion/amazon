'use strict';

const config = require('../config');
const { createChecker } = require('./common');

function validateBooking(body) {
  const ck = createChecker(body);
  const eventId = ck.string('eventId', { max: 20 });
  const qty = ck.integer('qty', { min: 1 });
  const promoCode = ck.string('promoCode', { required: false, max: 20 });
  ck.onlyKnown(['eventId', 'qty', 'promoCode']);
  ck.done();
  return { eventId, qty, promoCode };
}

module.exports = { validateBooking };
