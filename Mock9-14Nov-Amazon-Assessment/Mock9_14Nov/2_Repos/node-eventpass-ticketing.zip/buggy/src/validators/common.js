'use strict';

const { validationError } = require('../errors/AppError');

/**
 * Small validation toolkit. A validator collects every problem in `details` (in field order) and throws one 400
 * at the end, so the client sees all mistakes at once.
 */
function createChecker(body) {
  const details = [];
  const source = body && typeof body === 'object' && !Array.isArray(body) ? body : null;
  if (!source) details.push({ field: 'body', issue: 'must be a JSON object' });
  const data = source || {};
  const fail = (field, issue) => details.push({ field, issue });
  const missing = (field, required) => {
    if (data[field] === undefined || data[field] === null) {
      if (required) fail(field, 'is required');
      return true;
    }
    return false;
  };
  return {
    data,
    fail,
    details,
    string(field, { required = true, min = 1, max = 200, pattern } = {}) {
      if (missing(field, required)) return undefined;
      const value = data[field];
      if (typeof value !== 'string') return fail(field, 'must be a string');
      const trimmed = value.trim();
      if (trimmed.length < min || trimmed.length > max) return fail(field, `must be ${min} to ${max} characters`);
      if (pattern && !pattern.test(trimmed)) return fail(field, 'has an invalid format');
      return trimmed;
    },
    integer(field, { required = true, min = Number.MIN_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER } = {}) {
      if (missing(field, required)) return undefined;
      const value = data[field];
      if (!Number.isInteger(value)) return fail(field, 'must be an integer');
      if (value < min || value > max) return fail(field, `must be from ${min} to ${max}`);
      return value;
    },
    oneOf(field, allowed, { required = true } = {}) {
      if (missing(field, required)) return undefined;
      if (!allowed.includes(data[field])) return fail(field, `must be one of ${allowed.join(', ')}`);
      return data[field];
    },
    onlyKnown(allowedKeys) {
      for (const key of Object.keys(data)) if (!allowedKeys.includes(key)) fail(key, 'is not allowed');
    },
    done() {
      if (details.length) throw validationError(details);
    },
  };
}

const PHONE = /^\+?\d{10,13}$/;
const DATE = /^\d{4}-\d{2}-\d{2}$/;

module.exports = { createChecker, PHONE, DATE };
