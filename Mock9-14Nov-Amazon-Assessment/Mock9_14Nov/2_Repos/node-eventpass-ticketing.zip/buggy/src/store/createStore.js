'use strict';

const { EVENTS, PROMOS } = require('../config/seed');
const { createIdGenerator } = require('../utils/ids');

/** The in-memory database for one app instance: one Map per table and the id generator. */
function createStore() {
  const ids = createIdGenerator();
  const tables = { events: new Map(), promos: new Map(), bookings: new Map(), attempts: new Map() };
  for (const e of EVENTS) {
    const id = ids.next('evt');
    tables.events.set(id, { id, ...e, seatsSold: 0 });
  }
  for (const p of PROMOS) tables.promos.set(p.code, { id: p.code, ...p });
  return { tables, ids };
}

module.exports = { createStore };
