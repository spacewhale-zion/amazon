const request = require('supertest');
const { createApp } = require('../src/app');

// Monday 1 June 2026, 06:00 UTC
const NOW = '2026-06-01T06:00:00Z';

/** A fresh app with a clock the test can move: `ctx.clock.set('2026-06-01T07:00:00Z')`. */
function makeApp(start = NOW) {
  let now = new Date(start);
  const clock = { set(iso) { now = new Date(iso); } };
  const app = createApp({ clock: () => new Date(now) });
  const as = (user) => ({
    get: (url) => request(app).get(url).set('X-User', user),
    post: (url, body) => request(app).post(url).set('X-User', user).send(body || {}),
  });
  return { app, clock, as, api: as('u_asha') };
}

const book = (ctx, eventId, qty, promoCode, user = 'u_asha') =>
  ctx.as(user).post('/bookings', promoCode ? { eventId, qty, promoCode } : { eventId, qty });

/*
 * Seed events (UTC), price per ticket in rupees:
 *   evt_1 Sunburn Arena Night   Mon 1 Jun 07:00   cap 100   1500
 *   evt_2 Comedy Hour           Tue 2 Jun 14:00   cap 3      499
 *   evt_3 AWS Builders Talk     Fri 5 Jun 10:00   cap 200    799
 *   evt_4 Indie Folk Evening    Sat 6 Jun 13:00   cap 80     650
 *   evt_5 Startup Pitch Day     Sun 7 Jun 05:30   cap 150    300
 *   evt_6 Kids Science Fair     Mon 8 Jun 04:30   cap 300    200
 *   evt_7 Jazz on the Lake      Tue 9 Jun 13:30   cap 120    900
 *   evt_8 Stand-up Open Mic     Wed 10 Jun 15:00  cap 40     250
 * Promo codes: FEST10 (10%, max 500), SAVE20 (20%, max 300), OLD50 (inactive).
 */
module.exports = { request, makeApp, book, NOW };
