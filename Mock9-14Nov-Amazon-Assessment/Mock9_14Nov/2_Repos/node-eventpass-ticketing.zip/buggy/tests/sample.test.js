const { makeApp, book } = require('./helpers');

/**
 * These tests describe behaviour from README.md that is broken right now: every one of them FAILS on the starting
 * code. Fix the bugs in src/ until they all pass. One or two hidden tests check the same rules again.
 */
describe('EventPass', () => {
  test('more than 6 tickets in one booking is a validation error', async () => {
    const ctx = makeApp();
    const res = await book(ctx, 'evt_3', 7);
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_FAILED');
  });

  test('tickets can still be bought exactly 60 minutes before the start', async () => {
    const ctx = makeApp();                                       // now 06:00, event at 07:00
    const res = await book(ctx, 'evt_1', 2);
    expect(res.status).toBe(201);
  });

  test('asking for more seats than are left is 409 SOLD_OUT', async () => {
    const ctx = makeApp();
    const res = await book(ctx, 'evt_2', 4);                     // capacity 3
    expect(res.status).toBe(409);
    expect(res.body.error).toBe('SOLD_OUT');
  });

  test('a booking takes its seats out of the event', async () => {
    const ctx = makeApp();
    await book(ctx, 'evt_3', 2);
    const event = await ctx.api.get('/events/evt_3');
    expect(event.body).toMatchObject({ seatsSold: 2, seatsLeft: 198 });
  });

  test('a promo code takes its percentage off the ticket price', async () => {
    const ctx = makeApp();
    const res = await book(ctx, 'evt_3', 2, 'FEST10');           // 1598, 10% = 159.8 -> 160
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ subtotal: 1598, discount: 160, fees: 60, amount: 1498 });
  });

  test('the 6th booking attempt in a minute is refused, across different events', async () => {
    const ctx = makeApp();
    for (const id of ['evt_3', 'evt_4', 'evt_5', 'evt_6', 'evt_7']) {
      expect((await book(ctx, id, 1)).status).toBe(201);
    }
    const sixth = await book(ctx, 'evt_8', 1);
    expect(sixth.status).toBe(429);
    expect(sixth.body.error).toBe('RATE_LIMITED');
  });
});
