# EventPass ticketing API (Express)

> **Repository questions: there are 6 in this test. Solve ANY TWO of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | EventPass ticketing | Node.js / Express |
> | 2 | QuizHub online quizzes | Node.js / Express |
> | 3 | PharmaCart pharmacy orders | Java / Spring Boot |
> | 4 | DeskSpace coworking desks | Java / Spring Boot |
> | 5 | TutorMatch tutoring sessions | Python / Django |
> | 6 | RentEase rent invoices | Python / Django |
>
> Pick any two, from the same stack or from different stacks. Only your best two are counted, so finish two
> completely rather than starting several.
>
> **Every visible test fails on the starting code.** Each failing test points at a bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. When all of them pass you are almost done:
> one or two hidden tests run on submit, and they check **the same rules** as the visible tests (with other data),
> so fix the rule properly instead of special-casing the test values.

EventPass sells tickets for concerts, talks and shows in Hyderabad: an event catalogue with limited seats, promo codes,
bookings, cancellations with a fee, and a rate limit that stops bots from hammering the booking endpoint.

Customers have reported wrong prices, events that never sell out and booking errors. **Your task: find and fix the
bugs in `src/` so that the API behaves as this README says.** Do not change the tests, `package.json` or this file.
When the code and the README disagree, the README is right.

```
npm install
npx jest          # run the tests
node src/server.js
```

## Code map

| Folder | What is in it |
|---|---|
| `src/routes/` | HTTP routes: they validate the body and call a service (no business rules) |
| `src/services/` | the rules: `eventService` (sales window), `pricingService` (promo codes and fees), `bookingService`, `rateLimiter` |
| `src/repositories/` | data access. **Every read returns a copy: a change is only kept after `save()`.** `promoRepository` is async |
| `src/middleware/` | request context (X-User), `requireUser`, the booking rate limit |
| `src/validators/` | request body checks |
| `src/errors/` | `AppError`, the error-code table and the error handler |
| `src/config/` | business settings and seed data (8 events, 3 promo codes) |

## Conventions

* Every booking request must send the user id in the `X-User` header (401 UNAUTHENTICATED otherwise).
* Money is whole rupees. Times are UTC ISO strings.
* Errors: `{ "error": CODE, "message": text }` (plus `details` for validation errors).

| Code | HTTP | Code | HTTP |
|---|---|---|---|
| VALIDATION_FAILED | 400 | SOLD_OUT | 409 |
| UNAUTHENTICATED | 401 | INVALID_STATE | 409 |
| FORBIDDEN | 403 | SALES_CLOSED | 422 |
| NOT_FOUND | 404 | PROMO_INVALID | 422 |
| RATE_LIMITED | 429 | | |

## Endpoints

| Method and path | Notes |
|---|---|
| `GET /events`, `GET /events/:id` | event view has `capacity`, `seatsSold`, `seatsLeft` |
| `POST /bookings` | body `{ eventId, qty, promoCode? }` -> 201 `{ id, qty, subtotal, discount, fees, amount, status }` |
| `GET /bookings/:id`, `POST /bookings/:id/cancel` | only your own bookings |
| `GET /me/bookings` | newest first |

## Business rules

1. `qty` is a whole number from **1 to 6** tickets per booking (400 VALIDATION_FAILED).
2. Ticket sales stay open **up to and including 60 minutes before the start**. Later: 422 SALES_CLOSED.
3. A booking may not take more seats than are left (409 SOLD_OUT).
4. A booking takes its seats out of the event **at once** (`seatsSold` goes up, `seatsLeft` goes down); a cancellation
   puts them back.
5. Promo codes: discount = the promo's percent of the ticket subtotal, **rounded to the nearest rupee**, but never more
   than the promo's `maxOff`. An unknown or inactive code is 422 PROMO_INVALID.
6. `fees` = 30 per ticket. `amount = subtotal - discount + fees`.
7. Cancelling 48 hours or more before the start refunds `amount - fees`; later, 25% of the subtotal is kept as well.
8. A user can only see and cancel their own bookings (someone else's booking is 404).
9. **Rate limit:** at most **5 booking attempts per user per rolling 60 seconds, across all events**. Every attempt
   counts, also refused ones. The 6th attempt inside the window is 429 RATE_LIMITED.
