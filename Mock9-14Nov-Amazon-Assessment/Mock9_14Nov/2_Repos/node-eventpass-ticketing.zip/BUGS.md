# Planted bugs (author only, never shown to students)

EventPass ticketing API (Express).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Kind | Symptom | File | Fixed code | Buggy code | Visible tests | Hidden tests |
|---|---|---|---|---|---|---|---|
| 1 | RP-05 Validation | More than 6 tickets per booking are accepted | `src/validators/bookingValidator.js` | `const qty = ck.integer('qty', { min: 1, max: config.MAX_TICKETS_PER_BOOKING });` | `const qty = ck.integer('qty', { min: 1 });` | more than 6 tickets in one booking is a validation error | none |
| 2 | RP-06 Boundary | Sales close one moment too early (exactly 60 minutes before is refused) | `src/services/eventService.js` | `return clock().getTime() <= closesAt;` | `return clock().getTime() < closesAt;` | tickets can still be bought exactly 60 minutes before the start | none |
| 3 | RP-03 Status codes | SOLD_OUT is returned as 400 instead of 409 | `src/errors/errorCodes.js` | `SOLD_OUT: 409,` | `SOLD_OUT: 400,` | asking for more seats than are left is 409 SOLD_OUT | none |
| 4 | RP-04 Persistence | A booking never takes seats out of the event | `src/services/bookingService.js` | `event.seatsSold += qty; eventRepository.save(event); const booking` | `event.seatsSold += qty; const booking` | a booking takes its seats out of the event | two bookings by different users both take seats |
| 5 | RP-09 Language trap (missing await) | Promo discounts are never applied correctly | `src/services/pricingService.js` | `const promo = await promoRepository.findByCode(code);` | `const promo = promoRepository.findByCode(code);` | a promo code takes its percentage off the ticket price | a promo discount is capped at its maximum |
| 6 | RP-10 Rate limit | The limit counts attempts per event instead of per user | `src/services/rateLimiter.js` | `function keyFor(userId) { return `user:${userId}`;` | `function keyFor(userId, eventId) { return `user:${userId}:${eventId}`;` | the 6th booking attempt in a minute is refused, across different events | none |

Fix notes:

1. qty must be checked against MAX_TICKETS_PER_BOOKING (6), so 7 is a 400 VALIDATION_FAILED.
2. Sales are open up to AND INCLUDING 60 minutes before the start: <=.
3. The README error table maps SOLD_OUT to 409 Conflict.
4. The repository hands out copies: after changing seatsSold the event must be saved.
5. findByCode is async and returns a Promise. Without await, promo is a Promise (always truthy, no percent), so the discount is NaN.
6. The README limit is 5 attempts per user per minute across ALL events, so the key is the user only.
