package com.examate.pharmacart.service;

import com.examate.pharmacart.domain.Medicine;
import com.examate.pharmacart.error.ErrorCode;
import com.examate.pharmacart.error.PharmaException;
import com.examate.pharmacart.repository.MedicineRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class CatalogService {

    private final MedicineRepository medicines;

    public CatalogService(MedicineRepository medicines) {
        this.medicines = medicines;
    }

    public Medicine get(String code) {
        return medicines.findByCode(code)
                .orElseThrow(() -> new PharmaException(ErrorCode.MEDICINE_NOT_FOUND, "No medicine " + code));
    }

    /** All medicines, or only those of one schedule when {@code schedule} is given (README rule 1). */
    public List<Medicine> list(String schedule) {
        if (schedule == null || schedule.isBlank()) {
            return medicines.findAll();
        }
        return medicines.findAll().stream().filter(m -> m.schedule().equals(schedule)).toList();
    }

    public void takeStock(Medicine m, int quantity) {
        if (quantity > m.stock()) {
            throw new PharmaException(ErrorCode.OUT_OF_STOCK, "Only " + m.stock() + " strips of " + m.name() + " left");
        }
        medicines.save(m.withStock(m.stock() - quantity));
    }

    public void returnStock(String code, int quantity) {
        Medicine m = get(code);
        medicines.save(m.withStock(m.stock() + quantity));
    }
}
