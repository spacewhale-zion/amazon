package com.examate.pharmacart.hidden;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.pharmacart.support.WebTestBase;
import org.junit.jupiter.api.Test;

class PharmaCartHiddenTest extends WebTestBase {

    @Test
    void gstOnThreeStripsRoundsUp() throws Exception {
        order("MED-5", 3, "2026-04-01")                                  // 12630 x 12% = 1515.6
                .andExpect(jsonPath("$.gstPaise").value(1516));
    }

    @Test
    void filteringByOtcReturnsOnlyOtcMedicines() throws Exception {
        getUrl("/medicines?schedule=OTC").andExpect(jsonPath("$.length()").value(2));
    }
}
