# Planted bugs (author only, never shown to students)

PharmaCart pharmacy orders API (Spring Boot).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Kind | Symptom | File | Fixed code | Buggy code | Visible tests | Hidden tests |
|---|---|---|---|---|---|---|---|
| 1 | RP-05 Validation (missing @Valid) | An order for 0 strips is accepted | `src/main/java/com/examate/pharmacart/web/OrderController.java` | `public OrderResponse place(@Valid @RequestBody PlaceOrderRequest r) {` | `public OrderResponse place(@RequestBody PlaceOrderRequest r) {` | anOrderForZeroStripsIsAValidationError | none |
| 2 | RP-06 Boundary (dates) | A prescription exactly 180 days old is refused | `src/main/java/com/examate/pharmacart/service/PrescriptionPolicy.java` | `if (issuedOn.isBefore(today.minusDays(VALID_DAYS))) {` | `if (!issuedOn.isAfter(today.minusDays(VALID_DAYS))) {` | aPrescriptionExactly180DaysOldIsStillValid | none |
| 3 | RP-09 Language trap (== on String) | Filtering the catalogue by schedule returns nothing | `src/main/java/com/examate/pharmacart/service/CatalogService.java` | `.filter(m -> m.schedule().equals(schedule))` | `.filter(m -> m.schedule() == schedule)` | theCatalogueCanBeFilteredBySchedule | filteringByOtcReturnsOnlyOtcMedicines |
| 4 | RP-07 Arithmetic (rounding) | GST is truncated instead of rounded half up | `src/main/java/com/examate/pharmacart/service/PricingService.java` | `long gst = (subtotal * GST_PERCENT + 50) / 100;` | `long gst = subtotal * GST_PERCENT / 100;` | gstIsRoundedHalfUpToThePaisa | gstOnThreeStripsRoundsUp |
| 5 | RP-04 Persistence (immutable record) | A cancelled order goes back to PLACED | `src/main/java/com/examate/pharmacart/service/OrderService.java` | `Order cancelled = order.withStatus(OrderStatus.CANCELLED); orders.save(cancelled);` | `Order cancelled = order.withStatus(OrderStatus.CANCELLED);` | aCancelledOrderStaysCancelled | none |
| 6 | RP-03 Status codes | OUT_OF_STOCK is returned as 422 instead of 409 | `src/main/java/com/examate/pharmacart/error/ErrorCode.java` | `OUT_OF_STOCK(HttpStatus.CONFLICT),` | `OUT_OF_STOCK(HttpStatus.UNPROCESSABLE_ENTITY),` | orderingMoreThanTheStockIsAConflict | none |

Fix notes:

1. The @Min/@Max rules on the DTO only run when the controller parameter is annotated with @Valid.
2. !isAfter(limit) is also true ON the limit day. Expired means strictly before it: isBefore(today.minusDays(180)).
3. == compares object identity. The schedule from the URL is a different String object, so compare with equals().
4. Integer division drops the fraction. Add 50 before dividing by 100 to round half up to the paisa.
5. withStatus returns a NEW record; the repository still holds the old one until the new one is saved.
6. The README error table maps OUT_OF_STOCK to 409 Conflict.
