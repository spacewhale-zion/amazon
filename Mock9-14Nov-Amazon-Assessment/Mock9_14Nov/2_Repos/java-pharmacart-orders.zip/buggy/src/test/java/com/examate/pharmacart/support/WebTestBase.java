package com.examate.pharmacart.support;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.pharmacart.PharmaCartApplication;
import com.jayway.jsonpath.JsonPath;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/**
 * Every web test extends this class, so all of them share ONE Spring context and ONE clock (Mon 1 June 2026, 09:00
 * UTC). Nothing is reset between tests: each test places its own orders.
 */
@SpringBootTest(classes = {PharmaCartApplication.class, TestClockConfig.class})
@AutoConfigureMockMvc
public abstract class WebTestBase {

    @Autowired
    protected MockMvc mvc;

    @Autowired
    protected MutableClock clock;

    protected ResultActions postJson(String url, String json) throws Exception {
        return mvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(json));
    }

    protected ResultActions getUrl(String url) throws Exception {
        return mvc.perform(get(url));
    }

    protected static String idOf(ResultActions result) throws Exception {
        return JsonPath.read(result.andReturn().getResponse().getContentAsString(), "$.id");
    }

    protected ResultActions order(String code, int quantity, String prescriptionDate) throws Exception {
        String rx = prescriptionDate == null ? "null" : "\"" + prescriptionDate + "\"";
        return postJson("/orders", "{\"customerId\":\"CUST-1\",\"medicineCode\":\"" + code + "\",\"quantity\":" + quantity
                + ",\"prescriptionDate\":" + rx + "}");
    }

    protected String placed(String code, int quantity, String prescriptionDate) throws Exception {
        return idOf(order(code, quantity, prescriptionDate).andExpect(status().isCreated()));
    }
}
