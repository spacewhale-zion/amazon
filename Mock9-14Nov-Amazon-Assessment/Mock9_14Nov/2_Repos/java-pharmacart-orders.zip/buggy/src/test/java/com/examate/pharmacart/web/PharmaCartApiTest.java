package com.examate.pharmacart.web;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.examate.pharmacart.support.WebTestBase;
import org.junit.jupiter.api.Test;

/**
 * These tests describe behaviour from README.md that is broken right now: every one of them FAILS on the starting
 * code. Fix the bugs in src/main/java until they all pass. One or two hidden tests check the same rules again.
 */
class PharmaCartApiTest extends WebTestBase {

    @Test
    void anOrderForZeroStripsIsAValidationError() throws Exception {
        order("MED-1", 0, null)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_FAILED"));
    }

    @Test
    void aPrescriptionExactly180DaysOldIsStillValid() throws Exception {
        order("MED-5", 1, "2025-12-03")                                  // today 2026-06-01 minus 180 days
                .andExpect(status().isCreated());
    }

    @Test
    void theCatalogueCanBeFilteredBySchedule() throws Exception {
        getUrl("/medicines?schedule=SCHEDULE_H")
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(3));
    }

    @Test
    void gstIsRoundedHalfUpToThePaisa() throws Exception {
        order("MED-2", 1, "2026-05-20")                                  // 1238 x 12% = 148.56
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.gstPaise").value(149))
                .andExpect(jsonPath("$.totalPaise").value(1387));
    }

    @Test
    void aCancelledOrderStaysCancelled() throws Exception {
        String id = placed("MED-4", 2, null);
        postJson("/orders/" + id + "/cancel", "").andExpect(status().isOk());
        getUrl("/orders/" + id).andExpect(jsonPath("$.status").value("CANCELLED"));
    }

    @Test
    void orderingMoreThanTheStockIsAConflict() throws Exception {
        order("MED-3", 3, "2026-05-30")                                  // only 2 strips in stock
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("OUT_OF_STOCK"));
    }
}
