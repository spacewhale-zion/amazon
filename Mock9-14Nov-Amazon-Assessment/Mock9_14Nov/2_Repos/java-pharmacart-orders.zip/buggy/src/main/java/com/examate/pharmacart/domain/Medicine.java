package com.examate.pharmacart.domain;

/** Immutable catalogue row. Prices are paise per strip. Use withStock to get a changed copy, then save it. */
public record Medicine(String code, String name, String schedule, long pricePaise, int stock) {

    public Medicine withStock(int newStock) {
        return new Medicine(code, name, schedule, pricePaise, newStock);
    }
}
