package com.examate.pharmacart.domain;

import java.time.Instant;
import java.time.LocalDate;

/** Immutable order row. withStatus returns a changed copy: nothing changes until the copy is saved. */
public record Order(String id, String customerId, String medicineCode, int quantity, LocalDate prescriptionDate,
                    long subtotalPaise, long gstPaise, long totalPaise, OrderStatus status, Instant placedAt) {

    public Order withStatus(OrderStatus newStatus) {
        return new Order(id, customerId, medicineCode, quantity, prescriptionDate, subtotalPaise, gstPaise, totalPaise,
                newStatus, placedAt);
    }
}
