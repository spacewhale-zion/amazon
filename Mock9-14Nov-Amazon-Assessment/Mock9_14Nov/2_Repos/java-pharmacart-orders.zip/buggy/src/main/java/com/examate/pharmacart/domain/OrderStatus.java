package com.examate.pharmacart.domain;

public enum OrderStatus {
    PLACED,
    DISPATCHED,
    CANCELLED
}
