package com.examate.pharmacart.repository;

import com.examate.pharmacart.domain.Order;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** In-memory table. Records are immutable: a changed record is only kept after save(). */
@Repository
public class OrderRepository {

    private final Map<String, Order> rows = new LinkedHashMap<>();

    public synchronized Order save(Order row) {
        rows.put(row.id(), row);
        return row;
    }

    public synchronized Optional<Order> findById(String id) {
        return Optional.ofNullable(rows.get(id));
    }

    public synchronized List<Order> findByCustomer(String customerId) {
        return rows.values().stream().filter(o -> o.customerId().equals(customerId)).toList();
    }
}
