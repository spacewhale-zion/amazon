package com.examate.pharmacart.web.dto;

import com.examate.pharmacart.domain.Order;

public record OrderResponse(String id, String customerId, String medicineCode, int quantity, long subtotalPaise,
                            long gstPaise, long totalPaise, String status, String placedAt) {

    public static OrderResponse from(Order o) {
        return new OrderResponse(o.id(), o.customerId(), o.medicineCode(), o.quantity(), o.subtotalPaise(), o.gstPaise(),
                o.totalPaise(), o.status().name(), o.placedAt().toString());
    }
}
