package com.examate.pharmacart.error;

/** A business rule was broken. The handler turns it into the error body for its code. */
public class PharmaException extends RuntimeException {

    private final ErrorCode code;

    public PharmaException(ErrorCode code, String message) {
        super(message);
        this.code = code;
    }

    public ErrorCode code() {
        return code;
    }
}
