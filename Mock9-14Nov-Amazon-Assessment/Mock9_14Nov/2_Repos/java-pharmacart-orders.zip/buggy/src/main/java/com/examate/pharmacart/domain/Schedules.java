package com.examate.pharmacart.domain;

import java.util.List;

/** Drug schedules used in India. SCHEDULE_H medicines are sold only against a valid prescription. */
public final class Schedules {

    public static final String OTC = "OTC";
    public static final String SCHEDULE_H = "SCHEDULE_H";
    public static final List<String> ALL = List.of(OTC, SCHEDULE_H);

    private Schedules() {
    }
}
