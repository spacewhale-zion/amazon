package com.examate.pharmacart.service;

import com.examate.pharmacart.domain.Medicine;
import com.examate.pharmacart.domain.Schedules;
import com.examate.pharmacart.error.ErrorCode;
import com.examate.pharmacart.error.PharmaException;
import java.time.Clock;
import java.time.LocalDate;
import org.springframework.stereotype.Component;

/**
 * README rule 3: a SCHEDULE_H medicine needs a prescription issued at most 180 days ago (a prescription exactly 180
 * days old is still valid) and not in the future.
 */
@Component
public class PrescriptionPolicy {

    static final int VALID_DAYS = 180;

    private final Clock clock;

    public PrescriptionPolicy(Clock clock) {
        this.clock = clock;
    }

    public void check(Medicine m, LocalDate issuedOn) {
        if (!Schedules.SCHEDULE_H.equals(m.schedule())) {
            return;
        }
        LocalDate today = LocalDate.now(clock);
        if (issuedOn == null || issuedOn.isAfter(today)) {
            throw new PharmaException(ErrorCode.PRESCRIPTION_REQUIRED, m.name() + " needs a valid prescription");
        }
        if (!issuedOn.isAfter(today.minusDays(VALID_DAYS))) {
            throw new PharmaException(ErrorCode.PRESCRIPTION_EXPIRED, "The prescription is older than 180 days");
        }
    }
}
