package com.examate.pharmacart.web.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

/** quantity is the number of strips: 1 to 30 per order. prescriptionDate (YYYY-MM-DD) is needed for SCHEDULE_H medicines. */
public record PlaceOrderRequest(@NotBlank String customerId,
                                @NotBlank String medicineCode,
                                @Min(1) @Max(30) int quantity,
                                String prescriptionDate) {
}
