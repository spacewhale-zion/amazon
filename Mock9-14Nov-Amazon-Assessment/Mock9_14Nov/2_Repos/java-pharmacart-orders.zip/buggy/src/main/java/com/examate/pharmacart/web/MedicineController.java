package com.examate.pharmacart.web;

import com.examate.pharmacart.domain.Medicine;
import com.examate.pharmacart.service.CatalogService;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MedicineController {

    private final CatalogService catalog;

    public MedicineController(CatalogService catalog) {
        this.catalog = catalog;
    }

    @GetMapping("/medicines")
    public List<Medicine> list(@RequestParam(name = "schedule", required = false) String schedule) {
        return catalog.list(schedule);
    }

    @GetMapping("/medicines/{code}")
    public Medicine get(@PathVariable("code") String code) {
        return catalog.get(code);
    }
}
