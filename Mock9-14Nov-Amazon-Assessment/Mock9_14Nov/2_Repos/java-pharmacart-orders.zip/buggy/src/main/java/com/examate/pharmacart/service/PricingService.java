package com.examate.pharmacart.service;

import com.examate.pharmacart.domain.Bill;
import com.examate.pharmacart.domain.Medicine;
import org.springframework.stereotype.Service;

/** README rule 5: GST on medicines is 12% of the subtotal, rounded half up to the nearest paisa. */
@Service
public class PricingService {

    static final long GST_PERCENT = 12;

    public Bill bill(Medicine m, int quantity) {
        long subtotal = m.pricePaise() * quantity;
        long gst = subtotal * GST_PERCENT / 100;
        return new Bill(subtotal, gst, subtotal + gst);
    }
}
