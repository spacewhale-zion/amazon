package com.examate.pharmacart.repository;

import com.examate.pharmacart.domain.Medicine;
import com.examate.pharmacart.domain.Schedules;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** In-memory catalogue, seeded at start-up. Records are immutable: a changed record is only kept after save(). */
@Repository
public class MedicineRepository {

    private final Map<String, Medicine> rows = new LinkedHashMap<>();

    public MedicineRepository() {
        save(new Medicine("MED-1", "Paracetamol 500 mg", Schedules.OTC, 2500, 100));
        save(new Medicine("MED-2", "Amoxicillin 500 mg", Schedules.SCHEDULE_H, 1238, 50));
        save(new Medicine("MED-3", "Azithromycin 500 mg", Schedules.SCHEDULE_H, 9999, 2));
        save(new Medicine("MED-4", "Cetirizine 10 mg", Schedules.OTC, 1550, 200));
        save(new Medicine("MED-5", "Pantoprazole 40 mg", Schedules.SCHEDULE_H, 4210, 80));
    }

    public synchronized Medicine save(Medicine row) {
        rows.put(row.code(), row);
        return row;
    }

    public synchronized Optional<Medicine> findByCode(String code) {
        return Optional.ofNullable(rows.get(code));
    }

    public synchronized List<Medicine> findAll() {
        return List.copyOf(rows.values());
    }
}
