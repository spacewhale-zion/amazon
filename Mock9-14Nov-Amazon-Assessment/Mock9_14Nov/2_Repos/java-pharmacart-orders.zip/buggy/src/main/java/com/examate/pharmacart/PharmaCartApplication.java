package com.examate.pharmacart;

import java.time.Clock;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class PharmaCartApplication {

    public static void main(String[] args) {
        SpringApplication.run(PharmaCartApplication.class, args);
    }

    /** Every service reads the time from this clock, so tests can move time. */
    @Bean
    public Clock clock() {
        return Clock.systemUTC();
    }
}
