package com.examate.pharmacart.web;

import com.examate.pharmacart.service.OrderService;
import com.examate.pharmacart.web.dto.OrderResponse;
import com.examate.pharmacart.web.dto.PlaceOrderRequest;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    private final OrderService orders;

    public OrderController(OrderService orders) {
        this.orders = orders;
    }

    @PostMapping("/orders")
    @ResponseStatus(HttpStatus.CREATED)
    public OrderResponse place(@RequestBody PlaceOrderRequest r) {
        return OrderResponse.from(orders.place(r.customerId(), r.medicineCode(), r.quantity(), r.prescriptionDate()));
    }

    @GetMapping("/orders/{orderId}")
    public OrderResponse get(@PathVariable("orderId") String orderId) {
        return OrderResponse.from(orders.get(orderId));
    }

    @PostMapping("/orders/{orderId}/cancel")
    public OrderResponse cancel(@PathVariable("orderId") String orderId) {
        return OrderResponse.from(orders.cancel(orderId));
    }

    @GetMapping("/customers/{customerId}/orders")
    public List<OrderResponse> forCustomer(@PathVariable("customerId") String customerId) {
        return orders.forCustomer(customerId).stream().map(OrderResponse::from).toList();
    }
}
