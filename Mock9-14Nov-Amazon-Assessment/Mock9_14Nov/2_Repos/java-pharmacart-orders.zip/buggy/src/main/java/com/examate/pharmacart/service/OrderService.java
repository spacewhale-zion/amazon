package com.examate.pharmacart.service;

import com.examate.pharmacart.domain.Bill;
import com.examate.pharmacart.domain.Medicine;
import com.examate.pharmacart.domain.Order;
import com.examate.pharmacart.domain.OrderStatus;
import com.examate.pharmacart.error.ErrorCode;
import com.examate.pharmacart.error.PharmaException;
import com.examate.pharmacart.repository.IdGenerator;
import com.examate.pharmacart.repository.OrderRepository;
import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    private final OrderRepository orders;
    private final CatalogService catalog;
    private final PricingService pricing;
    private final PrescriptionPolicy prescriptions;
    private final IdGenerator ids;
    private final Clock clock;

    public OrderService(OrderRepository orders, CatalogService catalog, PricingService pricing,
                        PrescriptionPolicy prescriptions, IdGenerator ids, Clock clock) {
        this.orders = orders;
        this.catalog = catalog;
        this.pricing = pricing;
        this.prescriptions = prescriptions;
        this.ids = ids;
        this.clock = clock;
    }

    public Order place(String customerId, String medicineCode, int quantity, String prescriptionText) {
        LocalDate prescriptionDate = parseDate(prescriptionText);
        Medicine m = catalog.get(medicineCode);
        prescriptions.check(m, prescriptionDate);
        catalog.takeStock(m, quantity);
        Bill bill = pricing.bill(m, quantity);
        Order order = new Order(ids.next("ORD"), customerId, medicineCode, quantity, prescriptionDate,
                bill.subtotalPaise(), bill.gstPaise(), bill.totalPaise(), OrderStatus.PLACED, clock.instant());
        return orders.save(order);
    }

    private static LocalDate parseDate(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        try {
            return LocalDate.parse(text);
        } catch (DateTimeParseException e) {
            throw new PharmaException(ErrorCode.VALIDATION_FAILED, "prescriptionDate must be YYYY-MM-DD");
        }
    }

    public Order get(String id) {
        return orders.findById(id)
                .orElseThrow(() -> new PharmaException(ErrorCode.ORDER_NOT_FOUND, "No order " + id));
    }

    /** README rule 6: only a PLACED order can be cancelled; its strips go back into stock. */
    public Order cancel(String id) {
        Order order = get(id);
        if (order.status() != OrderStatus.PLACED) {
            throw new PharmaException(ErrorCode.INVALID_STATE, "Order " + id + " is " + order.status());
        }
        Order cancelled = order.withStatus(OrderStatus.CANCELLED);
        catalog.returnStock(order.medicineCode(), order.quantity());
        return cancelled;
    }

    public List<Order> forCustomer(String customerId) {
        return orders.findByCustomer(customerId).stream()
                .sorted(Comparator.comparing(Order::placedAt).reversed())
                .toList();
    }
}
