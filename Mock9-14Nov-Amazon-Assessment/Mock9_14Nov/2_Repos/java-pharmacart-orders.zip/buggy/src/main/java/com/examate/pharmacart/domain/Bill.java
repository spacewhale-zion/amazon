package com.examate.pharmacart.domain;

public record Bill(long subtotalPaise, long gstPaise, long totalPaise) {
}
