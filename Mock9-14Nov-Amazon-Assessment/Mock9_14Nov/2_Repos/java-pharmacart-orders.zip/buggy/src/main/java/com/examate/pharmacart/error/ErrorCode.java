package com.examate.pharmacart.error;

import org.springframework.http.HttpStatus;

/** Every error the API can return, with its HTTP status. Must match the error table in README.md. */
public enum ErrorCode {
    VALIDATION_FAILED(HttpStatus.BAD_REQUEST),
    MALFORMED_REQUEST(HttpStatus.BAD_REQUEST),
    MEDICINE_NOT_FOUND(HttpStatus.NOT_FOUND),
    ORDER_NOT_FOUND(HttpStatus.NOT_FOUND),
    OUT_OF_STOCK(HttpStatus.UNPROCESSABLE_ENTITY),
    INVALID_STATE(HttpStatus.CONFLICT),
    PRESCRIPTION_REQUIRED(HttpStatus.UNPROCESSABLE_ENTITY),
    PRESCRIPTION_EXPIRED(HttpStatus.UNPROCESSABLE_ENTITY);

    private final HttpStatus status;

    ErrorCode(HttpStatus status) {
        this.status = status;
    }

    public HttpStatus status() {
        return status;
    }
}
