# PharmaCart pharmacy orders API (Spring Boot)

> **Repository questions: there are 6 in this test. Solve ANY TWO of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | EventPass ticketing | Node.js / Express |
> | 2 | QuizHub online quizzes | Node.js / Express |
> | 3 | PharmaCart pharmacy orders | Java / Spring Boot |
> | 4 | DeskSpace coworking desks | Java / Spring Boot |
> | 5 | TutorMatch tutoring sessions | Python / Django |
> | 6 | RentEase rent invoices | Python / Django |
>
> Pick any two, from the same stack or from different stacks. Only your best two are counted, so finish two
> completely rather than starting several.
>
> **Every visible test fails on the starting code.** Each failing test points at a bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. When all of them pass you are almost done:
> one or two hidden tests run on submit, and they check **the same rules** as the visible tests (with other data),
> so fix the rule properly instead of special-casing the test values.

PharmaCart is the ordering service of an online pharmacy: a medicine catalogue (OTC and prescription-only SCHEDULE_H
medicines), stock, orders with GST, prescription checks and cancellations.

The pharmacy team has reported problems. **Your task: find and fix the bugs in `src/main/java` so that the API behaves
as this README says.** Do not change the tests, `pom.xml`, `application.properties` or this file. When the code and the
README disagree, the README is right.

```
mvn test          # run the tests (Java 17)
mvn spring-boot:run
```

## Code map

| Package | What is in it |
|---|---|
| `web` | controllers and request/response DTOs (validation annotations live on the DTOs) |
| `service` | `CatalogService` (catalogue, stock), `PricingService` (GST), `PrescriptionPolicy`, `OrderService` |
| `repository` | in-memory tables. **Records are immutable: a changed copy is only kept after `save()`** |
| `domain` | `Medicine`, `Order`, `OrderStatus`, `Schedules`, `Bill` |
| `error` | `ErrorCode` (code -> HTTP status), `PharmaException`, the exception handler |

## Conventions

* Money is whole paise. "Today" is the date of the injected `Clock` (UTC).
* Errors: `{ "code": CODE, "message": text, "fields": [...] }`; `fields` lists invalid fields for VALIDATION_FAILED.

| Code | HTTP | Code | HTTP |
|---|---|---|---|
| VALIDATION_FAILED, MALFORMED_REQUEST | 400 | OUT_OF_STOCK, INVALID_STATE | 409 |
| MEDICINE_NOT_FOUND, ORDER_NOT_FOUND | 404 | PRESCRIPTION_REQUIRED, PRESCRIPTION_EXPIRED | 422 |

## Endpoints

| Method and path | Notes |
|---|---|
| `GET /medicines?schedule=` | all medicines, or only `OTC` / `SCHEDULE_H` ones |
| `POST /orders` | `{ customerId, medicineCode, quantity, prescriptionDate? }` -> 201 |
| `GET /orders/{id}`, `POST /orders/{id}/cancel` | |
| `GET /customers/{id}/orders` | newest first |

Seed catalogue: MED-1 Paracetamol (OTC, 2500 paise, 100 strips), MED-2 Amoxicillin (SCHEDULE_H, 1238, 50), MED-3
Azithromycin (SCHEDULE_H, 9999, 2), MED-4 Cetirizine (OTC, 1550, 200), MED-5 Pantoprazole (SCHEDULE_H, 4210, 80).

## Business rules

1. `GET /medicines?schedule=X` returns only the medicines whose schedule is X.
2. `quantity` is 1 to 30 strips; `customerId` and `medicineCode` are required (400 VALIDATION_FAILED).
3. A SCHEDULE_H medicine needs `prescriptionDate` (YYYY-MM-DD): missing or in the future is 422
   PRESCRIPTION_REQUIRED; older than 180 days is 422 PRESCRIPTION_EXPIRED. A prescription **exactly 180 days old is
   still valid**.
4. An order may not take more strips than are in stock (409 OUT_OF_STOCK); a placed order takes them out of stock.
5. `subtotal = price x quantity`; `gst = 12%` of the subtotal **rounded half up to the paisa**; `total = subtotal + gst`.
6. Only a PLACED order can be cancelled (409 INVALID_STATE); it becomes CANCELLED for good and its strips return to
   stock.
