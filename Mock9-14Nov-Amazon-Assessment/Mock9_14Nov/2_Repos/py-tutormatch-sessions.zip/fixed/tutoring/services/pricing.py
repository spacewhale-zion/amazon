"""Session price (README rule 6).

fee          = hourly_rate x minutes / 60, rounded half up to the paisa
platform_fee = 5% of fee, rounded half up
total        = fee + platform_fee
"""
from .. import config
from ..money import div_round_half_up


def price(hourly_rate: int, minutes: int) -> dict:
    fee = div_round_half_up(hourly_rate * minutes, 60)
    platform_fee = div_round_half_up(fee * config.PLATFORM_FEE_PERCENT, 100)
    return {"fee": fee, "platform_fee": platform_fee, "total": fee + platform_fee}
