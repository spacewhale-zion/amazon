"""OTP login (README rule 8).

A phone is LOCKED when it has 5 wrong OTP attempts in the last 15 minutes, whatever codes were typed. While locked,
every attempt is refused with 429, even the right OTP. The lock ends 15 minutes after the oldest of those attempts.
"""
from datetime import timedelta

from .. import clock, config
from ..errors import Locked, NotFound, Unauthorized
from ..models import LoginAttempt, Student


def recent_wrong(phone, otp):
    since = clock.now() - timedelta(minutes=config.OTP_WINDOW_MINUTES)
    return LoginAttempt.objects.filter(phone=phone, success=False, at__gt=since).count()


def verify(phone, otp) -> Student:
    student = Student.objects.filter(phone=phone).first()
    if student is None:
        raise NotFound("no student with this phone")
    if recent_wrong(phone, otp) >= config.OTP_MAX_WRONG:
        raise Locked("too many wrong OTPs, try again later")
    ok = otp == config.TEST_OTP
    LoginAttempt.objects.create(phone=phone, code=otp, success=ok, at=clock.now())
    if not ok:
        raise Unauthorized("wrong OTP")
    return student
