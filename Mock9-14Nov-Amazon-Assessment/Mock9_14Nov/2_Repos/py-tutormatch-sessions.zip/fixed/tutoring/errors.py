class ApiError(Exception):
    """Raised by the services and validation. The views turn it into {"error": code, "message": message}."""

    status = 400
    code = "VALIDATION_FAILED"

    def __init__(self, message: str, code: str | None = None):
        super().__init__(message)
        self.message = message
        if code:
            self.code = code


class BadRequest(ApiError):
    status = 400
    code = "VALIDATION_FAILED"


class Unauthorized(ApiError):
    status = 401
    code = "WRONG_OTP"


class NotFound(ApiError):
    status = 404
    code = "NOT_FOUND"


class Conflict(ApiError):
    status = 409
    code = "CONFLICT"


class SlotTaken(Conflict):
    """The tutor already has a session that overlaps the requested time (README rule 4)."""
    code = "SLOT_TAKEN"


class Unprocessable(ApiError):
    status = 422
    code = "RULE_FAILED"


class Locked(ApiError):
    status = 429
    code = "LOCKED"
