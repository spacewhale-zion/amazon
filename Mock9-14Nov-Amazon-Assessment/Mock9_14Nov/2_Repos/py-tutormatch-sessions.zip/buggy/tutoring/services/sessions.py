from datetime import timedelta

from django.db import transaction

from .. import clock, config
from ..errors import Conflict, NotFound, SlotTaken, Unprocessable
from ..models import Session
from . import people, pricing


def end_of(s: Session):
    return s.starts_at + timedelta(minutes=s.minutes)


def overlaps(existing: Session, start, end) -> bool:
    """Half-open intervals: a session ending at 11:00 and one starting at 11:00 do not overlap."""
    return existing.starts_at <= end and start <= end_of(existing)


@transaction.atomic
def book(data) -> Session:
    tutor = people.get_tutor(data["tutor_id"])
    student = people.get_student(data["student_id"])
    start = data["starts_at"]
    if start <= clock.now():
        raise Unprocessable("a session must start in the future", "IN_THE_PAST")
    end = start + timedelta(minutes=data["minutes"])
    for s in Session.objects.filter(tutor=tutor, status=Session.BOOKED):
        if overlaps(s, start, end):
            raise SlotTaken(f"{tutor.name} is busy from {s.starts_at:%H:%M} to {end_of(s):%H:%M}")
    return Session.objects.create(tutor=tutor, student=student, starts_at=start, minutes=data["minutes"],
                                  **pricing.price(tutor.hourly_rate, data["minutes"]))


def get(session_id) -> Session:
    s = Session.objects.select_related("tutor", "student").filter(pk=session_id).first()
    if s is None:
        raise NotFound("session not found")
    return s


@transaction.atomic
def cancel(session_id) -> Session:
    """Free cancellation up to 24 hours before the start: full refund. Later: no refund."""
    s = get(session_id)
    if s.status != Session.BOOKED:
        raise Conflict("this session is already cancelled", "INVALID_STATE")
    now = clock.now()
    s.status = Session.CANCELLED
    s.cancelled_at = now
    s.refund = s.total if s.starts_at - now >= timedelta(hours=config.FREE_CANCEL_HOURS) else 0
    s.save(update_fields=["cancelled_at", "refund"])
    return s


def for_tutor(tutor_id):
    people.get_tutor(tutor_id)
    return Session.objects.select_related("tutor", "student").filter(tutor_id=tutor_id).order_by("starts_at", "id")
