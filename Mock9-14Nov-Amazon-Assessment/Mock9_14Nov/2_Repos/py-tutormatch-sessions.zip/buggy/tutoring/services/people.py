from ..errors import Conflict, NotFound
from ..models import Student, Tutor


def add_tutor(data) -> Tutor:
    return Tutor.objects.create(**data)


def add_student(data) -> Student:
    if Student.objects.filter(phone=data["phone"]).exists():
        raise Conflict("a student with this phone already exists", "DUPLICATE")
    return Student.objects.create(**data)


def get_tutor(tutor_id) -> Tutor:
    tutor = Tutor.objects.filter(pk=tutor_id).first()
    if tutor is None:
        raise NotFound("tutor not found")
    return tutor


def get_student(student_id) -> Student:
    student = Student.objects.filter(pk=student_id).first()
    if student is None:
        raise NotFound("student not found")
    return student
