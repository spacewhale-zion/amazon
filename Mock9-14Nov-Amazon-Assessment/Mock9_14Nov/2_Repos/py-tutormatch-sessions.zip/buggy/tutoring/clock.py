"""The current time for TutorMatch (UTC). Provided and read-only: the tests set it."""
from datetime import datetime, timezone

_now = None


def now() -> datetime:
    return _now or datetime.now(timezone.utc).replace(microsecond=0)


def set_now(t: datetime) -> None:
    global _now
    _now = t


def reset() -> None:
    global _now
    _now = None
