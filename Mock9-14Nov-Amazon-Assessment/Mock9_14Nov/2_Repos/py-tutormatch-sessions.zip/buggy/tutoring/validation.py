"""Checks for request bodies. Each function returns cleaned values or raises BadRequest (400)."""
import re
from datetime import datetime

from . import config
from .errors import BadRequest

PHONE = re.compile(r"\d{10}")


def _text(body, key, max_length=100):
    value = body.get(key)
    if not isinstance(value, str) or not value.strip():
        raise BadRequest(f"{key} is required")
    if len(value.strip()) > max_length:
        raise BadRequest(f"{key} is too long")
    return value.strip()


def _int(body, key, low=None, high=None):
    value = body.get(key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise BadRequest(f"{key} must be a whole number")
    if low is not None and value < low:
        raise BadRequest(f"{key} must be at least {low}")
    if high is not None and value > high:
        raise BadRequest(f"{key} must be at most {high}")
    return value


def _phone(body):
    phone = _text(body, "phone", 10)
    if not PHONE.fullmatch(phone):
        raise BadRequest("phone must be 10 digits")
    return phone


def tutor_in(body):
    return {"name": _text(body, "name"), "subject": _text(body, "subject", 60),
            "hourly_rate": _int(body, "hourly_rate", 100, 10_000_00)}


def student_in(body):
    return {"name": _text(body, "name"), "phone": _phone(body)}


def otp_in(body):
    return {"phone": _phone(body), "otp": _text(body, "otp", 10)}


def session_in(body):
    minutes = _int(body, "minutes", config.SESSION_MIN_MINUTES, config.SESSION_MAX_MINUTES)
    raw = _text(body, "starts_at", 30)
    try:
        starts_at = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        raise BadRequest("starts_at must be an ISO time like 2026-06-02T10:00:00Z")
    if starts_at.tzinfo is None:
        raise BadRequest("starts_at needs a time zone (use Z for UTC)")
    return {"student_id": _int(body, "student_id", 1), "tutor_id": _int(body, "tutor_id", 1),
            "starts_at": starts_at, "minutes": minutes}
