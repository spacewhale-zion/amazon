"""TutorMatch data model. Money is whole paise; times are UTC."""
from django.db import models


class Tutor(models.Model):
    name = models.CharField(max_length=100)
    subject = models.CharField(max_length=60)
    hourly_rate = models.IntegerField()                 # paise per hour


class Student(models.Model):
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15, unique=True)


class Session(models.Model):
    BOOKED, CANCELLED = "BOOKED", "CANCELLED"
    tutor = models.ForeignKey(Tutor, on_delete=models.PROTECT, related_name="sessions")
    student = models.ForeignKey(Student, on_delete=models.PROTECT, related_name="sessions")
    starts_at = models.DateTimeField()
    minutes = models.IntegerField()
    fee = models.IntegerField()
    platform_fee = models.IntegerField()
    total = models.IntegerField()
    status = models.CharField(max_length=10, default=BOOKED)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    refund = models.IntegerField(default=0)


class LoginAttempt(models.Model):
    """Every OTP check is recorded, right or wrong."""
    phone = models.CharField(max_length=15)
    code = models.CharField(max_length=10)
    success = models.BooleanField()
    at = models.DateTimeField()
