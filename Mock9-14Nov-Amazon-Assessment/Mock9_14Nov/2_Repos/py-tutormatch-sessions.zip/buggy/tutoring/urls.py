from django.urls import path

from .api import views

urlpatterns = [
    path("tutors", views.tutors),
    path("tutors/<int:tutor_id>/sessions", views.tutor_sessions),
    path("students", views.students),
    path("auth/verify-otp", views.verify_otp),
    path("sessions", views.book),
    path("sessions/<int:session_id>", views.session_detail),
    path("sessions/<int:session_id>/cancel", views.cancel),
]
