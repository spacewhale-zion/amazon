"""Settings. Provided and read-only. Money is whole paise."""
TEST_OTP = "482913"                 # the OTP every phone receives in this test build
OTP_MAX_WRONG = 5                   # wrong OTPs allowed in the window
OTP_WINDOW_MINUTES = 15
SESSION_MIN_MINUTES = 30
SESSION_MAX_MINUTES = 180
SESSION_STEP_MINUTES = 15
PLATFORM_FEE_PERCENT = 5
FREE_CANCEL_HOURS = 24
