from .. import validation
from ..services import auth, people, sessions
from .common import api, iso


def tutor_view(t):
    return {"tutor_id": t.id, "name": t.name, "subject": t.subject, "hourly_rate": t.hourly_rate}


def session_view(s):
    return {"session_id": s.id, "tutor_id": s.tutor_id, "student_id": s.student_id, "starts_at": iso(s.starts_at),
            "minutes": s.minutes, "fee": s.fee, "platform_fee": s.platform_fee, "total": s.total, "status": s.status,
            "refund": s.refund}


@api("POST")
def tutors(request, body):
    return 201, tutor_view(people.add_tutor(validation.tutor_in(body)))


@api("POST")
def students(request, body):
    s = people.add_student(validation.student_in(body))
    return 201, {"student_id": s.id, "name": s.name, "phone": s.phone}


@api("POST")
def verify_otp(request, body):
    data = validation.otp_in(body)
    s = auth.verify(data["phone"], data["otp"])
    return 200, {"student_id": s.id, "token": f"student-{s.id}"}


@api("POST")
def book(request, body):
    return 201, session_view(sessions.book(validation.session_in(body)))


@api("GET")
def session_detail(request, body, session_id):
    return 200, session_view(sessions.get(session_id))


@api("POST")
def cancel(request, body, session_id):
    return 200, session_view(sessions.cancel(session_id))


@api("GET")
def tutor_sessions(request, body, tutor_id):
    return 200, [session_view(s) for s in sessions.for_tutor(tutor_id)]
