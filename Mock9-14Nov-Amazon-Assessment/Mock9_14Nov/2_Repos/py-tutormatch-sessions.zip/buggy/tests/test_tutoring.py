"""These tests describe behaviour from README.md that is broken right now: every one of them FAILS on the starting
code. Fix the bugs in tutoring/ until they all pass. One or two hidden tests check the same rules again."""


def test_an_overlapping_session_is_409_slot_taken(tm):
    t, s = tm.tutor(), tm.student()
    assert tm.book(t, s, "2026-06-02T10:00:00Z", 60).status_code == 201
    r = tm.book(t, tm.student("9876500002"), "2026-06-02T10:30:00Z", 60)
    assert r.status_code == 409
    assert r.json()["error"] == "SLOT_TAKEN"


def test_back_to_back_sessions_are_allowed(tm):
    t, s = tm.tutor(), tm.student()
    assert tm.book(t, s, "2026-06-02T10:00:00Z", 60).status_code == 201
    assert tm.book(t, s, "2026-06-02T11:00:00Z", 45).status_code == 201


def test_session_length_must_be_a_multiple_of_15_minutes(tm):
    r = tm.book(tm.tutor(), tm.student(), "2026-06-02T10:00:00Z", 40)
    assert r.status_code == 400
    assert r.json()["error"] == "VALIDATION_FAILED"


def test_the_fee_is_rounded_half_up_to_the_paisa(tm):
    r = tm.book(tm.tutor(hourly_rate=60050), tm.student(), "2026-06-03T15:00:00Z", 45)   # 600.50 x 0.75 = 450.375
    assert r.status_code == 201
    assert (r.json()["fee"], r.json()["platform_fee"], r.json()["total"]) == (45038, 2252, 47290)


def test_a_cancelled_session_stays_cancelled(tm):
    sid = tm.book(tm.tutor(), tm.student(), "2026-06-05T10:00:00Z", 60).json()["session_id"]
    assert tm.post(f"/sessions/{sid}/cancel").status_code == 200
    assert tm.get(f"/sessions/{sid}").json()["status"] == "CANCELLED"


def test_five_wrong_otps_lock_the_phone_even_with_different_codes(tm):
    tm.student("9000000001")
    for code in ("111111", "222222", "333333", "444444", "555555"):
        assert tm.otp("9000000001", code).status_code == 401
    r = tm.otp("9000000001", "482913")                          # the right OTP, but the phone is locked
    assert r.status_code == 429
    assert r.json()["error"] == "LOCKED"
