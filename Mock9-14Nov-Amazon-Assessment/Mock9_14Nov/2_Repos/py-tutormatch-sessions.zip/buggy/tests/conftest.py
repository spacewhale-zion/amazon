import os

import django

# the runner's pytest config names no settings module, so load Django here, before any test imports a model
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tutorsite.settings")
django.setup()

import json  # noqa: E402
from datetime import datetime, timedelta, timezone  # noqa: E402

import pytest  # noqa: E402

from tutoring import clock  # noqa: E402

START = datetime(2026, 6, 1, 9, 0, tzinfo=timezone.utc)        # Monday 1 June 2026, 09:00 UTC


@pytest.fixture(autouse=True)
def clean_state(db):
    clock.set_now(START)
    yield
    clock.reset()


@pytest.fixture
def tm(client):
    class TM:
        def get(self, url):
            return client.get(url)

        def post(self, url, body=None):
            return client.post(url, data=json.dumps(body if body is not None else {}), content_type="application/json")

        def tutor(self, hourly_rate=60000, name="Meera", subject="Physics"):
            r = self.post("/tutors", {"name": name, "subject": subject, "hourly_rate": hourly_rate})
            assert r.status_code == 201, r.content
            return r.json()["tutor_id"]

        def student(self, phone="9876500001", name="Arjun"):
            r = self.post("/students", {"name": name, "phone": phone})
            assert r.status_code == 201, r.content
            return r.json()["student_id"]

        def book(self, tutor_id, student_id, starts_at, minutes=60):
            return self.post("/sessions", {"tutor_id": tutor_id, "student_id": student_id, "starts_at": starts_at,
                                           "minutes": minutes})

        def otp(self, phone, code):
            return self.post("/auth/verify-otp", {"phone": phone, "otp": code})

        def later(self, **kw):
            clock.set_now(clock.now() + timedelta(**kw))

    return TM()
