# TutorMatch tutoring sessions API (Django)

> **Repository questions: there are 6 in this test. Solve ANY TWO of them.**
>
> | # | App | Stack |
> |---|---|---|
> | 1 | EventPass ticketing | Node.js / Express |
> | 2 | QuizHub online quizzes | Node.js / Express |
> | 3 | PharmaCart pharmacy orders | Java / Spring Boot |
> | 4 | DeskSpace coworking desks | Java / Spring Boot |
> | 5 | TutorMatch tutoring sessions | Python / Django |
> | 6 | RentEase rent invoices | Python / Django |
>
> Pick any two, from the same stack or from different stacks. Only your best two are counted, so finish two
> completely rather than starting several.
>
> **Every visible test fails on the starting code.** Each failing test points at a bug: read the test, read the
> rule in this README, find the code that breaks the rule and fix it. When all of them pass you are almost done:
> one or two hidden tests run on submit, and they check **the same rules** as the visible tests (with other data),
> so fix the rule properly instead of special-casing the test values.

TutorMatch connects students with home tutors: tutors with an hourly rate, students who log in with a phone OTP,
session booking without double-booking a tutor, fees with a platform charge, and cancellations.

Users have reported problems. **Your task: find and fix the bugs in `tutoring/` so that the API behaves as this README
says.** Do not change the tests, `requirements.txt`, `tutoring/clock.py`, `tutoring/config.py`, `tutoring/money.py`,
`tutorsite/`, `manage.py` or this file. When the code and the README disagree, the README is right.

```
pip install -r requirements.txt
pytest -q                          # every test gets a fresh in-memory SQLite database
python manage.py runserver         # optional
```

## Code map

| Path | What is in it |
|---|---|
| `tutoring/api/` | views and the JSON/error wrapper (no business rules) |
| `tutoring/services/` | `auth.py` (OTP and lockout), `sessions.py` (booking, overlap, cancel), `pricing.py`, `people.py` |
| `tutoring/models.py` | Tutor, Student, Session, LoginAttempt. `save(update_fields=[...])` writes only the listed columns |
| `tutoring/validation.py`, `tutoring/errors.py` | request checks and error classes (each class has its HTTP status) |
| `tutoring/money.py` | `div_round_half_up` |

## Conventions

* Money is whole paise. Times are UTC ISO strings ending in Z.
* Errors: `{ "error": CODE, "message": text }`.

| Code | HTTP | Code | HTTP |
|---|---|---|---|
| VALIDATION_FAILED | 400 | SLOT_TAKEN, DUPLICATE, INVALID_STATE | 409 |
| WRONG_OTP | 401 | IN_THE_PAST | 422 |
| NOT_FOUND | 404 | LOCKED | 429 |

## Endpoints

| Method and path | Notes |
|---|---|
| `POST /tutors`, `POST /students` | `{ name, subject, hourly_rate }`, `{ name, phone }` |
| `POST /auth/verify-otp` | `{ phone, otp }` -> 200 `{ student_id, token }` |
| `POST /sessions` | `{ tutor_id, student_id, starts_at, minutes }` -> 201 |
| `GET /sessions/{id}`, `POST /sessions/{id}/cancel` | |
| `GET /tutors/{id}/sessions` | by start time |

## Business rules

1. `minutes` is 30 to 180 **in steps of 15** (400 VALIDATION_FAILED). A session must start in the future (422
   IN_THE_PAST).
2. A tutor cannot have two BOOKED sessions that overlap: 409 SLOT_TAKEN.
3. Sessions are half-open intervals: one ending at 11:00 and the next starting at 11:00 **do not overlap**.
4. `fee = hourly_rate x minutes / 60`, **rounded half up** to the paisa; `platform_fee` = 5% of the fee, rounded half
   up; `total = fee + platform_fee`.
5. Cancelling makes a session CANCELLED for good (409 INVALID_STATE if already cancelled); 24 hours or more before the
   start the total is refunded, later nothing is.
6. OTP login: the test OTP is in `config.py`. A wrong OTP is 401 WRONG_OTP.
7. **Lockout:** a phone with **5 wrong OTP attempts in the last 15 minutes, whatever codes were typed,** is locked:
   every attempt is 429 LOCKED, even the right OTP, until those attempts are older than 15 minutes.
