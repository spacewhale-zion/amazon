from django.urls import include, path

urlpatterns = [path("", include("tutoring.urls"))]
