"""Settings for the TutorMatch tutoring service. Provided and read-only."""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = "exam-only-not-a-secret"
DEBUG = False
ALLOWED_HOSTS = ["testserver", "localhost"]

INSTALLED_APPS = ["tutoring"]
MIDDLEWARE = ["django.middleware.common.CommonMiddleware"]
ROOT_URLCONF = "tutorsite.urls"
APPEND_SLASH = False

DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}}
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

USE_TZ = True
TIME_ZONE = "UTC"

# 4xx responses are part of the API, not errors worth logging
LOGGING = {"version": 1, "disable_existing_loggers": False, "loggers": {"django.request": {"level": "ERROR"}}}
