# Planted bugs (author only, never shown to students)

TutorMatch tutoring sessions API (Django).

All visible tests fail on the starting code. Each visible and hidden test fails for exactly one bug (checked by applying each bug alone to the fixed code). Hidden tests re-check the same rules with other data.

| # | Kind | Symptom | File | Fixed code | Buggy code | Visible tests | Hidden tests |
|---|---|---|---|---|---|---|---|
| 1 | RP-03 Status codes | An overlapping session is 400 instead of 409 | `tutoring/errors.py` | `class SlotTaken(Conflict):` | `class SlotTaken(BadRequest):` | test_an_overlapping_session_is_409_slot_taken | none |
| 2 | RP-04 Persistence (update_fields) | A cancelled session goes back to BOOKED | `tutoring/services/sessions.py` | `s.save(update_fields=["status", "cancelled_at", "refund"])` | `s.save(update_fields=["cancelled_at", "refund"])` | test_a_cancelled_session_stays_cancelled | none |
| 3 | RP-05 Validation | A 40-minute session is accepted | `tutoring/validation.py` | `if minutes % config.SESSION_STEP_MINUTES != 0: raise BadRequest(f"minutes must be a multiple of {config.SESSION_STEP_MINUTES}")` | `(removed)` | test_session_length_must_be_a_multiple_of_15_minutes | none |
| 4 | RP-06 Boundary (intervals) | Back-to-back sessions are refused as overlapping | `tutoring/services/sessions.py` | `return existing.starts_at < end and start < end_of(existing)` | `return existing.starts_at <= end and start <= end_of(existing)` | test_back_to_back_sessions_are_allowed | test_a_session_may_end_exactly_when_the_next_starts |
| 5 | RP-07 Arithmetic (rounding) | The fee is rounded down instead of half up | `tutoring/services/pricing.py` | `fee = div_round_half_up(hourly_rate * minutes, 60)` | `fee = hourly_rate * minutes // 60` | test_the_fee_is_rounded_half_up_to_the_paisa | test_fee_for_90_minutes_rounds_up |
| 6 | RP-10 Rate limit / lockout | The OTP lock only counts repeats of the same wrong code | `tutoring/services/auth.py` | `return LoginAttempt.objects.filter(phone=phone, success=False, at__gt=since).count()` | `return LoginAttempt.objects.filter(phone=phone, code=otp, success=False, at__gt=since).count()` | test_five_wrong_otps_lock_the_phone_even_with_different_codes | none |

Fix notes:

1. SLOT_TAKEN is a conflict with existing data: the class must extend Conflict (409), not BadRequest (400).
2. save(update_fields=...) writes only the listed columns. status must be in the list.
3. Sessions are booked in steps of 15 minutes: refuse any other length with 400.
4. Intervals are half-open: one ending at 11:00 and the next starting at 11:00 do not overlap, so compare with <.
5. // always rounds down. The README rounds half up: use div_round_half_up.
6. The lock counts every wrong attempt for the phone, whatever code was typed. Filtering by code lets an attacker try 5 codes, then 5 more, forever.
