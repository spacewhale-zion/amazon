def test_fee_for_90_minutes_rounds_up(tm):
    r = tm.book(tm.tutor(hourly_rate=33333), tm.student(), "2026-06-04T08:00:00Z", 90)     # 499.995 -> 50000 paise
    assert r.json()["fee"] == 50000


def test_a_session_may_end_exactly_when_the_next_starts(tm):
    t, s = tm.tutor(), tm.student()
    assert tm.book(t, s, "2026-06-02T14:00:00Z", 60).status_code == 201
    assert tm.book(t, s, "2026-06-02T13:15:00Z", 45).status_code == 201
